#!/bin/bash
# Compila Que Pasa Hermano sin Gradle: aapt + javac + dx + zipalign + apksigner
set -euo pipefail
cd "$(dirname "$0")"
SDK=/usr/lib/android-sdk
AJ=$SDK/platforms/android-23/android.jar
OUT=build
rm -rf "$OUT"; mkdir -p "$OUT/gen" "$OUT/obj" "$OUT/apk"

echo "1/6 recursos"
aapt package -f -m -J "$OUT/gen" -M AndroidManifest.xml -S res -A assets -I "$AJ" \
  --min-sdk-version 21 --target-sdk-version 34 -0 arsc -0 woff2 -F "$OUT/apk/unsigned.apk"

echo "2/6 java"
javac -nowarn -Xlint:-options -encoding UTF-8 -source 8 -target 8 -bootclasspath "$AJ" -classpath "$AJ" \
  -d "$OUT/obj" $(find src "$OUT/gen" -name '*.java')

echo "3/6 dex"
dalvik-exchange --dex --min-sdk-version=21 --output="$OUT/apk/classes.dex" "$OUT/obj"

echo "4/6 empaquetar"
(cd "$OUT/apk" && aapt add -f unsigned.apk classes.dex >/dev/null)

echo "5/6 alinear"
zipalign -f -p 4 "$OUT/apk/unsigned.apk" "$OUT/apk/aligned.apk"

echo "6/6 firmar"
if [ ! -f keystore/qph.jks ]; then
  mkdir -p keystore
  keytool -genkeypair -keystore keystore/qph.jks -alias qph -keyalg RSA -keysize 2048 -validity 12000 \
    -storepass quepasahermano -keypass quepasahermano -dname "CN=Que Pasa Hermano, O=Que Pasa Hermano, C=CO" 2>/dev/null
fi
apksigner sign --ks keystore/qph.jks --ks-key-alias qph --ks-pass pass:quepasahermano --key-pass pass:quepasahermano \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --min-sdk-version 21 --out "$OUT/QuePasaHermano.apk" "$OUT/apk/aligned.apk"
apksigner verify "$OUT/QuePasaHermano.apk"
ls -la "$OUT/QuePasaHermano.apk"
