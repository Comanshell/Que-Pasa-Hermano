/* Que Pasa Hermano — arranque, acciones y puente con Android */
'use strict';

var DEVICE = { lowEnd: false, sdk: 0 };
function fxOn() { var f = S.settings.fx; return (f === null || f === undefined) ? !DEVICE.lowEnd : !!f; }
function motionOn() { return S.settings.motion !== false; }
function sysDark() {
  if (Native) { var r = nat('systemDark'); if (typeof r === 'boolean') return r; }
  return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
}
function applyTheme() {
  var t = S.settings.theme, dark = t === 'auto' ? sysDark() : t !== 'light', root = document.documentElement;
  root.setAttribute('data-theme', dark ? 'dark' : 'light');
  root.style.setProperty('--accent', S.settings.accent || '#FA2D48');
  root.classList.toggle('nofx', !fxOn());
  root.classList.toggle('nomotion', !motionOn());
  nat('setTheme', dark);
  MINI.key = ''; PLAYER.key = '';
}

function appIcon(size) {
  return '<svg class="app-ic" width="' + size + '" height="' + size + '" viewBox="0 0 100 100" aria-hidden="true"><rect width="100" height="100" rx="23" fill="var(--accent)"/>' +
    '<path d="M27 25h46a12 12 0 0 1 12 12v22a12 12 0 0 1-12 12H48L33 82.5V71h-6a12 12 0 0 1-12-12V37a12 12 0 0 1 12-12z" fill="#fff"/>' +
    '<path d="M37 48.5l9 9 18-18.5" fill="none" stroke="var(--accent)" stroke-width="7.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
}

/* ---------- acciones ---------- */
function actMenu(a) {
  var items = [];
  if (a.kind !== 'evento') {
    if (isOpen(a)) items.push({ t: 'Marcar como completada', fn: function () { setStatus(a, 'completada'); } });
    else items.push({ t: 'Marcar como pendiente', fn: function () { setStatus(a, 'pendiente'); } });
    if (a.status === 'pendiente') items.push({ t: 'Marcar en proceso', fn: function () { setStatus(a, 'proceso'); } });
  }
  if (isOpen(a)) items.push({ t: 'Estudiar ahora', fn: function () { focusAct(a); } });
  items.push({ t: 'Editar', fn: function () { actForm(a); } });
  if (isOpen(a)) items.push({ t: 'Posponer un día', fn: function () {
    var snap = snapshot();
    a.date = ymd(addDays(pymd(a.date), 1)); save(); refresh();
    toast('Movida a ' + relDay(pymd(a.date)).toLowerCase(), function () { restore(snap); });
  } });
  items.push({ t: 'Eliminar', danger: true, fn: function () { deleteAct(a.id); } });
  actionSheet(esc(a.title), items);
}
function setStatus(a, st) {
  if (a.status === st) return;
  var snap = snapshot();
  a.status = st;
  a.completedAt = st === 'completada' ? Date.now() : null;
  if (st === 'completada' && S.focus && S.focus.actId === a.id) { S.focus = null; }
  save(); refresh();
  var row = document.getElementById('tr-' + a.id);
  if (row) row.classList.add('pop');
  if (st === 'completada') { haptic(2); toast('Completada: ' + a.title, function () { restore(snap); }); }
  else haptic(0);
}
function cycleStatus(a) {
  var next = { pendiente: 'proceso', proceso: 'completada', completada: 'pendiente' }[a.status] || 'pendiente';
  setStatus(a, next);
}
function focusAct(a) {
  if (!isOpen(a)) { toast('Esta actividad ya está completada'); return; }
  var key = 'act:' + a.id;
  if (S.focus && S.focus.key === key) { openPlayer(); return; }
  if (S.focus) focusStop(false);
  var dur = (+S.settings.focusMin || 25) * 60000, now = Date.now();
  S.focus = { key: key, actId: a.id, subId: a.subjectId || null, label: a.title, dur: dur, endAt: now + dur, running: true, remaining: null, started: now };
  if (a.status === 'pendiente' && a.kind !== 'evento') a.status = 'proceso';
  MINI.sel = key;
  save(); render(); renderMini(); openPlayer();
  toast('Sesión de ' + (+S.settings.focusMin) + ' min');
  if (Native && nat('canNotify') === false) nat('askNotify');
}
var fileDelTimer = null, fileDelList = [];
function scheduleFileDelete(files) {
  if (!files || !files.length) return;
  fileDelList = fileDelList.concat(files.map(function (f) { return f.id; }));
  clearTimeout(fileDelTimer);
  fileDelTimer = setTimeout(function () {
    fileDelList.forEach(function (id) { if (!findFile(id)) nat('removeFile', id); });
    fileDelList = [];
  }, 7000);
}
function resetStacks(test) {
  Object.keys(NAV.stacks).forEach(function (k) {
    var root = NAV.stacks[k][0];
    NAV.stacks[k] = NAV.stacks[k].filter(function (en, i) { return i === 0 || !test(en); });
    if (!NAV.stacks[k].length) NAV.stacks[k] = [root];
  });
}
function deleteAct(id) {
  var a = getAct(id); if (!a) return;
  actionSheet('¿Eliminar «' + esc(a.title) + '»?', [{ t: 'Eliminar', danger: true, fn: function () {
    var snap = snapshot(), wasHere = curEntry().v === 'act' && curEntry().id === id;
    closeAllSheets(); FORM = null;
    S.acts = S.acts.filter(function (x) { return x.id !== id; });
    S.subjects.forEach(function (s) { s.grades.forEach(function (g) { if (g.actId === id) delete g.actId; }); });
    if (S.focus && S.focus.actId === id) S.focus = null;
    save();
    resetStacks(function (en) { return en.v === 'act' && en.id === id; });
    render(wasHere ? 'pop' : undefined); renderMini();
    scheduleFileDelete(a.files);
    toast('Eliminada', function () { restore(snap); });
  } }]);
}
function deleteSubject(id) {
  var sub = getSub(id); if (!sub) return;
  actionSheet('Se eliminará «' + esc(sub.name) + '» con sus calificaciones, apuntes y clases del horario. Sus tareas quedarán sin materia.', [{ t: 'Eliminar materia', danger: true, fn: function () {
    var snap = snapshot(), files = [];
    closeAllSheets();
    S.notes.filter(function (n) { return n.subjectId === id; }).forEach(function (n) { files = files.concat(n.files || []); });
    S.notes = S.notes.filter(function (n) { return n.subjectId !== id; });
    S.classes = S.classes.filter(function (c) { return c.subjectId !== id; });
    S.acts.forEach(function (a) { if (a.subjectId === id) a.subjectId = ''; });
    S.subjects = S.subjects.filter(function (s) { return s.id !== id; });
    if (S.focus && S.focus.subId === id) S.focus = null;
    save();
    resetStacks(function (en) { return en.v === 'subject' && en.id === id; });
    render('pop'); renderMini();
    scheduleFileDelete(files);
    toast('Materia eliminada', function () { restore(snap); });
  } }]);
}
function miniStep(d) {
  var st = miniState(); if (!st.it) return;
  var i = st.q.indexOf(st.it) + d;
  if (i < 0 || i >= st.q.length) return;
  MINI.sel = st.q[i].key; renderMini(); renderPlayer(); haptic(0);
}
function pick(tag, mode) {
  if (!Native) { toast('Disponible en la app instalada en el celular'); return; }
  nat('pick', tag, mode);
}
function loadDemo() {
  var go = function () {
    var name = S.profile.name;
    S = seedState({ profile: S.profile, settings: S.settings });
    S.profile.name = name;
    save(); initNav(); render('tab'); renderChrome();
    toast('Datos de ejemplo cargados');
  };
  if (S.subjects.length || S.acts.length) actionSheet('Los datos de ejemplo reemplazan tus materias, tareas y horario actuales.', [{ t: 'Reemplazar con el ejemplo', danger: true, fn: go }]);
  else go();
}
function goCalendar(mode) {
  NAV.stacks.calendario = [{ v: 'calendar', mode: mode }];
  if (NAV.tab === 'calendario') render('tab'); else switchTab('calendario');
}
function pushHere(entry) { if (PLAYER.open) closePlayer(); entry.back = curEntry().title; push(entry); }

var ACTIONS = {
  'tab': function (d) { switchTab(d.tab); },
  'back': function () { pop(); },
  'quick-add': function () { quickAdd(); },
  'go-horario': function () { goCalendar('horario'); },
  'go-cal': function () { goCalendar('mes'); },
  'load-demo': loadDemo,

  'open-subject': function (d) { if (getSub(d.id)) pushHere({ v: 'subject', id: d.id }); },
  'new-subject': function () { subjectForm(null); },
  'sub-menu': function (d) {
    var sub = getSub(d.id); if (!sub) return;
    actionSheet(esc(sub.name), [
      { t: 'Editar materia', fn: function () { subjectForm(sub); } },
      { t: 'Nueva actividad', fn: function () { actForm(null, { subjectId: sub.id }); } },
      { t: 'Nuevo apunte', fn: function () { noteForm(null, sub.id); } },
      { t: 'Agregar clase al horario', fn: function () { classForm(null, { subjectId: sub.id }); } },
      { t: 'Eliminar materia', danger: true, fn: function () { deleteSubject(sub.id); } }
    ]);
  },
  'sub-mode': function (d) {
    var sub = getSub(d.id); if (!sub || sub.mode === d.v) return;
    var snap = snapshot();
    applyMode(sub, d.v); save(); render(); haptic(1);
    toast(d.v === 'equal' ? 'Ahora todas las notas valen igual' : 'Ahora cada nota tiene su porcentaje', function () { restore(snap); });
  },
  'delete-subject': function (d) { deleteSubject(d.id); },

  'new-act': function (d) { actForm(null, { subjectId: d.sub, date: d.date }); },
  'open-act': function (d) { if (getAct(d.id)) pushHere({ v: 'act', id: d.id }); },
  'edit-act': function (d) { var a = getAct(d.id); if (a) actForm(a); },
  'act-menu': function (d) { var a = getAct(d.id); if (a) actMenu(a); },
  'delete-act': function (d) { deleteAct(d.id); },
  'cycle-status': function (d) { var a = getAct(d.id); if (a) cycleStatus(a); },
  'set-status': function (d) { var a = getAct(d.id); if (a) setStatus(a, d.v); },
  'focus-act': function (d) { var a = getAct(d.id); if (a) focusAct(a); },
  'act-grade': function (d) { var a = getAct(d.id); if (a) gradeForActForm(a); },

  'new-grade': function (d) { var s = getSub(d.sub); if (s) gradeForm(s, null); },
  'edit-grade': function (d) { var s = getSub(d.sub); if (!s) return; var g = find(s.grades, function (x) { return x.id === d.id; }); if (g) gradeForm(s, g); },
  'delete-grade': function (d) {
    var s = getSub(d.sub); if (!s) return;
    var snap = snapshot();
    s.grades = s.grades.filter(function (x) { return x.id !== d.id; });
    closeAllSheets(); save(); render(); renderMini();
    toast('Calificación eliminada', function () { restore(snap); });
  },

  'new-note': function (d) { noteForm(null, d.sub); },
  'edit-note': function (d) { var n = getNote(d.id); if (n) noteForm(n); },
  'delete-note': function (d) {
    var n = getNote(d.id); if (!n) return;
    var snap = snapshot();
    closeAllSheets(); FORM = null;
    S.notes = S.notes.filter(function (x) { return x.id !== d.id; });
    save(); render(); scheduleFileDelete(n.files);
    toast('Apunte eliminado', function () { restore(snap); });
  },

  'new-class': function (d) { classForm(null, { day: d.day ? +d.day : undefined, subjectId: d.sub }); },
  'edit-class': function (d) { var c = getClass(d.id); if (c) classForm(c); },
  'delete-class': function (d) {
    var snap = snapshot();
    S.classes = S.classes.filter(function (x) { return x.id !== d.id; });
    closeAllSheets(); save(); render(); renderMini();
    toast('Clase quitada del horario', function () { restore(snap); });
  },

  'task-filter': function (d) { curEntry().f = d.v; curPageEl.scrollTop = 0; render(); haptic(0); },

  'cal-mode': function (d) { var e = curEntry(); e.mode = d.v; render(); haptic(0); },
  'cal-prev': function () { calShift(-1); },
  'cal-next': function () { calShift(1); },
  'cal-today': function () { var e = curEntry(); e.m = null; e.sel = ymd(new Date()); render(); },
  'cal-sel': function (d) {
    var e = curEntry(), dt = pymd(d.d), m0 = e.m ? pymd(e.m) : null;
    e.sel = d.d;
    if (!m0 || m0.getMonth() !== dt.getMonth() || m0.getFullYear() !== dt.getFullYear()) e.m = ymd(new Date(dt.getFullYear(), dt.getMonth(), 1));
    render(); haptic(0);
  },
  'cal-add': function () {
    var e = curEntry();
    if (e.mode === 'horario') classForm(null, { day: e.hd });
    else quickAdd(e.mode === 'semana' ? undefined : (e.sel || ymd(new Date())));
  },
  'wk-prev': function () { var e = curEntry(); e.w = ymd(addDays(e.w ? pymd(e.w) : monday(new Date()), -7)); render(); },
  'wk-next': function () { var e = curEntry(); e.w = ymd(addDays(e.w ? pymd(e.w) : monday(new Date()), 7)); render(); },
  'wk-today': function () { curEntry().w = null; render(); },
  'hz-day': function (d) { curEntry().hd = +d.v; render(); haptic(0); },

  'set-theme': function (d) { S.settings.theme = d.v; save(); applyTheme(); render(); renderChrome(); },
  'set-accent': function (d) { S.settings.accent = d.v; save(); applyTheme(); render(); renderChrome(); haptic(0); },
  'toggle-fx': function () { S.settings.fx = !fxOn(); save(); applyTheme(); render(); },
  'toggle-motion': function () { S.settings.motion = !motionOn(); save(); applyTheme(); render(); },
  'edit-scale': function () { scaleForm(); },
  'set-defmode': function (d) { S.settings.defMode = d.v; save(); render(); },
  'toggle-defrem': function (d) {
    var m = +d.v, arr = S.settings.defRem, i = arr.indexOf(m);
    if (i >= 0) arr.splice(i, 1); else arr.push(m);
    save(); render(); haptic(0);
  },
  'set-classrem': function (d) {
    S.settings.classRem = +d.v; save(); render();
    if (+d.v && Native && nat('canNotify') === false) nat('askNotify');
  },
  'focus-min': function (d) { S.settings.focusMin = +d.m; save(); renderPlayer(); if (curEntry().v === 'profile') render(); haptic(0); },
  'notif-perm': function () { if (nat('canNotify')) toast('Las notificaciones ya están activadas'); else nat('askNotify'); },
  'test-notif': function () { if (nat('canNotify') === false) { nat('askNotify'); return; } nat('testNotify'); toast('Notificación enviada'); },
  'export': function () {
    flush();
    if (!Native) { toast('Disponible en la app instalada en el celular'); return; }
    nat('exportBackup', JSON.stringify(S), 'que-pasa-hermano-' + ymd(new Date()) + '.json');
  },
  'import': function () { pick('import', 'import'); },
  'wipe': function () {
    actionSheet('Se borrarán todas tus materias, notas, tareas, apuntes, archivos y el horario. No se puede deshacer.', [{ t: 'Borrar todo', danger: true, fn: function () {
      nat('wipeFiles');
      var keep = S.settings;
      S = defaultState(); S.settings = keep; S.onboarded = false;
      flush(); thumbCache = {};
      initNav(); render('tab'); renderChrome(); showOnboarding();
    } }]);
  },
  'edit-profile': function () { profileForm(); },
  'pick-avatar': function () {
    if (!Native) { profileForm(); return; }
    actionSheet(null, [
      { t: 'Elegir foto', fn: function () { pick('avatar', 'image'); } },
      { t: 'Tomar foto', fn: function () { pick('avatar', 'photo'); } }
    ].concat(S.profile.avatar ? [{ t: 'Quitar foto', danger: true, fn: function () { nat('removeFile', S.profile.avatar); S.profile.avatar = null; save(); render(); renderChrome(); } }] : []));
  },

  'open-player': function () { openPlayer(); },
  'close-player': function () { closePlayer(); },
  'focus-toggle': function () { focusToggle(); },
  'focus-stop': function () { focusStop(false); },
  'mini-next': function () { if (!S.focus) miniStep(1); },
  'mini-prev': function () { if (!S.focus) miniStep(-1); },
  'mini-sel': function (d) { MINI.sel = d.key; renderMini(); renderPlayer(); haptic(0); },
  'pl-complete': function (d) { var a = getAct(d.id); if (a) { setStatus(a, 'completada'); MINI.sel = null; renderMini(); renderPlayer(); } },
  'pl-open': function (d) { closePlayer(); setTimeout(function () { pushHere({ v: 'act', id: d.id }); }, 80); },
  'pl-sub': function (d) { closePlayer(); setTimeout(function () { pushHere({ v: 'subject', id: d.id }); }, 80); },
  'pl-note': function (d) { closePlayer(); setTimeout(function () { noteForm(null, d.id); }, 200); },

  'attach': function (d) { pick(d.tag, d.mode); },
  'open-file': function (d) {
    var f = findFile(d.id); if (!f) return;
    if (!Native) { toast('Disponible en la app instalada en el celular'); return; }
    if (nat('openFile', f.id, f.mime || '', f.name || 'archivo') === false) toast('No hay una app para abrir este archivo');
  },
  'remove-file': function (d) {
    if (!FORM) return;
    FORM.files = FORM.files.filter(function (f) { return f.id !== d.id; });
    var added = find(FORM.added, function (f) { return f.id === d.id; });
    if (added) { FORM.added = FORM.added.filter(function (f) { return f.id !== d.id; }); nat('removeFile', d.id); }
    else FORM.removed.push(d.id);
    FORM.refresh(); haptic(0);
  },

  'onb-start': function () {
    var n = $('#onb_name'); S.profile.name = n ? n.value.trim() : '';
    S.onboarded = true; save(); hideOnboarding(); render(); renderChrome();
  },
  'onb-demo': function () {
    var n = $('#onb_name'), name = n ? n.value.trim() : '';
    S = seedState({ profile: Object.assign({}, S.profile, { name: name }), settings: S.settings });
    save(); hideOnboarding(); initNav(); render('tab'); renderChrome();
  }
};
function calShift(d) {
  var e = curEntry(), base = e.m ? pymd(e.m) : (function () { var s = pymd(e.sel || ymd(new Date())); return new Date(s.getFullYear(), s.getMonth(), 1); })();
  var m = new Date(base.getFullYear(), base.getMonth() + d, 1);
  e.m = ymd(m);
  var t = new Date();
  e.sel = (m.getMonth() === t.getMonth() && m.getFullYear() === t.getFullYear()) ? ymd(t) : ymd(m);
  render(); haptic(0);
}
function runAction(a, d, el, ev) {
  var fn = ACTIONS[a];
  if (fn) fn(d || {}, el, ev);
}

/* ---------- eventos globales ---------- */
document.addEventListener('click', function (e) {
  var t = e.target;
  if (!t || !t.closest) return;
  var sv = t.closest('[data-segv]');
  if (sv) {
    var seg = sv.parentNode;
    $$('button', seg).forEach(function (b) { b.classList.toggle('on', b === sv); });
    seg.setAttribute('data-val', sv.getAttribute('data-segv'));
    seg.dispatchEvent(new CustomEvent('segchange', { bubbles: true }));
    haptic(0); return;
  }
  var cv = t.closest('[data-chipv]');
  if (cv) { cv.classList.toggle('on'); haptic(0); return; }
  var cl = t.closest('[data-clear]');
  if (cl) { e.preventDefault(); var inp = document.getElementById(cl.getAttribute('data-clear')); if (inp) inp.value = ''; return; }
  var el = t.closest('[data-a]');
  if (!el) return;
  if (el.tagName === 'LABEL') return;
  e.preventDefault();
  e.stopPropagation();
  runAction(el.getAttribute('data-a'), el.dataset, el, e);
}, false);

var lastTouch = 0;
document.addEventListener('touchstart', function () { lastTouch = Date.now(); }, { passive: true });

/* ---------- bienvenida ---------- */
function showOnboarding() {
  if ($('.onb')) return;
  var el = document.createElement('div');
  el.className = 'onb';
  el.innerHTML = appIcon(96) + '<h1>Que Pasa Hermano</h1><p>Tus clases, tareas, exámenes y notas, en un solo lugar.</p>' +
    '<div class="feat"><div>' + icon('grade', 28) + '<span><b>Cuánto necesitas para pasar</b>Por porcentajes o con notas que valen igual.</span></div>' +
    '<div>' + icon('bell', 28) + '<span><b>Recordatorios</b>Antes de cada examen, entrega o clase.</span></div>' +
    '<div>' + icon('calendar', 28) + '<span><b>Horario y calendario</b>Siempre sabes qué clase sigue.</span></div></div>' +
    '<input id="onb_name" type="text" placeholder="¿Cómo te llamas?" autocomplete="given-name">' +
    '<button class="pill solid tap" data-a="onb-start">Empezar</button><button class="lnk" data-a="onb-demo">Explorar con datos de ejemplo</button>';
  document.body.appendChild(el);
}
function hideOnboarding() {
  var el = $('.onb'); if (!el) return;
  if (document.activeElement) document.activeElement.blur();
  el.classList.add('out');
  setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 500);
}

/* ---------- llamadas desde Android ---------- */
window.__insets = function (top, bottom) {
  var r = document.documentElement.style;
  r.setProperty('--sat', Math.max(0, top) + 'px');
  r.setProperty('--sab', Math.max(0, bottom) + 'px');
};
window.__back = function () {
  if (LAYERS.length) { closeTopLayer(); return true; }
  if ($('.onb')) return false;
  if (pop()) return true;
  if (NAV.tab !== 'inicio') { switchTab('inicio'); return true; }
  return false;
};
var lastDay = ymd(new Date());
window.__resume = function () {
  applyTheme();
  lastDay = ymd(new Date());
  render(); renderChrome();
  syncReminders(true);
};
window.__pause = function () { flush(); };
window.__picked = function (tag, json) {
  var files;
  try { files = typeof json === 'string' ? JSON.parse(json) : json; } catch (e) { return; }
  if (!files || !files.length) return;
  if (tag === 'form') {
    if (!FORM) { files.forEach(function (f) { nat('removeFile', f.id); }); return; }
    files.forEach(function (f) { FORM.files.push(f); FORM.added.push(f); });
    FORM.refresh();
  } else if (tag.indexOf('act:') === 0) {
    var a = getAct(tag.slice(4)); if (!a) return;
    a.files = (a.files || []).concat(files); save(); render();
  } else if (tag === 'avatar') {
    var old = S.profile.avatar; S.profile.avatar = files[0].id;
    if (old) nat('removeFile', old);
    save(); render(); renderChrome();
    return;
  }
  toast(files.length === 1 ? 'Archivo agregado' : files.length + ' archivos agregados');
};
window.__toast = function (msg) { toast(msg); };
window.__imported = function (text) {
  var d;
  try { d = JSON.parse(text); } catch (e) { toast('Ese archivo no es una copia válida'); return; }
  if (!d || !Array.isArray(d.subjects) || !Array.isArray(d.acts)) { toast('Ese archivo no es una copia de ' + APP_NAME); return; }
  actionSheet('Esto reemplazará tus datos actuales por los de la copia (' + plural(d.subjects.length, 'materia', 'materias') + ', ' + plural(d.acts.length, 'actividad', 'actividades') + ').', [{ t: 'Restaurar copia', danger: true, fn: function () {
    S = migrate(d); S.onboarded = true; save(); applyTheme(); initNav(); render('tab'); renderChrome(); toast('Copia restaurada');
  } }]);
};
window.__notifPerm = function (granted) {
  toast(granted ? 'Notificaciones activadas' : 'Sin permiso para notificaciones');
  if (curEntry().v === 'profile') render();
  syncReminders(true);
};
window.__sysTheme = function () { if (S.settings.theme === 'auto') { applyTheme(); render(); renderChrome(); } };

/* ---------- arranque ---------- */
function boot() {
  loadState();
  var info = null;
  try { info = JSON.parse(nat('info') || 'null'); } catch (e) { info = null; }
  if (info) {
    DEVICE.sdk = info.sdk || 0;
    DEVICE.lowEnd = !!(info.lowRam || (info.ramMb && info.ramMb < 3000) || (info.sdk && info.sdk < 24));
  } else {
    DEVICE.lowEnd = !!((navigator.deviceMemory && navigator.deviceMemory <= 2) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2));
  }
  var ins = nat('insets');
  if (ins) { var p = String(ins).split(','); window.__insets(+p[0], +p[1]); }
  var q = {};
  location.search.replace(/[?&]([^=&]+)=?([^&]*)/g, function (m, k, v) { q[k] = decodeURIComponent(v); });
  if (!Native) {
    if (q.demo) { S = seedState({ profile: { name: q.name || 'Camila', school: 'I. E. Champagnat', level: 'Grado 11', avatar: null }, settings: S.settings }); }
    if (q.theme) S.settings.theme = q.theme;
    if (q.sat) window.__insets(+q.sat, +(q.sab || 0));
  }
  applyTheme();
  initNav();
  if (q.tab) NAV.tab = q.tab;
  render(); renderChrome();
  if (!S.onboarded) showOnboarding();
  syncReminders(true);
  setInterval(tick, 1000);
  setInterval(function () {
    var today = ymd(new Date());
    if (today !== lastDay) { lastDay = today; render(); renderChrome(); return; }
    var v = curEntry().v;
    if (!LAYERS.length && Date.now() - lastTouch > 3000 && (v === 'home' || v === 'calendar')) render();
  }, 60000);
  var b = $('#boot');
  if (b) setTimeout(function () { b.classList.add('out'); setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); }, 400); }, 120);
}
