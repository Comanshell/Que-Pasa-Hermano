/* Que Pasa Hermano — componentes, navegación, mini panel y reproductor. */
'use strict';

/* ---------- íconos ---------- */
var IC = {
  home: '<path d="M3.5 10.6 12 3.6l8.5 7V19.5a1.5 1.5 0 0 1-1.5 1.5h-4v-6.5h-6V21H5a1.5 1.5 0 0 1-1.5-1.5z"/>',
  stack: '<rect x="3.5" y="7.5" width="13" height="13" rx="2.6"/><path d="M7.5 4h10a3 3 0 0 1 3 3v10"/>',
  tasks: '<path d="M3.8 6.3 5.4 8 8.6 4.6M3.8 12.8l1.6 1.7 3.2-3.4M3.8 19.3 5.4 21l3.2-3.4M12 6.5h8.5M12 13h8.5M12 19.5h8.5"/>',
  calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.8"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  person: '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5c.9-3.9 3.9-6 7.5-6s6.6 2.1 7.5 6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  chev_r: '<path d="M9.5 5.5 16 12l-6.5 6.5"/>',
  chev_l: '<path d="M15 4.5 7.5 12l7.5 7.5"/>',
  chev_d: '<path d="M5.5 9 12 15.5 18.5 9"/>',
  more: '<circle cx="5.5" cy="12" r="1.7" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.7" fill="currentColor" stroke="none"/><circle cx="18.5" cy="12" r="1.7" fill="currentColor" stroke="none"/>',
  play: '<path d="M7 4.9v14.2a.9.9 0 0 0 1.4.8l11.2-7.1a.9.9 0 0 0 0-1.6L8.4 4.1A.9.9 0 0 0 7 4.9z" fill="currentColor" stroke="none"/>',
  pause: '<rect x="6" y="4.5" width="4.2" height="15" rx="1.2" fill="currentColor" stroke="none"/><rect x="13.8" y="4.5" width="4.2" height="15" rx="1.2" fill="currentColor" stroke="none"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2.5" fill="currentColor" stroke="none"/>',
  fwd: '<path d="M2.5 6.3v11.4a.8.8 0 0 0 1.2.7l8.2-5.7a.8.8 0 0 0 0-1.4L3.7 5.6a.8.8 0 0 0-1.2.7zM12 6.3v11.4a.8.8 0 0 0 1.2.7l8.2-5.7a.8.8 0 0 0 0-1.4l-8.2-5.7a.8.8 0 0 0-1.2.7z" fill="currentColor" stroke="none"/>',
  rew: '<path d="M21.5 6.3v11.4a.8.8 0 0 1-1.2.7l-8.2-5.7a.8.8 0 0 1 0-1.4l8.2-5.7a.8.8 0 0 1 1.2.7zM12 6.3v11.4a.8.8 0 0 1-1.2.7l-8.2-5.7a.8.8 0 0 1 0-1.4l8.2-5.7a.8.8 0 0 1 1.2.7z" fill="currentColor" stroke="none"/>',
  check: '<path d="M5 12.5 10 17.5 19.5 7"/>',
  circle: '<circle cx="12" cy="12" r="9"/>',
  half: '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor"/>',
  checkc: '<circle cx="12" cy="12" r="10" fill="currentColor" stroke="none"/><path d="M7.4 12.4l3 3 6.2-6.4" style="stroke:var(--bg)"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  clip: '<path d="M20 11.4l-7.9 7.9a5 5 0 0 1-7.1-7.1l8.3-8.3a3.4 3.4 0 0 1 4.8 4.8l-8.2 8.2a1.7 1.7 0 0 1-2.4-2.4l7.4-7.4"/>',
  camera: '<path d="M3.5 8.5a2 2 0 0 1 2-2h2l1.6-2h5.8l1.6 2h2a2 2 0 0 1 2 2v9.5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="3.6"/>',
  doc: '<path d="M6.5 3h7l4.5 4.5V19a2 2 0 0 1-2 2H6.5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M13.5 3v4.5H18M8.5 13h7M8.5 16.5h5"/>',
  trash: '<path d="M4 6.5h16M9.5 6.5V4.5h5v2M6 6.5l1 13a1.5 1.5 0 0 0 1.5 1.4h7a1.5 1.5 0 0 0 1.5-1.4l1-13M10 10.5v6M14 10.5v6"/>',
  bell: '<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2h-15z"/><path d="M10 20.5a2.2 2.2 0 0 0 4 0"/>',
  pencil: '<path d="M4 20l1-4.5L15.5 5a2.1 2.1 0 0 1 3 3L8 18.5z"/><path d="M13.5 7l3 3"/>',
  x: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
  note: '<rect x="4.5" y="3.5" width="15" height="17" rx="2.5"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  timer: '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 9.5v4l2.6 1.6M9.5 3h5"/>',
  share: '<path d="M12 14.5V3.5M7.5 8 12 3.5 16.5 8"/><path d="M5 12v7a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 19v-7"/>',
  download: '<path d="M12 3.5v11M7.5 10.5 12 15l4.5-4.5"/><path d="M5 17v2a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 19v-2"/>',
  sparkle: '<path d="M12 3.5l1.9 5.1 5.1 1.9-5.1 1.9L12 17.5l-1.9-5.1L5 10.5l5.1-1.9z"/><path d="M18.5 16v4M16.5 18h4"/>',
  grade: '<path d="M2.5 9 12 4.5 21.5 9 12 13.5z"/><path d="M6.5 11v4.5c1.6 1.5 3.6 2.4 5.5 2.4s3.9-.9 5.5-2.4V11M21.5 9v5"/>',
  pin: '<path d="M12 21s-6.5-6-6.5-11a6.5 6.5 0 0 1 13 0c0 5-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6 6 6M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4"/>',
  flag: '<path d="M5.5 21V4M5.5 4.5h11l-2 4 2 4h-11"/>',
  calplus: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.8"/><path d="M3.5 10h17M8 3v4M16 3v4M12 13v5M9.5 15.5h5"/>'
};
function icon(name, size, cls) {
  size = size || 24;
  return '<svg class="ic ' + (cls || '') + '" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || '') + '</svg>';
}

/* ---------- glifos de materias ---------- */
var GLYPH = {
  atom: '<circle cx="12" cy="12" r="1.7" fill="currentColor" stroke="none"/><ellipse cx="12" cy="12" rx="10" ry="4"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(120 12 12)"/>',
  flask: '<path d="M9 3h6M10 3v6.2L4.6 18.8A1.5 1.5 0 0 0 5.9 21h12.2a1.5 1.5 0 0 0 1.3-2.2L14 9.2V3"/><path d="M7.2 15h9.6"/>',
  book: '<path d="M2.5 5.5C5 4 8.3 4.1 12 6c3.7-1.9 7-2 9.5-.5V19c-2.5-1.5-5.8-1.4-9.5.5-3.7-1.9-7-2-9.5-.5z"/><path d="M12 6v13.5"/>',
  globe: '<circle cx="12" cy="12" r="9.5"/><path d="M2.5 12h19M12 2.5c2.7 2.9 4 6 4 9.5s-1.3 6.6-4 9.5c-2.7-2.9-4-6-4-9.5s1.3-6.6 4-9.5z"/>',
  sigma: '<path d="M18 5H6.5l6 7-6 7H18"/>',
  pi: '<path d="M4 7.5h16M9 7.5V19M15 7.5v9.2c0 1.4.9 2.3 2.4 2.3"/>',
  palette: '<path d="M12 2.5a9.5 9.5 0 1 0 0 19c1.4 0 2-1 2-2 0-1.5-1.2-2-1.2-3.2 0-1.2 1-2 2.2-2H17a4.5 4.5 0 0 0 4.5-4.5C21.5 6 17.3 2.5 12 2.5z"/><circle cx="7.5" cy="11" r="1.2" fill="currentColor"/><circle cx="10" cy="7" r="1.2" fill="currentColor"/><circle cx="15" cy="7.5" r="1.2" fill="currentColor"/>',
  music: '<path d="M9 18V5.5l11-2.2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16.3" r="3"/>',
  ball: '<circle cx="12" cy="12" r="9.5"/><path d="M12 2.5v19M2.5 12h19M5.6 5c3 2.6 3 11.4 0 14M18.4 5c-3 2.6-3 11.4 0 14"/>',
  code: '<path d="M8 7l-5 5 5 5M16 7l5 5-5 5M13.8 4l-3.6 16"/>',
  leaf: '<path d="M5 19C5 10 10.5 4 20 4c0 9.6-6 15-15 15z"/><path d="M5 19l8.5-8.5"/>',
  pen: '<path d="M4 20l1.2-5L16 4.2l3.8 3.8L9 18.8z"/><path d="M13.8 6.4l3.8 3.8"/>',
  lang: '<path d="M2.8 19 7.6 5l4.8 14M4.6 14.2h6"/><circle cx="17.6" cy="15.6" r="3.3"/><path d="M20.9 12v7"/>',
  landmark: '<path d="M3 21h18M4 9.5h16M12 3l9 5H3z"/><path d="M6 9.5v8.5M10 9.5v8.5M14 9.5v8.5M18 9.5v8.5"/>',
  dna: '<path d="M7 2.5c0 7.4 10 7.4 10 14.8M17 2.5c0 7.4-10 7.4-10 14.8M7 21.5c0-1.5.6-2.8 1.6-3.8M17 21.5c0-1.5-.6-2.8-1.6-3.8M8.6 6.2h6.8M8.6 13.6h6.8"/>',
  calc: '<rect x="5" y="2.5" width="14" height="19" rx="2.5"/><path d="M8.2 6.5h7.6"/><path d="M8.6 11.5h.01M12 11.5h.01M15.4 11.5h.01M8.6 15h.01M12 15h.01M15.4 15h.01M8.6 18.5h.01M12 18.5h.01M15.4 18.5h.01" stroke-width="2.4"/>',
  scales: '<path d="M12 3.5v17M7.5 20.5h9M4.5 7h15M6.5 7 3.5 13.5a3 3 0 0 0 6 0zM17.5 7l-3 6.5a3 3 0 0 0 6 0z"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9.5" y="9.5" width="5" height="5" rx=".5"/><path d="M9 2.5V6M15 2.5V6M9 18v3.5M15 18v3.5M2.5 9H6M2.5 15H6M18 9h3.5M18 15h3.5"/>'
};
var GLYPH_ORDER = ['book', 'sigma', 'pi', 'atom', 'flask', 'leaf', 'dna', 'lang', 'globe', 'landmark', 'palette', 'music', 'ball', 'code', 'cpu', 'pen', 'scales', 'calc'];
function glyphSvg(name, cls, sw) {
  return '<svg class="' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (sw || 1.8) + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (GLYPH[name] || GLYPH.book) + '</svg>';
}

/* Arte de portada: color plano + composición geométrica según la materia */
function coverArt(sub) {
  var g = GLYPH[sub.glyph] || GLYPH.book, h = hashStr(sub.id || sub.name) % 4, a = '';
  var gs = function (tx, ty, s, op, sw) {
    return '<g transform="translate(' + tx + ' ' + ty + ') scale(' + s + ')" fill="none" stroke="#fff" stroke-opacity="' + op + '" stroke-width="' + sw + '" stroke-linecap="round" stroke-linejoin="round" style="color:#fff">' + g + '</g>';
  };
  if (h === 0) a = gs(38, 6, 3.3, 0.3, 1.25) + gs(10, 10, 0.95, 0.95, 1.9);
  else if (h === 1) a = '<g fill="none" stroke="#fff" stroke-opacity=".16" stroke-width="1"><circle cx="74" cy="30" r="13"/><circle cx="74" cy="30" r="25"/><circle cx="74" cy="30" r="37"/><circle cx="74" cy="30" r="49"/><circle cx="74" cy="30" r="61"/></g>' + gs(63, 19, 0.92, 0.95, 1.9);
  else if (h === 2) a = '<path d="M-5 72 72 -5h22L-5 94z" fill="#000" fill-opacity=".13"/><path d="M40 105 105 40v24l-41 41z" fill="#fff" fill-opacity=".1"/>' + gs(66, 10, 1, 0.95, 1.9);
  else a = '<g fill="#fff" fill-opacity=".2">' + dots() + '</g>' + gs(40, 26, 2.6, 0.55, 1.4);
  return '<svg class="art" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' + a + '</svg>';
}
var _dots = null;
function dots() {
  if (_dots) return _dots;
  var s = '';
  for (var y = 5; y < 100; y += 9) for (var x = 5; x < 100; x += 9) s += '<circle cx="' + x + '" cy="' + y + '" r=".9"/>';
  return (_dots = s);
}
function cover(sub, size, extra) {
  size = size || 'm';
  if (!sub) return '<div class="cover cv-' + size + ' none">' + (size === 's' ? glyphSvg('book', 'gl') : '<div class="gl" style="position:absolute;top:30%;left:30%;width:40%;height:40%">' + icon('calendar', '100%') + '</div>') + (extra || '') + '</div>';
  if (size === 's') return '<div class="cover cv-s" style="background-color:' + sub.color + '"><div class="hl"></div>' + glyphSvg(sub.glyph, 'gl', 2) + (extra || '') + '</div>';
  var title = (size === 'm' || size === 'l') ? '<div class="ct">' + esc(sub.name) + '</div>' : '';
  return '<div class="cover cv-' + size + '" style="background-color:' + sub.color + '">' + coverArt(sub) + '<div class="hl"></div>' + title + (extra || '') + '</div>';
}
function eventCover(size) {
  return '<div class="cover cv-' + (size || 's') + ' none" style="background-color:var(--accent)"><div class="hl"></div>' +
    '<svg class="gl" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + IC.calendar + '</svg></div>';
}
function actCover(a, size) { var sub = getSub(a.subjectId); return sub ? cover(sub, size) : eventCover(size); }

/* ---------- componentes ---------- */
function prioMarks(p) { p = +p || 0; if (!p) return ''; return '<span class="prio p' + p + '">' + (p === 3 ? '!!!' : p === 2 ? '!!' : '!') + '</span>'; }
function statusIcon(st) { return icon(st === 'completada' ? 'checkc' : st === 'proceso' ? 'half' : 'circle', 26); }
function empty(ic, title, text, btn) {
  return '<div class="empty"><div class="eic">' + (GLYPH[ic] ? glyphSvg(ic, '', 1.4).replace('<svg ', '<svg width="56" height="56" ') : icon(ic, 56)) + '</div><h3>' + title + '</h3><p>' + text + '</p>' + (btn || '') + '</div>';
}
function secHead(title, action, link) {
  var inner = '<h2>' + title + '</h2>' + (action ? icon('chev_r', 22, 'chev') : '');
  return '<div class="sec-h">' + (action ? '<button class="tap" style="display:flex;align-items:center" ' + action + '>' + inner + '</button>' : inner) + '<span class="sp"></span>' + (link || '') + '</div>';
}
function avatarHtml(cls) {
  var p = S.profile, ini = (p.name || '').trim().split(/\s+/).map(function (w) { return w.charAt(0); }).join('').slice(0, 2).toUpperCase();
  var img = p.avatar ? thumbUrl(p.avatar) : '';
  return '<span class="avatar ' + (cls || '') + '">' + (img ? '<img src="' + img + '" alt="">' : (ini || icon('person', cls === 'sm' ? 20 : 48))) + '</span>';
}

/* ---------- archivos y miniaturas ---------- */
var thumbCache = {};
function thumbUrl(id) {
  if (thumbCache[id] !== undefined) return thumbCache[id];
  var u = nat('thumb', id);
  thumbCache[id] = u || '';
  return thumbCache[id];
}
function isImage(f) { return /^image\//.test(f.mime || '') || /\.(jpe?g|png|webp|gif|heic)$/i.test(f.name || ''); }
function fmtSize(b) { if (!b) return ''; if (b < 1024) return b + ' B'; if (b < 1048576) return Math.round(b / 1024) + ' KB'; return (b / 1048576).toFixed(1) + ' MB'; }
function fileTile(f, removable) {
  var img = isImage(f) ? thumbUrl(f.id) : '';
  return '<button class="file tap" data-a="open-file" data-id="' + esc(f.id) + '">' +
    (img ? '<img src="' + img + '" alt="">' : '<span class="fi">' + icon('doc', 26) + '<span class="fn">' + esc(f.name) + '<br><span style="color:var(--label2)">' + fmtSize(f.size) + '</span></span></span>') +
    (removable ? '<span class="x" data-a="remove-file" data-id="' + esc(f.id) + '">' + icon('x', 14) + '</span>' : '') + '</button>';
}
function findFile(id) {
  var all = [];
  S.acts.forEach(function (a) { all = all.concat(a.files || []); });
  S.notes.forEach(function (n) { all = all.concat(n.files || []); });
  if (FORM && FORM.files) all = all.concat(FORM.files);
  return find(all, function (f) { return f.id === id; });
}

/* ---------- capas: hojas, menús y avisos ---------- */
var LAYERS = [];
function openSheet(o) {
  var wrap = document.createElement('div');
  wrap.className = 'sheet-wrap';
  wrap.innerHTML = '<div class="scrim"></div><div class="sheet' + (o.full ? ' full' : '') + '" role="dialog" aria-label="' + esc(o.title || '') + '">' +
    '<div class="grabber"></div><div class="sh-head"><button class="sh-btn" data-sh="cancel">' + (o.cancelLabel || 'Cancelar') + '</button>' +
    '<div class="sh-title">' + esc(o.title || '') + '</div>' +
    (o.onSave ? '<button class="sh-btn strong" data-sh="save">' + (o.saveLabel || 'Guardar') + '</button>' : '<span class="sh-btn"></span>') +
    '</div><div class="sh-body">' + o.body + '</div></div>';
  document.body.appendChild(wrap);
  var layer = { el: wrap, o: o, type: 'sheet' };
  LAYERS.push(layer);
  var body = $('.sh-body', wrap), sheet = $('.sheet', wrap);
  $('.scrim', wrap).addEventListener('click', function () { cancelLayer(layer); });
  $('[data-sh=cancel]', wrap).addEventListener('click', function () { cancelLayer(layer); });
  var sv = $('[data-sh=save]', wrap);
  if (sv) sv.addEventListener('click', function () {
    var r = o.onSave(body, layer);
    if (r !== false) { haptic(1); closeLayer(layer); }
  });
  dragToClose(sheet, $('.sh-head', wrap), $('.grabber', wrap), function () { cancelLayer(layer); });
  wrap.offsetWidth; // fuerza el estilo inicial
  requestAnimationFrame(function () { wrap.classList.add('open'); });
  if (o.onMount) o.onMount(body, layer);
  return layer;
}
function dragToClose(sheet, head, grab, onClose) {
  var y0 = null, dy = 0;
  function start(e) { if (e.target.closest && e.target.closest('button')) return; y0 = e.touches[0].clientY; dy = 0; sheet.classList.add('drag'); }
  function move(e) { if (y0 === null) return; dy = Math.max(0, e.touches[0].clientY - y0); sheet.style.transform = 'translate3d(0,' + dy + 'px,0)'; }
  function end() {
    if (y0 === null) return; y0 = null; sheet.classList.remove('drag'); sheet.style.transform = '';
    if (dy > 110) onClose();
  }
  [head, grab].forEach(function (el) {
    if (!el) return;
    el.addEventListener('touchstart', start, { passive: true });
    el.addEventListener('touchmove', move, { passive: true });
    el.addEventListener('touchend', end);
  });
}
function cancelLayer(layer) { if (layer.o && layer.o.onCancel) layer.o.onCancel(); closeLayer(layer); }
function closeLayer(layer) {
  var i = LAYERS.indexOf(layer);
  if (i >= 0) LAYERS.splice(i, 1);
  layer.el.classList.remove('open');
  if (layer.o && layer.o.onClose) layer.o.onClose();
  setTimeout(function () { if (layer.el.parentNode) layer.el.parentNode.removeChild(layer.el); }, 430);
}
function closeTopLayer() {
  var l = LAYERS[LAYERS.length - 1];
  if (!l) return false;
  cancelLayer(l);
  return true;
}
function closeAllSheets() { while (LAYERS.length) closeLayer(LAYERS[LAYERS.length - 1]); }

function actionSheet(title, items) {
  var wrap = document.createElement('div');
  wrap.className = 'as-wrap';
  var html = '<div class="scrim"></div><div class="as"><div class="as-g">' + (title ? '<div class="as-t">' + title + '</div>' : '');
  items.forEach(function (it, i) { html += '<button class="as-b' + (it.danger ? ' danger' : '') + '" data-i="' + i + '">' + esc(it.t) + '</button>'; });
  html += '</div><div class="as-g"><button class="as-b cancel" data-i="-1">Cancelar</button></div></div>';
  wrap.innerHTML = html;
  document.body.appendChild(wrap);
  var layer = { el: wrap, o: {}, type: 'as' };
  LAYERS.push(layer);
  wrap.addEventListener('click', function (e) {
    var b = e.target.closest('[data-i]');
    if (!b && !e.target.classList.contains('scrim')) return;
    closeLayer(layer);
    var i = b ? +b.getAttribute('data-i') : -1;
    if (i >= 0 && items[i].fn) setTimeout(items[i].fn, 120);
  });
  requestAnimationFrame(function () { wrap.classList.add('open'); });
}

var toastEl = null, toastTimer = null;
function toast(msg, undo) {
  if (!toastEl) { toastEl = document.createElement('div'); toastEl.className = 'toast'; document.body.appendChild(toastEl); }
  toastEl.className = 'toast' + (undo ? '' : ' noundo');
  toastEl.innerHTML = '<span class="tm">' + esc(msg) + '</span>' + (undo ? '<button class="tu">Deshacer</button>' : '');
  if (undo) $('.tu', toastEl).onclick = function () { hideToast(); undo(); haptic(1); };
  requestAnimationFrame(function () { toastEl.classList.add('show'); });
  clearTimeout(toastTimer);
  toastTimer = setTimeout(hideToast, undo ? 4500 : 2600);
}
function hideToast() { if (toastEl) toastEl.classList.remove('show'); }

function haptic(k) { nat('haptic', k || 0); }

/* deshacer: guarda una copia del estado antes de una acción */
function snapshot() { return JSON.stringify(S); }
function restore(snap) { S = migrate(JSON.parse(snap)); save(); render(); renderChrome(); }

/* ---------- navegación ---------- */
var TABS = [
  { id: 'inicio', t: 'Inicio', ic: 'home', root: { v: 'home' } },
  { id: 'materias', t: 'Materias', ic: 'stack', root: { v: 'subjects' } },
  { id: 'tareas', t: 'Tareas', ic: 'tasks', root: { v: 'tasks' } },
  { id: 'calendario', t: 'Calendario', ic: 'calendar', root: { v: 'calendar' } },
  { id: 'perfil', t: 'Perfil', ic: 'person', root: { v: 'profile' } }
];
var NAV = { tab: 'inicio', stacks: {} };
function initNav() { TABS.forEach(function (t) { NAV.stacks[t.id] = [Object.assign({}, t.root)]; }); }
function curEntry() { var s = NAV.stacks[NAV.tab]; return s[s.length - 1]; }
var curPageEl = null, curEntryRef = null;

function saveScroll() { if (curPageEl && curEntryRef) curEntryRef.scroll = curPageEl.scrollTop; }
function push(entry) { saveScroll(); NAV.stacks[NAV.tab].push(entry); render('push'); haptic(0); }
function pop() {
  var s = NAV.stacks[NAV.tab];
  if (s.length > 1) { s.pop(); render('pop'); return true; }
  return false;
}
function switchTab(id) {
  if (id === NAV.tab) {
    var s = NAV.stacks[id];
    if (s.length > 1) { s.length = 1; render('pop'); }
    else if (curPageEl) scrollTop(curPageEl);
    return;
  }
  saveScroll(); NAV.tab = id; render('tab'); renderTabbar(); haptic(0);
}
function scrollTop(el) {
  if (el.scrollTo) { try { el.scrollTo({ top: 0, behavior: 'smooth' }); return; } catch (e) { } }
  el.scrollTop = 0;
}

function pageHtml(out) {
  var nb = '<div class="navbar' + (out.solid ? ' solid' : '') + '"><div class="nb-bg"></div>' +
    '<div class="nb-l">' + (out.back ? '<button class="nb-back" data-a="back">' + icon('chev_l', 26) + '<span>' + esc(out.back) + '</span></button>' : '') + '</div>' +
    '<div class="nb-title">' + esc(out.title || '') + '</div><div class="nb-r">' + (out.right || '') + '</div></div>';
  var head = out.head !== undefined ? out.head : (out.large !== false ? '<h1 class="large-title">' + esc(out.title) + '</h1>' : '');
  return nb + '<div class="page-in">' + head + out.html + '</div><div class="page-end"></div>';
}
function onPageScroll(e) {
  var el = e.currentTarget, nb = el.firstElementChild;
  if (!nb) return;
  var on = el.scrollTop > (el.getAttribute('data-th') ? +el.getAttribute('data-th') : 30);
  if (on !== nb.classList.contains('scrolled')) nb.classList.toggle('scrolled', on);
}

function render(mode) {
  var entry = curEntry(), fn = VIEWS[entry.v];
  if (!fn) { entry = NAV.stacks[NAV.tab][0]; fn = VIEWS[entry.v]; }
  var out = fn(entry);
  if (out === null) { NAV.stacks[NAV.tab].pop(); return render(mode); }
  var html = pageHtml(out);
  if (!mode && curPageEl && curEntryRef === entry) {
    var st = curPageEl.scrollTop;
    curPageEl.innerHTML = html;
    curPageEl.scrollTop = st;
    curPageEl.setAttribute('data-th', out.th || 30);
    onPageScroll({ currentTarget: curPageEl });
    if (out.after) out.after(curPageEl);
    return;
  }
  var stage = $('#stage'), old = curPageEl;
  var el = document.createElement('div');
  el.className = 'page';
  el.innerHTML = html;
  el.setAttribute('data-th', out.th || 30);
  el.addEventListener('scroll', onPageScroll, { passive: true });
  stage.appendChild(el);
  el.scrollTop = entry.scroll || 0;
  onPageScroll({ currentTarget: el });
  if (out.after) out.after(el);
  curPageEl = el; curEntryRef = entry;
  if (!old) return;
  if (!motionOn() || !mode) { old.parentNode.removeChild(old); return; }
  var a1, a2, top;
  if (mode === 'push') { el.classList.add('from-right', 'top'); a1 = 'to-left'; top = el; }
  else if (mode === 'pop') { el.classList.add('from-left'); old.classList.add('top'); a1 = 'to-right'; top = old; }
  else { el.classList.add('fade', 'top'); a1 = null; top = el; }
  el.offsetWidth;
  el.classList.add('anim'); old.classList.add('anim');
  requestAnimationFrame(function () {
    el.classList.remove('from-right', 'from-left', 'fade');
    if (mode === 'push') old.classList.add('to-left');
    else if (mode === 'pop') old.classList.add('to-right');
    else old.style.opacity = '0';
  });
  setTimeout(function () {
    if (old.parentNode) old.parentNode.removeChild(old);
    el.classList.remove('anim', 'top');
  }, mode === 'tab' ? 260 : 440);
}
function refresh() { render(); renderChrome(); }

/* ---------- barra de pestañas ---------- */
function renderTabbar() {
  var tb = $('#tabbar');
  if (!tb.childElementCount) {
    tb.innerHTML = TABS.map(function (t) {
      return '<button class="tab" data-a="tab" data-tab="' + t.id + '" aria-label="' + t.t + '">' + icon(t.ic, 25) + '<span>' + t.t + '</span></button>';
    }).join('');
  }
  $$('.tab', tb).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-tab') === NAV.tab); });
}

/* ---------- mini panel (cola de lo próximo) ---------- */
var MINI = { sel: null, key: '' };
function queue() {
  var now = new Date(), items = [];
  var cc = currentClass(now);
  if (cc && cc.sub) items.push({ key: 'cls:' + cc.c.id + ':' + ymd(cc.start), type: 'class', o: cc, sub: cc.sub, t: cc.start.getTime(), current: true });
  pendingWork().forEach(function (a) {
    items.push({ key: 'act:' + a.id, type: 'act', a: a, sub: getSub(a.subjectId), t: actDue(a).getTime() });
  });
  var nc = nextClass(now);
  if (nc && nc.sub) items.push({ key: 'cls:' + nc.c.id + ':' + ymd(nc.start), type: 'class', o: nc, sub: nc.sub, t: nc.start.getTime(), current: false });
  items.sort(function (a, b) {
    if (a.current) return -1; if (b.current) return 1;
    return a.t - b.t;
  });
  return items.slice(0, 15);
}
function itemTitle(it) { return it.type === 'class' ? it.sub.name : it.type === 'study' ? it.label : it.a.title; }
function itemSub(it, now) {
  now = now || Date.now();
  if (it.type === 'study') return it.sub.name + ' · Sesión de estudio';
  if (it.type === 'class') {
    var o = it.o;
    if (it.current) return 'En clase · termina en ' + span(o.end - now);
    return 'Clase · ' + relDay(o.start).toLowerCase() + ', ' + fmtTime(o.c.start);
  }
  var a = it.a, name = it.sub ? it.sub.name + ' · ' : '';
  if (isOverdue(a)) return name + 'Atrasada · ' + relDay(pymd(a.date)).toLowerCase();
  return name + (a.kind === 'examen' ? 'Examen ' : 'Entrega ') + countdown(actDue(a) - now);
}
function itemCover(it, size) { return it.type === 'act' ? actCover(it.a, size) : cover(it.sub, size); }
function focusItemKey() { return S.focus ? S.focus.key : null; }
function miniState() {
  var q = queue(), it = null;
  var fk = focusItemKey();
  if (fk) it = find(q, function (x) { return x.key === fk; });
  if (fk && !it) {
    var f = S.focus, fa = f.actId ? getAct(f.actId) : null, fs = getSub(f.subId);
    if (fa) it = { key: fk, type: 'act', a: fa, sub: getSub(fa.subjectId), t: actDue(fa).getTime() };
    else if (fs) it = { key: fk, type: 'study', sub: fs, label: f.label, t: Date.now() };
    if (it) q = [it].concat(q);
  }
  if (!it && MINI.sel) it = find(q, function (x) { return x.key === MINI.sel; });
  if (!it) it = q[0] || null;
  return { q: q, it: it };
}
function focusInfo(now) {
  var f = S.focus; if (!f) return null;
  now = now || Date.now();
  var left = f.running ? f.endAt - now : f.remaining;
  return { left: Math.max(0, left), frac: clamp(1 - left / f.dur, 0, 1), running: f.running };
}
function renderMini() {
  var el = $('#mini'), st = miniState(), it = st.it, now = Date.now();
  var fi = focusInfo(now);
  var key = (it ? it.key : 'none') + '|' + (fi ? (fi.running ? 'r' : 'p') : '') + '|' + S.settings.theme;
  if (key !== MINI.key) {
    MINI.key = key;
    if (!it) {
      el.innerHTML = '<button class="mini-main" data-a="open-player"><div class="mini-cv"><div class="cover cv-s none">' +
        '<svg class="gl" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--green)">' + IC.check + '</svg></div></div>' +
        '<div class="mini-tx"><div class="mini-t">Todo al día</div><div class="mini-s">No tienes pendientes</div></div></button>';
    } else {
      el.innerHTML = '<button class="mini-main" data-a="open-player"><div class="mini-cv">' + itemCover(it, 's') + '</div>' +
        '<div class="mini-tx"><div class="mini-t"></div><div class="mini-s"></div></div></button>' +
        '<button class="mini-btn" data-a="focus-toggle" aria-label="' + (fi && fi.running ? 'Pausar' : 'Estudiar') + '">' + icon(fi && fi.running ? 'pause' : 'play', 26) + '</button>' +
        '<button class="mini-btn" data-a="' + (fi ? 'focus-stop' : 'mini-next') + '" aria-label="' + (fi ? 'Terminar sesión' : 'Siguiente') + '">' + icon(fi ? 'stop' : 'fwd', fi ? 22 : 28) + '</button>' +
        '<div class="mini-prog"><i></i></div>';
    }
  }
  if (!it) return;
  $('.mini-t', el).textContent = itemTitle(it);
  var sub = itemSub(it, now), frac = null;
  if (fi) { sub = (fi.running ? 'Estudiando · ' : 'En pausa · ') + clock(fi.left); frac = fi.frac; }
  else if (it.type === 'class' && it.current) frac = clamp((now - it.o.start) / (it.o.end - it.o.start), 0, 1);
  $('.mini-s', el).textContent = sub;
  var pr = $('.mini-prog', el);
  pr.classList.toggle('on', frac !== null);
  if (frac !== null) $('i', pr).style.width = (frac * 100).toFixed(2) + '%';
}
function renderChrome() { renderTabbar(); renderMini(); if (PLAYER.open) renderPlayer(); }

/* ---------- reproductor expandido ---------- */
var PLAYER = { open: false, el: null, key: '' };
function openPlayer() {
  if (PLAYER.open) return;
  var w = document.createElement('div');
  w.className = 'player-wrap';
  w.innerHTML = '<div class="player"></div>';
  document.body.appendChild(w);
  PLAYER.el = w; PLAYER.open = true; PLAYER.key = '';
  renderPlayer();
  var pl = $('.player', w), y0 = null, dy = 0;
  pl.addEventListener('touchstart', function (e) { if (pl.scrollTop > 0) { y0 = null; return; } y0 = e.touches[0].clientY; dy = 0; }, { passive: true });
  pl.addEventListener('touchmove', function (e) {
    if (y0 === null) return;
    dy = e.touches[0].clientY - y0;
    if (dy > 0 && pl.scrollTop <= 0) { w.classList.add('drag'); w.style.transform = 'translate3d(0,' + dy + 'px,0)'; }
  }, { passive: true });
  pl.addEventListener('touchend', function () {
    if (y0 === null) return; y0 = null; w.classList.remove('drag'); w.style.transform = '';
    if (dy > 140) closePlayer();
  });
  w.offsetWidth;
  requestAnimationFrame(function () { w.classList.add('open'); });
  LAYERS.push({ el: w, o: { onClose: function () { PLAYER.open = false; } }, type: 'player' });
  haptic(0);
}
function closePlayer() {
  var l = find(LAYERS, function (x) { return x.type === 'player'; });
  if (l) closeLayer(l);
  PLAYER.open = false;
}
function renderPlayer() {
  if (!PLAYER.open || !PLAYER.el) return;
  var st = miniState(), it = st.it, now = Date.now(), fi = focusInfo(now);
  var pl = $('.player', PLAYER.el);
  var key = (it ? it.key : 'none') + '|' + (fi ? (fi.running ? 'r' : 'p') : '') + '|' + st.q.length + '|' + S.settings.focusMin;
  if (key !== PLAYER.key) {
    PLAYER.key = key;
    if (!it) {
      pl.innerHTML = '<div class="pl-bg" style="background:#1c1c1e"><div class="dim"></div></div><div class="pl-in"><button class="pl-grab" data-a="close-player" aria-label="Cerrar"></button>' +
        '<div class="empty" style="color:#fff;padding-top:120px"><div class="eic" style="color:var(--green)">' + icon('check', 64) + '</div><h3>Todo al día</h3><p style="color:rgba(255,255,255,.6)">No tienes tareas, exámenes ni clases próximas. Cuando agregues algo aparecerá aquí.</p></div></div>';
      return;
    }
    var col = it.sub ? it.sub.color : 'var(--accent)';
    var idx = st.q.indexOf(it);
    var html = '<div class="pl-bg" style="background-color:' + col + '">' + (it.sub ? coverArt(it.sub) : '') + '<div class="dim"></div></div><div class="pl-in">' +
      '<button class="pl-grab" data-a="close-player" aria-label="Cerrar"></button>' +
      '<div class="pl-cv' + (fi && !fi.running ? ' small' : '') + '">' + (it.sub ? cover(it.sub, 'l') : eventCover('l')) + '</div>' +
      '<div class="pl-meta"><div class="m"><div class="pl-t">' + esc(itemTitle(it)) + '</div><div class="pl-s">' + esc(it.type === 'class' ? (it.sub.teacher || 'Clase') : it.type === 'study' ? it.sub.name : ((it.sub ? it.sub.name + ' · ' : '') + KIND[it.a.kind])) + '</div></div>' +
      (it.type === 'act' ? '<button class="pl-more" data-a="act-menu" data-id="' + it.a.id + '" aria-label="Más opciones">' + icon('more', 20) + '</button>' : '') + '</div>' +
      '<div class="pl-bar"><i></i></div><div class="pl-times"><span class="l"></span><span class="r"></span></div>' +
      '<div class="pl-ctrls"><button data-a="mini-prev" class="' + (idx <= 0 || fi ? 'dis' : '') + '" aria-label="Anterior">' + icon('rew', 34) + '</button>' +
      '<button data-a="focus-toggle" aria-label="Estudiar">' + icon(fi && fi.running ? 'pause' : 'play', 46) + '</button>' +
      '<button data-a="' + (fi ? 'focus-stop' : 'mini-next') + '" class="' + (!fi && idx >= st.q.length - 1 ? 'dis' : '') + '" aria-label="Siguiente">' + icon(fi ? 'stop' : 'fwd', fi ? 30 : 34) + '</button></div>';
    if (!fi) html += '<div class="pl-dur">' + [15, 25, 45, 60].map(function (m) {
      return '<button class="' + (+S.settings.focusMin === m ? 'on' : '') + '" data-a="focus-min" data-m="' + m + '">' + m + ' min</button>';
    }).join('') + '</div>';
    html += '<div class="pl-acts">' + (it.type === 'act'
      ? '<button data-a="pl-complete" data-id="' + it.a.id + '">' + icon('check', 20) + 'Completar</button><button data-a="pl-open" data-id="' + it.a.id + '">' + icon('doc', 20) + 'Detalles</button>'
      : '<button data-a="pl-sub" data-id="' + it.sub.id + '">' + icon('stack', 20) + 'Materia</button><button data-a="pl-note" data-id="' + it.sub.id + '">' + icon('note', 20) + 'Apunte</button>') + '</div>';
    var rest = st.q.slice(idx + 1, idx + 7);
    if (rest.length) {
      html += '<div class="pl-q"><h3>A continuación</h3>' + rest.map(function (x) {
        return '<button class="qrow tap" data-a="mini-sel" data-key="' + esc(x.key) + '"><div class="cvw">' + itemCover(x, 's') + '</div><div class="mid"><div class="t">' + esc(itemTitle(x)) + '</div><div class="s">' + esc(itemSub(x, now)) + '</div></div></button>';
      }).join('') + '</div>';
    }
    html += '</div>';
    pl.innerHTML = html;
  }
  var bar = $('.pl-bar i', pl), l = $('.pl-times .l', pl), r = $('.pl-times .r', pl);
  if (!bar) return;
  var frac = 0, lt = '', rt = '';
  if (fi) { frac = fi.frac; lt = clock(S.focus.dur - fi.left); rt = '−' + clock(fi.left); }
  else if (it.type === 'class') {
    if (it.current) { frac = (now - it.o.start) / (it.o.end - it.o.start); lt = fmtTime(it.o.c.start); rt = 'quedan ' + span(it.o.end - now); }
    else { lt = 'Empieza ' + relDay(it.o.start).toLowerCase(); rt = fmtTime(it.o.c.start); }
  } else {
    var a = it.a, c0 = a.created || (actDue(a).getTime() - 7 * 864e5), due = actDue(a).getTime();
    frac = (now - c0) / Math.max(1, due - c0);
    lt = STATUS_T[a.status];
    rt = due < now ? 'Venció ' + countdown(due - now) : 'Vence ' + countdown(due - now);
  }
  bar.style.width = (clamp(frac, 0, 1) * 100).toFixed(2) + '%';
  l.textContent = lt; r.textContent = rt;
}

/* ---------- temporizador de estudio ---------- */
function focusToggle() {
  var st = miniState(), it = st.it, f = S.focus, now = Date.now();
  if (!it && !f) return;
  if (f && f.running) { f.remaining = f.endAt - now; f.running = false; f.endAt = null; toast('Sesión en pausa'); }
  else if (f && !f.running) { f.endAt = now + f.remaining; f.running = true; }
  else {
    var dur = (+S.settings.focusMin || 25) * 60000;
    S.focus = { key: it.key, actId: it.type === 'act' ? it.a.id : null, subId: it.sub ? it.sub.id : null, label: itemTitle(it), dur: dur, endAt: now + dur, running: true, remaining: null, started: now };
    if (it.type === 'act' && it.a.status === 'pendiente') it.a.status = 'proceso';
    toast('Estudiando ' + (+S.settings.focusMin) + ' min');
    if (Native && nat('canNotify') === false) nat('askNotify');
  }
  haptic(1); save(); renderMini(); renderPlayer(); render();
}
function focusStop(done) {
  var f = S.focus; if (!f) return;
  var spent = done ? f.dur : (f.running ? f.dur - (f.endAt - Date.now()) : f.dur - f.remaining);
  spent = Math.max(0, spent);
  S.stats.focusMs = (S.stats.focusMs || 0) + spent;
  var a = f.actId ? getAct(f.actId) : null;
  if (a) a.focusMs = (a.focusMs || 0) + spent;
  S.focus = null;
  save(); renderMini(); renderPlayer(); render();
  if (done) { toast('Sesión terminada. Buen trabajo.'); haptic(2); }
  else toast('Estudiaste ' + span(spent));
}
function tick() {
  var f = S.focus;
  if (f && f.running && Date.now() >= f.endAt) focusStop(true);
  renderMini();
  if (PLAYER.open) renderPlayer();
}
