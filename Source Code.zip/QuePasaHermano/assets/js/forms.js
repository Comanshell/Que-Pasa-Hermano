/* Que Pasa Hermano — formularios (hojas inferiores) */
'use strict';

var FORM = null; // formulario abierto: guarda archivos agregados mientras se edita

/* ---------- piezas de formulario ---------- */
function fg(rows, h, f) { return '<div class="fg">' + (h ? '<div class="fg-h">' + h + '</div>' : '') + '<div class="group">' + rows.join('') + '</div>' + (f ? '<div class="fg-f">' + f + '</div>' : '') + '</div>'; }
function fText(id, ph, v, extra) { return '<div class="cell' + (extra && extra.big ? ' big' : '') + '"><input id="' + id + '" type="text" placeholder="' + esc(ph) + '" value="' + esc(v) + '" autocomplete="off" ' + (extra && extra.attrs || '') + '></div>'; }
function fArea(id, ph, v, rows) { return '<div class="cell"><textarea id="' + id + '" placeholder="' + esc(ph) + '" rows="' + (rows || 4) + '">' + esc(v) + '</textarea></div>'; }
function fRow(label, ctl, id) { return '<label class="cell"' + (id ? ' for="' + id + '"' : '') + '><span class="cl">' + label + '</span><span class="ctl">' + ctl + '</span></label>'; }
function fSelect(id, opts, v) {
  return '<select id="' + id + '">' + opts.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(v) ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('') + '</select>';
}
function fSeg(id, opts, v) {
  return '<div class="seg" id="' + id + '" data-val="' + esc(v) + '">' + opts.map(function (o) {
    return '<button type="button" class="' + (String(o[0]) === String(v) ? 'on' : '') + '" data-segv="' + esc(o[0]) + '">' + o[1] + '</button>';
  }).join('') + '</div>';
}
function fChips(id, opts, vals) {
  return '<div class="mchips" id="' + id + '">' + opts.map(function (o) {
    return '<button type="button" class="chip' + (vals.indexOf(o[0]) >= 0 ? ' on' : '') + '" data-chipv="' + esc(o[0]) + '">' + o[1] + '</button>';
  }).join('') + '</div>';
}
function segVal(id) { var el = document.getElementById(id); return el ? el.getAttribute('data-val') : null; }
function chipVals(id) { return $$('#' + id + ' .chip.on').map(function (b) { return b.getAttribute('data-chipv'); }); }
function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
function shake(el) {
  if (!el) return;
  el.focus();
  var cell = el.closest('.cell') || el;
  cell.style.transition = 'background .2s'; cell.style.background = 'rgba(255,69,58,.18)';
  setTimeout(function () { cell.style.background = ''; }, 900);
  haptic(2);
}
function subjectOpts(none) {
  var o = S.subjects.map(function (s) { return [s.id, s.name]; });
  if (none) o.unshift(['', none]);
  return o;
}

/* ---------- materia ---------- */
function subjectForm(sub) {
  var isNew = !sub;
  var d = sub ? deepCopy(sub) : { id: uid(), name: '', teacher: '', room: '', color: SUBJECT_COLORS[S.subjects.length % SUBJECT_COLORS.length], glyph: 'book', mode: S.settings.defMode || 'pct', grades: [], created: Date.now() };
  var glyphTouched = !isNew;
  function preview() { return '<div class="preview-cv">' + cover({ id: d.id, name: d.name || 'Materia', color: d.color, glyph: d.glyph }, 'm') + '</div>'; }
  var body = '<div id="f_prev">' + preview() + '</div>' +
    fg([fText('f_name', 'Nombre de la materia', d.name, { big: true }), fText('f_teacher', 'Profesor o profesora', d.teacher), fText('f_room', 'Aula o salón', d.room)]) +
    fg(['<div class="swatches" id="f_colors">' + SUBJECT_COLORS.map(function (c) { return '<button type="button" class="swatch' + (c === d.color ? ' on' : '') + '" style="background:' + c + '" data-color="' + c + '" aria-label="Color"></button>'; }).join('') + '</div>'], 'Color') +
    fg(['<div class="glyphs" id="f_glyphs">' + GLYPH_ORDER.map(function (g) { return '<button type="button" class="glyph' + (g === d.glyph ? ' on' : '') + '" data-glyph="' + g + '">' + glyphSvg(g, '', 1.8) + '</button>'; }).join('') + '</div>'], 'Portada') +
    fg(['<div class="cell stack">' + fSeg('f_mode', [['pct', 'Por porcentajes'], ['equal', 'Todas valen igual']], d.mode) + '</div>'], 'Cómo se calculan las notas',
      'Por porcentajes: cada nota pesa lo que diga el profesor (por ejemplo, parcial 30%). Todas valen igual: es un promedio simple.') +
    (isNew ? fg(['<div class="cell stack">' + fSeg('f_tpl', [['none', 'Vacía'], ['cortes', '3 cortes'], ['periodos', '4 periodos']], 'none') + '</div>'], 'Empezar con',
      '3 cortes crea Corte 1, 2 y 3 con 30%, 30% y 40%. 4 periodos crea cuatro periodos de 25%.') : '') +
    (isNew ? '' : '<div class="fg"><div class="group"><button class="cell danger" data-a="delete-subject" data-id="' + d.id + '">Eliminar materia</button></div></div>');
  openSheet({ title: isNew ? 'Nueva materia' : 'Editar materia', body: body, saveLabel: isNew ? 'Agregar' : 'Guardar', onMount: function (b) {
    function upd() { $('#f_prev', b).innerHTML = preview(); }
    $('#f_name', b).addEventListener('input', function () {
      d.name = this.value;
      if (!glyphTouched) {
        d.glyph = guessGlyph(d.name);
        $$('.glyph', b).forEach(function (x) { x.classList.toggle('on', x.getAttribute('data-glyph') === d.glyph); });
      }
      upd();
    });
    $('#f_colors', b).addEventListener('click', function (e) {
      var t = e.target.closest('[data-color]'); if (!t) return;
      d.color = t.getAttribute('data-color');
      $$('.swatch', b).forEach(function (x) { x.classList.toggle('on', x === t); }); upd(); haptic(0);
    });
    $('#f_glyphs', b).addEventListener('click', function (e) {
      var t = e.target.closest('[data-glyph]'); if (!t) return;
      d.glyph = t.getAttribute('data-glyph'); glyphTouched = true;
      $$('.glyph', b).forEach(function (x) { x.classList.toggle('on', x === t); }); upd(); haptic(0);
    });
    if (isNew) setTimeout(function () { var n = $('#f_name', b); if (n) n.focus(); }, 420);
  }, onSave: function (b) {
    d.name = val('f_name').trim(); d.teacher = val('f_teacher').trim(); d.room = val('f_room').trim();
    if (!d.name) { shake($('#f_name', b)); return false; }
    var newMode = segVal('f_mode');
    if (newMode !== d.mode) applyMode(d, newMode);
    if (isNew) {
      var tpl = segVal('f_tpl');
      if (tpl === 'cortes') d.grades = [['Corte 1', 30], ['Corte 2', 30], ['Corte 3', 40]].map(function (x, i) { return { id: uid() + i, name: x[0], weight: d.mode === 'equal' ? '' : x[1], grade: '' }; });
      if (tpl === 'periodos') d.grades = [1, 2, 3, 4].map(function (i) { return { id: uid() + i, name: 'Periodo ' + i, weight: d.mode === 'equal' ? '' : 25, grade: '' }; });
      S.subjects.push(d);
      save(); toast('Materia agregada');
      if (NAV.tab === 'materias' || NAV.tab === 'inicio') push({ v: 'subject', id: d.id, back: curEntry().title });
      else render();
    } else {
      var i = S.subjects.indexOf(getSub(d.id));
      S.subjects[i] = d; save(); render();
    }
    renderMini();
  } });
}
/* cambiar entre porcentajes e igual valor: al pasar a porcentajes reparte el 100% si no hay pesos */
function applyMode(sub, mode) {
  sub.mode = mode;
  if (mode === 'pct') {
    var has = sub.grades.some(function (g) { return parseNum(g.weight) !== null && parseNum(g.weight) > 0; });
    if (!has && sub.grades.length) {
      var n = sub.grades.length, base = Math.floor(1000 / n) / 10, rest = Math.round((100 - base * n) * 10) / 10;
      sub.grades.forEach(function (g, i) { g.weight = i === n - 1 ? Math.round((base + rest) * 10) / 10 : base; });
    }
  }
}

/* ---------- calificación ---------- */
function gradeForm(sub, g) {
  var isNew = !g, s = sc(), eq = sub.mode === 'equal';
  var d = g ? deepCopy(g) : { id: uid(), name: '', weight: '', grade: '' };
  if (isNew && !eq) {
    var c0 = calcSubject(sub);
    if (c0.total < 100) d.weight = Math.round((100 - c0.total) * 10) / 10;
  }
  var body = fg([fText('f_gname', 'Nombre (ej. Quiz 2, Parcial)', d.name),
    (eq ? '' : fRow('Porcentaje', '<input id="f_gw" class="num" type="text" inputmode="decimal" placeholder="%" value="' + esc(d.weight) + '">')),
    fRow('Nota', '<input id="f_gg" class="num" type="text" inputmode="decimal" placeholder="' + fmtG(s.min) + '–' + fmtG(s.max) + '" value="' + esc(d.grade) + '">')],
    null, eq ? 'En esta materia todas las notas valen lo mismo. Deja la nota vacía si todavía no te la han dado: así la app calcula cuánto necesitas.' :
      'Deja la nota vacía si aún no te la dan. El porcentaje es lo que vale esta nota sobre el 100% de la materia.') +
    '<p class="form-note" id="f_gprev"></p>' +
    (isNew ? '' : '<div class="fg"><div class="group"><button class="cell danger" data-a="delete-grade" data-sub="' + sub.id + '" data-id="' + d.id + '">Eliminar calificación</button></div></div>');
  function preview() {
    var tmp = deepCopy(sub), gi = find(tmp.grades, function (x) { return x.id === d.id; });
    if (!gi) { gi = { id: d.id }; tmp.grades.push(gi); }
    gi.grade = val('f_gg'); gi.weight = eq ? '' : val('f_gw');
    var c = calcSubject(tmp), gv = parseNum(gi.grade);
    var el = $('#f_gprev'); if (!el) return;
    if (gv === null) { el.innerHTML = c.need !== null && c.status !== 'empty' ? 'Sin esta nota todavía, necesitas <b>' + needLabel(c.need) + '</b> en lo que falta.' : ''; return; }
    el.innerHTML = (eq ? 'Con esta nota tu promedio queda en <b>' + fmtAcc(c.avg) + '</b>. ' : 'Con esta nota tu acumulado queda en <b>' + fmtAcc(c.acc) + '</b>. ') +
      (c.status === 'secured' ? 'Ya aseguras la materia.' : c.need !== null && c.status !== 'impossible' ? 'Después necesitarías <b>' + needLabel(c.need) + '</b> en lo que falta.' : c.status === 'impossible' ? 'Ya no alcanzaría para aprobar.' : '');
  }
  openSheet({ title: isNew ? 'Nueva calificación' : 'Editar calificación', body: body, saveLabel: isNew ? 'Agregar' : 'Guardar', onMount: function (b) {
    ['f_gg', 'f_gw'].forEach(function (id) { var el = $('#' + id, b); if (el) el.addEventListener('input', preview); });
    preview();
    setTimeout(function () { var n = $(isNew ? '#f_gname' : '#f_gg', b); if (n) n.focus(); }, 420);
  }, onSave: function (b) {
    var name = val('f_gname').trim(), gv = parseNum(val('f_gg')), wv = eq ? null : parseNum(val('f_gw'));
    if (val('f_gg').trim() && (gv === null || gv < s.min || gv > s.max)) { shake($('#f_gg', b)); toast('La nota debe estar entre ' + fmtG(s.min) + ' y ' + fmtG(s.max)); return false; }
    if (!eq && val('f_gw').trim() && (wv === null || wv < 0 || wv > 100)) { shake($('#f_gw', b)); toast('El porcentaje debe estar entre 0 y 100'); return false; }
    d.name = name || ('Nota ' + (isNew ? sub.grades.length + 1 : ''));
    d.grade = gv === null ? '' : gv;
    if (!eq) d.weight = wv === null ? '' : wv;
    if (isNew) sub.grades.push(d);
    else { var i = sub.grades.indexOf(find(sub.grades, function (x) { return x.id === d.id; })); sub.grades[i] = d; }
    save(); render(); renderMini();
  } });
}

/* ---------- actividad (tarea, examen, evento) ---------- */
function actForm(act, def) {
  def = def || {};
  var isNew = !act;
  var a = act ? deepCopy(act) : { id: uid(), kind: def.kind || 'tarea', title: '', subjectId: def.subjectId || '', date: def.date || ymd(addDays(today0(), 1)), time: '', priority: 0,
    status: 'pendiente', desc: '', files: [], rem: (S.settings.defRem || []).slice(), created: Date.now(), focusMs: 0 };
  if (!a.subjectId && isNew && def.kind !== 'evento' && S.subjects.length === 1) a.subjectId = S.subjects[0].id;
  FORM = { files: a.files.slice(), added: [], removed: [] };
  var linked = act ? gradeForAct(act) : null;
  function filesHtml() {
    return '<div class="files" style="padding:12px">' + FORM.files.map(function (f) { return fileTile(f, true); }).join('') +
      '<button type="button" class="file add" data-a="attach" data-tag="form" data-mode="file"><span class="fi">' + icon('clip', 24) + 'Archivo</span></button>' +
      '<button type="button" class="file add" data-a="attach" data-tag="form" data-mode="photo"><span class="fi">' + icon('camera', 24) + 'Foto</span></button></div>';
  }
  FORM.refresh = function () { var el = $('#f_files'); if (el) el.innerHTML = filesHtml(); };
  var sub0 = getSub(a.subjectId);
  var body = fSeg('f_kind', [['tarea', 'Tarea'], ['examen', 'Examen'], ['evento', 'Evento']], a.kind) +
    fg([fText('f_title', 'Título', a.title, { big: true }), fArea('f_desc', 'Descripción, temas o instrucciones', a.desc, 3)]) +
    fg([fRow('Materia', fSelect('f_sub', subjectOpts('Sin materia'), a.subjectId), 'f_sub'),
      fRow('Fecha', '<input id="f_date" type="date" value="' + esc(a.date) + '">', 'f_date'),
      fRow('Hora', '<input id="f_time" type="time" value="' + esc(a.time) + '"><button type="button" class="clear" data-clear="f_time">Quitar</button>', 'f_time')]) +
    '<div id="f_work">' +
    fg(['<div class="cell stack"><span class="cl">Prioridad</span>' + fSeg('f_prio', [[0, 'Ninguna'], [1, 'Baja'], [2, 'Media'], [3, 'Alta']], a.priority || 0) + '</div>',
      '<div class="cell stack"><span class="cl">Estado</span>' + fSeg('f_status', [['pendiente', 'Pendiente'], ['proceso', 'En proceso'], ['completada', 'Completada']], a.status) + '</div>']) +
    '</div>' +
    fg(['<div class="cell stack" style="padding-bottom:4px">' + fChips('f_rem', REM_OPTS.map(function (o) { return [String(o.m), REM_SHORT[o.m]]; }), (a.rem || []).map(String)) + '</div>'], 'Recordarme',
      'Te llega una notificación al celular aunque la app esté cerrada.' + (a.time ? '' : ' Si no pones hora, se toma como referencia las 7:00 a. m.')) +
    '<div class="fg"><div class="fg-h">Archivos adjuntos</div><div class="group" id="f_files">' + filesHtml() + '</div></div>' +
    '<div id="f_gradebox"></div>' +
    (isNew ? '' : '<div class="fg"><div class="group"><button class="cell danger" data-a="delete-act" data-id="' + a.id + '">Eliminar</button></div></div>');
  function gradeBox() {
    var sid = val('f_sub'), sub = getSub(sid), kind = segVal('f_kind'), box = $('#f_gradebox');
    if (!box) return;
    if (!sub || kind === 'evento') { box.innerHTML = ''; return; }
    var g = linked && act && sid === act.subjectId ? linked : null;
    box.innerHTML = fg([fRow('Nota', '<input id="f_grade" class="num" type="text" inputmode="decimal" placeholder="Sin nota" value="' + esc(g ? g.grade : '') + '">', 'f_grade'),
      sub.mode === 'equal' ? '' : fRow('Vale', '<input id="f_weight" class="num" type="text" inputmode="decimal" placeholder="%" value="' + esc(g ? g.weight : '') + '">', 'f_weight')],
      'Calificación', 'Si escribes la nota, se guarda en las calificaciones de ' + esc(sub.name) + '.');
  }
  function kindVis() {
    var k = segVal('f_kind');
    $('#f_work').style.display = k === 'evento' ? 'none' : '';
    gradeBox();
  }
  openSheet({ title: isNew ? 'Nueva actividad' : 'Editar', body: body, saveLabel: isNew ? 'Agregar' : 'Guardar', full: true,
    onMount: function (b) {
      b.addEventListener('segchange', function (e) { if (e.target.id === 'f_kind') kindVis(); });
      $('#f_sub', b).addEventListener('change', gradeBox);
      kindVis();
      if (isNew) setTimeout(function () { var n = $('#f_title', b); if (n) n.focus(); }, 450);
    },
    onCancel: function () {
      FORM.added.forEach(function (f) { nat('removeFile', f.id); });
      FORM = null;
    },
    onSave: function (b) {
      a.kind = segVal('f_kind');
      a.title = val('f_title').trim();
      a.subjectId = val('f_sub');
      a.date = val('f_date') || ymd(today0());
      a.time = val('f_time') || '';
      a.desc = val('f_desc').trim();
      a.rem = chipVals('f_rem').map(Number);
      if (a.kind !== 'evento') { a.priority = +segVal('f_prio'); var ns = segVal('f_status'); if (ns !== a.status) { a.status = ns; a.completedAt = ns === 'completada' ? Date.now() : null; } }
      else { a.priority = 0; a.status = 'pendiente'; }
      var sub = getSub(a.subjectId);
      if (!a.title) a.title = KIND[a.kind] + (sub ? ' de ' + sub.name : '');
      if (!a.title) { shake($('#f_title', b)); return false; }
      var gEl = $('#f_grade'), wEl = $('#f_weight');
      if (gEl && sub) {
        var gv = parseNum(gEl.value), wv = wEl ? parseNum(wEl.value) : null, s = sc();
        if (gEl.value.trim() && (gv === null || gv < s.min || gv > s.max)) { shake(gEl); toast('La nota debe estar entre ' + fmtG(s.min) + ' y ' + fmtG(s.max)); return false; }
        // si cambió de materia, quita la nota de la materia anterior
        S.subjects.forEach(function (x) { if (x.id !== sub.id) x.grades = x.grades.filter(function (g) { return g.actId !== a.id; }); });
        var gi = find(sub.grades, function (g) { return g.actId === a.id; });
        if (gv !== null || (wv !== null && sub.mode !== 'equal') || gi) {
          if (!gi) { gi = { id: uid(), actId: a.id, name: a.title, weight: '', grade: '' }; sub.grades.push(gi); }
          gi.name = a.title; gi.grade = gv === null ? '' : gv;
          if (sub.mode !== 'equal') gi.weight = wv === null ? '' : wv;
        }
      }
      FORM.removed.forEach(function (id) { nat('removeFile', id); });
      a.files = FORM.files;
      FORM = null;
      if (isNew) S.acts.push(a);
      else { var i = S.acts.indexOf(getAct(a.id)); S.acts[i] = a; }
      save(); render(); renderMini();
      toast(isNew ? KIND[a.kind] + ' agregada' : 'Cambios guardados');
      if (a.rem.length && isOpen(a) && Native && nat('canNotify') === false) setTimeout(function () { nat('askNotify'); }, 600);
    } });
}
function gradeForActForm(a) {
  var sub = getSub(a.subjectId);
  if (!sub) { toast('Asigna una materia a esta actividad primero'); return; }
  var g = gradeForAct(a);
  if (!g) {
    g = { id: uid(), actId: a.id, name: a.title, weight: '', grade: '' };
    if (sub.mode !== 'equal') { var c = calcSubject(sub); if (c.total < 100) g.weight = Math.round((100 - c.total) * 10) / 10; }
    sub.grades.push(g);
    gradeForm(sub, g);
    // si se cancela sin datos, se quita al cerrar
    var l = LAYERS[LAYERS.length - 1];
    l.o.onCancel = function () { if (parseNum(g.grade) === null) { sub.grades = sub.grades.filter(function (x) { return x !== g; }); } };
  } else gradeForm(sub, g);
}

/* ---------- clase del horario ---------- */
function classForm(cls, def) {
  def = def || {};
  if (!S.subjects.length) {
    actionSheet('Primero agrega al menos una materia para poder ponerla en el horario.', [{ t: 'Agregar materia', fn: function () { subjectForm(null); } }]);
    return;
  }
  var isNew = !cls, day = cls ? cls.day : (def.day || Math.min(dow(new Date()), 5));
  var start = '07:00', end = '07:55';
  if (isNew) {
    var list = classesOn(day);
    if (list.length) { var last = list[list.length - 1]; start = last.end; var len = tmin(last.end) - tmin(last.start); end = minToHm(tmin(start) + (len || 55)); }
  }
  var d = cls ? deepCopy(cls) : { id: uid(), subjectId: def.subjectId || S.subjects[0].id, day: day, start: start, end: end, room: '' };
  var dayOpts = [1, 2, 3, 4, 5, 6, 7].map(function (x) { return [String(x), DAY_LETTER[x] === 'M' && x === 3 ? 'Mi' : DAY_LETTER[x]]; });
  var body = fg([fRow('Materia', fSelect('f_csub', subjectOpts(), d.subjectId), 'f_csub')]) +
    fg(['<div class="cell stack" style="padding-bottom:4px">' + fChips('f_cdays', [1, 2, 3, 4, 5, 6, 7].map(function (x) { return [String(x), cap(DAYS_S[x % 7])]; }), [String(d.day)]) + '</div>'],
      isNew ? 'Días' : 'Día', isNew ? 'Puedes elegir varios días si la clase se repite a la misma hora.' : null) +
    fg([fRow('Empieza', '<input id="f_cstart" type="time" value="' + d.start + '">', 'f_cstart'), fRow('Termina', '<input id="f_cend" type="time" value="' + d.end + '">', 'f_cend'),
      fText('f_croom', 'Aula (opcional, si es distinta a la de la materia)', d.room)]) +
    (isNew ? '' : '<div class="fg"><div class="group"><button class="cell danger" data-a="delete-class" data-id="' + d.id + '">Quitar del horario</button></div></div>');
  openSheet({ title: isNew ? 'Nueva clase' : 'Editar clase', body: body, saveLabel: isNew ? 'Agregar' : 'Guardar', onMount: function (b) {
    if (!isNew) {
      $('#f_cdays', b).addEventListener('click', function (e) {
        var t = e.target.closest('.chip'); if (!t) return;
        setTimeout(function () { $$('#f_cdays .chip', b).forEach(function (x) { x.classList.toggle('on', x === t); }); }, 0);
      });
    }
  }, onSave: function (b) {
    var days = chipVals('f_cdays').map(Number), st = val('f_cstart'), en = val('f_cend');
    if (!days.length) { toast('Elige al menos un día'); return false; }
    if (!st || !en || tmin(en) <= tmin(st)) { shake($('#f_cend', b)); toast('La hora de fin debe ser después del inicio'); return false; }
    d.subjectId = val('f_csub'); d.start = st; d.end = en; d.room = val('f_croom').trim();
    if (isNew) days.forEach(function (x, i) { S.classes.push(Object.assign({}, d, { id: uid() + i, day: x })); });
    else { d.day = days[0]; var i = S.classes.indexOf(getClass(d.id)); S.classes[i] = d; }
    save(); render(); renderMini();
    toast(isNew ? (days.length > 1 ? plural(days.length, 'clase agregada', 'clases agregadas') : 'Clase agregada') : 'Clase actualizada');
  } });
}

/* ---------- apunte ---------- */
function noteForm(note, subId) {
  var isNew = !note;
  var n = note ? deepCopy(note) : { id: uid(), subjectId: subId, title: '', body: '', updated: Date.now(), files: [] };
  FORM = { files: n.files.slice(), added: [], removed: [] };
  function filesHtml() {
    return '<div class="files" style="padding:12px">' + FORM.files.map(function (f) { return fileTile(f, true); }).join('') +
      '<button type="button" class="file add" data-a="attach" data-tag="form" data-mode="photo"><span class="fi">' + icon('camera', 24) + 'Foto</span></button>' +
      '<button type="button" class="file add" data-a="attach" data-tag="form" data-mode="file"><span class="fi">' + icon('clip', 24) + 'Archivo</span></button></div>';
  }
  FORM.refresh = function () { var el = $('#f_nfiles'); if (el) el.innerHTML = filesHtml(); };
  var sub = getSub(n.subjectId);
  var body = fg([fText('f_ntitle', 'Título', n.title, { big: true }), fArea('f_nbody', 'Escribe tu apunte…', n.body, 12)], sub ? esc(sub.name) : null) +
    '<div class="fg"><div class="fg-h">Fotos y archivos</div><div class="group" id="f_nfiles">' + filesHtml() + '</div><div class="fg-f">Toma una foto del tablero o del cuaderno para tenerla con el apunte.</div></div>' +
    (isNew ? '' : '<div class="fg"><div class="group"><button class="cell danger" data-a="delete-note" data-id="' + n.id + '">Eliminar apunte</button></div></div>');
  openSheet({ title: isNew ? 'Nuevo apunte' : 'Apunte', body: body, saveLabel: 'Guardar', full: true,
    onMount: function (b) { if (isNew) setTimeout(function () { var x = $('#f_ntitle', b); if (x) x.focus(); }, 450); },
    onCancel: function () { FORM.added.forEach(function (f) { nat('removeFile', f.id); }); FORM = null; },
    onSave: function () {
      n.title = val('f_ntitle').trim(); n.body = val('f_nbody');
      if (!n.title && !n.body.trim() && !FORM.files.length) { FORM = null; return; }
      if (!n.title) n.title = n.body.trim().split('\n')[0].slice(0, 40) || 'Apunte';
      FORM.removed.forEach(function (id) { nat('removeFile', id); });
      n.files = FORM.files; n.updated = Date.now(); FORM = null;
      if (isNew) S.notes.push(n); else { var i = S.notes.indexOf(getNote(n.id)); S.notes[i] = n; }
      save(); render();
    } });
}

/* ---------- perfil y escala ---------- */
function profileForm() {
  var p = S.profile;
  var body = fg([fText('f_pname', 'Tu nombre', p.name, { big: true }), fText('f_pschool', 'Colegio o universidad', p.school), fText('f_plevel', 'Grado, curso o semestre', p.level)]);
  openSheet({ title: 'Editar perfil', body: body, onSave: function () {
    p.name = val('f_pname').trim(); p.school = val('f_pschool').trim(); p.level = val('f_plevel').trim();
    save(); render();
  } });
}
var SCALE_PRESETS = [
  { t: '0.0 a 5.0 · aprueba con 3.0', s: { min: 0, max: 5, pass: 3, dec: 1 } },
  { t: '1.0 a 5.0 · aprueba con 3.0', s: { min: 1, max: 5, pass: 3, dec: 1 } },
  { t: '1.0 a 5.0 · aprueba con 3.5', s: { min: 1, max: 5, pass: 3.5, dec: 1 } },
  { t: '0 a 10 · aprueba con 6', s: { min: 0, max: 10, pass: 6, dec: 1 } },
  { t: '0 a 100 · aprueba con 60', s: { min: 0, max: 100, pass: 60, dec: 0 } }
];
function scaleForm() {
  var s = sc();
  var cur = find(SCALE_PRESETS, function (p) { return p.s.min === s.min && p.s.max === s.max && p.s.pass === s.pass && p.s.dec === s.dec; });
  var body = fg(SCALE_PRESETS.map(function (p, i) {
    return '<button type="button" class="cell" data-preset="' + i + '"><span class="cl">' + p.t + '</span><span class="cv" style="color:var(--accent)">' + (p === cur ? icon('check', 20) : '') + '</span></button>';
  }), 'Escalas comunes') +
    fg([fRow('Nota mínima', '<input id="f_smin" class="num" type="text" inputmode="decimal" value="' + s.min + '">'),
      fRow('Nota máxima', '<input id="f_smax" class="num" type="text" inputmode="decimal" value="' + s.max + '">'),
      fRow('Para aprobar', '<input id="f_spass" class="num" type="text" inputmode="decimal" value="' + s.pass + '">'),
      '<div class="cell stack"><span class="cl">Decimales en las notas</span>' + fSeg('f_sdec', [[0, 'Ninguno'], [1, 'Uno'], [2, 'Dos']], s.dec) + '</div>'], 'Personalizada');
  openSheet({ title: 'Escala de notas', body: body, onMount: function (b) {
    b.addEventListener('click', function (e) {
      var t = e.target.closest('[data-preset]'); if (!t) return;
      var p = SCALE_PRESETS[+t.getAttribute('data-preset')].s;
      $('#f_smin').value = p.min; $('#f_smax').value = p.max; $('#f_spass').value = p.pass;
      var sg = $('#f_sdec'); sg.setAttribute('data-val', p.dec);
      $$('button', sg).forEach(function (x) { x.classList.toggle('on', x.getAttribute('data-segv') === String(p.dec)); });
      $$('[data-preset] .cv', b).forEach(function (x) { x.innerHTML = ''; });
      $('.cv', t).innerHTML = icon('check', 20);
      haptic(0);
    });
  }, onSave: function (b) {
    var mn = parseNum(val('f_smin')), mx = parseNum(val('f_smax')), ps = parseNum(val('f_spass'));
    if (mn === null || mx === null || ps === null || mx <= mn || ps < mn || ps > mx) { toast('Revisa los valores: la nota para aprobar debe estar entre la mínima y la máxima'); return false; }
    S.settings.scale = { min: mn, max: mx, pass: ps, dec: +segVal('f_sdec') };
    save(); render(); toast('Escala actualizada');
  } });
}

/* ---------- agregar rápido ---------- */
function quickAdd(date) {
  actionSheet(null, [
    { t: 'Nueva tarea', fn: function () { actForm(null, { kind: 'tarea', date: date }); } },
    { t: 'Nuevo examen', fn: function () { actForm(null, { kind: 'examen', date: date }); } },
    { t: 'Nuevo evento', fn: function () { actForm(null, { kind: 'evento', date: date }); } },
    { t: 'Nueva materia', fn: function () { subjectForm(null); } },
    { t: 'Clase en el horario', fn: function () { classForm(null, {}); } }
  ]);
}
