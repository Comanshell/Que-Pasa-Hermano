/* Que Pasa Hermano — pantallas */
'use strict';

var VIEWS = {};

/* ================= INICIO ================= */
function nextExam(now) {
  var list = S.acts.filter(function (a) { return a.kind === 'examen' && isOpen(a) && actDue(a) >= now; }).sort(byDue);
  return list[0] || null;
}
function daySummary(now) {
  if (!S.subjects.length) return 'Empieza agregando tus materias y tu horario. Lo demás se organiza solo.';
  var cls = classesOn(dow(now)), m = nowMin(now), today = ymd(now);
  var left = cls.filter(function (c) { return tmin(c.end) > m; }).length;
  var due = S.acts.filter(function (a) { return a.kind !== 'evento' && isOpen(a) && a.date === today; }).length;
  var late = S.acts.filter(function (a) { return isOverdue(a, now) && a.date !== today; }).length;
  var dueTxt = due ? plural(due, 'entrega', 'entregas') : '';
  var s;
  if (!cls.length) s = due ? 'Hoy no tienes clases, pero sí ' + dueTxt + '.' : 'Hoy no tienes clases.';
  else if (!left) s = 'Ya terminaste las clases de hoy' + (due ? ' y te ' + (due === 1 ? 'queda 1 entrega' : 'quedan ' + due + ' entregas') : '') + '.';
  else if (left === cls.length) s = 'Hoy tienes ' + plural(cls.length, 'clase', 'clases') + (due ? ' y ' + dueTxt : '') + '.';
  else s = 'Te ' + (left === 1 ? 'queda 1 clase' : 'quedan ' + left + ' clases') + ' hoy' + (due ? ' y ' + dueTxt : '') + '.';
  if (late) s += ' Tienes ' + plural(late, 'tarea atrasada', 'tareas atrasadas') + '.';
  else { var ex = nextExam(now); if (ex) s += ' Tu próximo examen es ' + relPhrase(pymd(ex.date)) + '.'; }
  return s;
}
function heroCard(o) {
  var style = 'background-color:' + (o.sub ? o.sub.color : 'var(--accent)');
  return '<button class="hero tap" data-a="' + o.a + '" data-id="' + esc(o.id || '') + '" style="' + style + '">' +
    (o.sub ? coverArt(o.sub) : '') + '<div class="hl"></div><div class="scrim"></div><div class="tx">' +
    '<div class="eb">' + esc(o.eb) + '</div><div class="t">' + esc(o.t) + '</div><div class="s">' + esc(o.s) + '</div>' +
    (o.frac !== undefined ? '<div class="hp"><i style="width:' + (clamp(o.frac, 0, 1) * 100).toFixed(1) + '%"></i></div>' : '') +
    '</div></button>';
}
function actRow(a) {
  var late = isOverdue(a), sub = getSub(a.subjectId);
  var s = (a.kind === 'examen' ? 'Examen · ' : a.kind === 'evento' ? 'Evento · ' : '') + (sub ? sub.name + ' · ' : '') + (late ? 'Atrasada · ' : '') + fmtDue(a);
  return '<div class="row"><button class="tap" style="display:flex;align-items:center;flex:1;min-width:0;text-align:left" data-a="open-act" data-id="' + a.id + '">' +
    '<div class="thumb">' + actCover(a, 's') + '</div><div class="mid"><div class="t">' + esc(a.title) + '</div><div class="s' + (late ? ' bad' : '') + '">' + esc(s) + '</div></div></button>' +
    '<div class="side">' + prioMarks(a.priority) + (a.files && a.files.length ? icon('clip', 16) : '') + '</div>' +
    '<button class="icon-btn sm" data-a="act-menu" data-id="' + a.id + '" aria-label="Opciones">' + icon('more', 20) + '</button></div>';
}

VIEWS.home = function () {
  var now = new Date(), first = (S.profile.name || '').trim().split(/\s+/)[0];
  var h = now.getHours();
  var greet = h < 5 ? 'Buenas noches' : h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
  var head = '<div class="home-head"><div class="eyebrow">' + esc(longDate(now)) + '</div>' +
    '<h1 class="large-title">' + greet + (first ? ', ' + esc(first) : '') + '</h1><p class="lede">' + esc(daySummary(now)) + '</p></div>';
  var right = '<button class="circle-btn" data-a="quick-add" aria-label="Agregar">' + icon('plus', 20) + '</button>' +
    '<button data-a="tab" data-tab="perfil" aria-label="Perfil">' + avatarHtml('sm') + '</button>';
  var html = '';

  if (!S.subjects.length) {
    html += '<div class="sec"><div class="shelf hero-shelf">' +
      '<button class="hero quiet short tap" data-a="new-subject"><span class="bigic">' + icon('stack', 40) + '</span><div class="tx"><div class="eb">Empieza aquí</div><div class="t">Agrega tus materias</div><div class="s">Con profesor, color y calificaciones</div></div></button>' +
      '<button class="hero quiet short tap" data-a="go-horario"><span class="bigic">' + icon('calendar', 40) + '</span><div class="tx"><div class="eb">Después</div><div class="t">Arma tu horario</div><div class="s">Para saber siempre qué clase sigue</div></div></button>' +
      '<div class="end"></div></div></div>';
    html += '<div class="sec">' + empty('sparkle', 'Tu semana, en un solo lugar', 'Cuando agregues materias, tareas y exámenes, aquí verás lo más importante de cada día.', '<button class="pill solid sm" data-a="load-demo">Ver con datos de ejemplo</button>') + '</div>';
    return { title: 'Inicio', head: head, right: right, html: html, th: 60 };
  }

  var heroes = [], cc = currentClass(now), nc = nextClass(now);
  if (cc && cc.sub) heroes.push(heroCard({ sub: cc.sub, a: 'open-subject', id: cc.sub.id, eb: 'Ahora en clase', t: cc.sub.name,
    s: 'Termina ' + aLas(cc.c.end) + ((cc.c.room || cc.sub.room) ? ' · ' + (cc.c.room || cc.sub.room) : ''), frac: (now - cc.start) / (cc.end - cc.start) }));
  if (nc && nc.sub) heroes.push(heroCard({ sub: nc.sub, a: 'open-subject', id: nc.sub.id, eb: 'Próxima clase · ' + relDay(nc.start).toLowerCase(), t: nc.sub.name,
    s: fmtTime(nc.c.start) + ((nc.c.room || nc.sub.room) ? ' · ' + (nc.c.room || nc.sub.room) : (nc.sub.teacher ? ' · ' + nc.sub.teacher : '')) }));
  var ex = nextExam(now);
  if (ex) {
    var es = getSub(ex.subjectId), ec = es ? calcSubject(es) : null;
    var needTxt = ec && ec.need !== null && ec.status !== 'secured' && ec.status !== 'empty' && ec.status !== 'impossible' ? ' · necesitas ' + needLabel(ec.need) : '';
    heroes.push(heroCard({ sub: es, a: 'open-act', id: ex.id, eb: 'Próximo examen · ' + countdown(actDue(ex) - now), t: ex.title, s: (es ? es.name : 'Examen') + needTxt }));
  }
  var work = pendingWork(), tk = find(work, function (a) { return a.kind === 'tarea'; });
  if (tk) {
    var ts = getSub(tk.subjectId), lateT = isOverdue(tk);
    heroes.push(heroCard({ sub: ts, a: 'open-act', id: tk.id, eb: lateT ? 'Entrega atrasada' : 'Próxima entrega · ' + relDay(pymd(tk.date)).toLowerCase(), t: tk.title, s: (ts ? ts.name + ' · ' : '') + STATUS_T[tk.status] }));
  }
  if (!heroes.length) heroes.push('<div class="hero quiet short"><span class="bigic" style="color:var(--green)">' + icon('check', 44) + '</span><div class="tx"><div class="eb">Hoy</div><div class="t">Todo al día</div><div class="s">No tienes pendientes cercanos</div></div></div>');
  html += '<div class="sec" style="margin-top:22px"><div class="shelf hero-shelf">' + heroes.join('') + '<div class="end"></div></div></div>';

  var pend = work.slice(0, 5);
  html += '<div class="sec">' + secHead('Pendientes', 'data-a="tab" data-tab="tareas"');
  if (pend.length) html += '<div class="rows">' + pend.map(actRow).join('') + '</div>';
  else html += '<p class="mini-empty">No tienes tareas pendientes. Buen momento para adelantar o repasar.</p>';
  html += '</div>';

  var exams = S.acts.filter(function (a) { return a.kind !== 'tarea' && isOpen(a) && actDue(a) >= now; }).sort(byDue).slice(0, 10);
  if (exams.length) {
    html += '<div class="sec">' + secHead('Próximos exámenes y eventos', 'data-a="go-cal"') + '<div class="shelf">' + exams.map(function (a) {
      var d = pymd(a.date), sub = getSub(a.subjectId);
      var badge = '<div class="badge">' + DAYS_S[d.getDay()] + '<b>' + d.getDate() + '</b></div>';
      return '<button class="tile tap" data-a="open-act" data-id="' + a.id + '">' + (sub ? cover(sub, 'm', badge) : '<div class="cover cv-m" style="background-color:#3a3a3c">' + badge + '<div class="ct">' + esc(a.title) + '</div></div>') +
        '<div class="tt">' + esc(a.title) + '</div><div class="ts">' + esc((sub ? sub.name : KIND[a.kind]) + ' · ' + countdown(actDue(a) - now)) + '</div></button>';
    }).join('') + '<div class="end"></div></div></div>';
  }

  html += '<div class="sec">' + secHead('Tus materias', 'data-a="tab" data-tab="materias"') + '<div class="shelf">' + S.subjects.map(function (sub) {
    var c = calcSubject(sub), st = STATUS[c.status];
    return '<button class="tile tap" data-a="open-subject" data-id="' + sub.id + '">' + cover(sub, 'm') + '<div class="tt">' + esc(sub.name) + '</div>' +
      '<div class="ts"><i class="dot" style="background:' + st.c + '"></i>' + (c.avg !== null ? fmtAcc(c.avg) + ' · ' : '') + st.t + '</div></button>';
  }).join('') + '<div class="end"></div></div></div>';

  var ov = overallAvg();
  if (ov) {
    var counts = { good: 0, risk: 0, bad: 0 };
    S.subjects.forEach(function (sub) {
      var st = calcSubject(sub).status;
      if (st === 'ok' || st === 'secured') counts.good++; else if (st === 'risk') counts.risk++; else if (st !== 'empty') counts.bad++;
    });
    var s = sc();
    html += '<div class="sec">' + secHead('Progreso académico') + '<button class="prog tap" data-a="tab" data-tab="materias"><div class="pr"><div class="pn">' + fmtAcc(ov.avg) + '</div>' +
      '<div class="pl"><b>Promedio general</b>en ' + plural(ov.n, 'materia', 'materias') + ' con notas</div></div>' +
      '<div class="bar"><i style="width:' + (clamp(ov.avg / s.max, 0, 1) * 100).toFixed(1) + '%;background:' + (ov.avg >= s.pass ? 'var(--green)' : 'var(--orange)') + '"></i><b style="left:' + (s.pass / s.max * 100).toFixed(1) + '%"></b></div>' +
      '<div class="lg">' + (counts.good ? '<span><i class="dot" style="background:var(--green)"></i>' + counts.good + ' van bien</span>' : '') +
      (counts.risk ? '<span><i class="dot" style="background:var(--orange)"></i>' + counts.risk + ' necesita' + (counts.risk > 1 ? 'n' : '') + ' subir</span>' : '') +
      (counts.bad ? '<span><i class="dot" style="background:var(--red)"></i>' + counts.bad + ' en peligro</span>' : '') + '</div></button></div>';
  }
  return { title: 'Inicio', head: head, right: right, html: html, th: 60 };
};

/* ================= MATERIAS ================= */
VIEWS.subjects = function () {
  var right = '<button class="circle-btn" data-a="new-subject" aria-label="Nueva materia">' + icon('plus', 20) + '</button>';
  if (!S.subjects.length) return { title: 'Materias', right: right,
    html: empty('stack', 'Aún no tienes materias', 'Cada materia tiene su portada, profesor, calificaciones, apuntes y actividades.', '<button class="pill solid sm" data-a="new-subject">Agregar materia</button>') };
  var html = '<div class="grid2">' + S.subjects.map(function (sub) {
    var c = calcSubject(sub), st = STATUS[c.status];
    return '<button class="tile tap" data-a="open-subject" data-id="' + sub.id + '">' + cover(sub, 'm') +
      '<div class="tt">' + esc(sub.name) + '</div><div class="ts"><i class="dot" style="background:' + st.c + '"></i>' + esc(sub.teacher || st.t) + '</div></button>';
  }).join('') + '</div>';
  return { title: 'Materias', right: right, html: html };
};

VIEWS.subject = function (e) {
  var sub = getSub(e.id);
  if (!sub) return null;
  var c = calcSubject(sub), s = sc(), st = STATUS[c.status], now = new Date();
  var days = subjectDays(sub.id).map(function (d) { return cap(DAYS_S[d % 7]); }).join(', ');
  var meta = [days, sub.room].filter(Boolean).join(' · ') || 'Sin clases en el horario';
  var html = '<div class="album"><div class="tint" style="background:linear-gradient(' + sub.color + ',rgba(0,0,0,0))"></div>' +
    '<div class="cvw">' + cover(sub, 'l') + '</div><h1>' + esc(sub.name) + '</h1>' +
    '<div class="who">' + esc(sub.teacher || 'Agregar profesor') + '</div><div class="mt">' + esc(meta.toUpperCase()) + '</div></div>' +
    '<div class="pill-btns"><button class="pill tap" data-a="new-act" data-sub="' + sub.id + '">' + icon('plus', 20) + 'Actividad</button>' +
    '<button class="pill tap" data-a="new-grade" data-sub="' + sub.id + '">' + icon('grade', 20) + 'Calificación</button></div>';

  // resumen de nota
  var big, lab;
  if (c.eq) { big = c.avg !== null ? fmtAcc(c.avg) : '—'; lab = 'Promedio · ' + c.graded + ' de ' + plural(c.n, 'nota', 'notas'); }
  else { big = c.graded ? fmtAcc(c.acc) : '—'; lab = 'Acumulado · ' + fmtPct(c.gW) + ' evaluado'; }
  var barW = c.eq ? (c.avg || 0) / s.max : c.acc / s.max;
  var ghost = (!c.eq && c.rem > 0 && c.graded) ? '<s style="left:' + (barW * 100).toFixed(1) + '%;width:' + ((c.maxP - c.acc) / s.max * 100).toFixed(1) + '%"></s>' : '';
  html += '<div class="gsum"><div class="gsum-top"><div><div class="gnum">' + big + '<small>/ ' + fmtG(s.max) + '</small></div><div class="glab">' + esc(lab) + '</div></div>' +
    '<div class="gstat" style="color:' + st.c + '"><i class="dot" style="background:' + st.c + '"></i>' + st.t + '</div></div>' +
    '<div class="bar"><i style="width:' + (clamp(barW, 0, 1) * 100).toFixed(1) + '%;background:' + (c.status === 'empty' ? 'var(--label3)' : st.c) + '"></i>' + ghost + '<b style="left:' + (s.pass / s.max * 100).toFixed(1) + '%"></b></div>' +
    '<div class="bar-legend"><span>0</span><span>Aprueba con ' + fmtG(s.pass) + '</span><span>' + fmtG(s.max) + '</span></div>' +
    '<p class="gtext">' + gradeSentence(sub, c) + '</p>';
  if (c.rem > 0.0001 && c.graded && c.status !== 'failed') {
    var tg = targetsFor(s);
    html += '<div class="targets">' + tg.map(function (t) {
      var n = needFor(c, t);
      var v = n === null ? '—' : n > s.max + 1e-9 ? '—' : needLabel(n);
      return '<div><span>Para ' + fmtG(t) + '</span><b class="' + (v === '—' ? 'no' : '') + '">' + v + '</b></div>';
    }).join('') + '</div>';
  }
  html += '</div>';

  // calificaciones (lista tipo canciones)
  html += '<div class="sec">' + secHead('Calificaciones') +
    '<div class="seg" style="margin-bottom:8px"><button class="' + (c.eq ? '' : 'on') + '" data-a="sub-mode" data-id="' + sub.id + '" data-v="pct">Por porcentajes</button>' +
    '<button class="' + (c.eq ? 'on' : '') + '" data-a="sub-mode" data-id="' + sub.id + '" data-v="equal">Todas valen igual</button></div>';
  html += sub.grades.map(function (g, i) {
    var gv = parseNum(g.grade), low = gv !== null && gv < s.pass, linked = g.actId ? getAct(g.actId) : null;
    return '<button class="track tap" data-a="edit-grade" data-sub="' + sub.id + '" data-id="' + g.id + '"><span class="n">' + (i + 1) + '</span>' +
      '<span class="t">' + esc(g.name || 'Sin nombre') + (linked ? '<small>' + KIND[linked.kind] + ' · ' + shortDate(pymd(linked.date)) + '</small>' : '') + '</span>' +
      (c.eq ? '' : '<span class="w">' + fmtPct(parseNum(g.weight) || 0) + '</span>') +
      '<span class="g' + (gv === null ? ' pend' : low ? ' low' : '') + '">' + fmtG(gv) + '</span></button>';
  }).join('');
  html += '<button class="track add tap" data-a="new-grade" data-sub="' + sub.id + '"><span class="n">' + icon('plus', 18) + '</span><span class="t">Agregar calificación</span></button>';
  var metaTxt;
  if (c.eq) metaTxt = plural(c.n, 'calificación', 'calificaciones') + ' · todas valen lo mismo' + (c.pending ? ' · ' + c.pending + ' por calificar' : '');
  else {
    metaTxt = plural(c.n, 'calificación', 'calificaciones') + ' · ' + fmtPct(c.gW) + ' evaluado';
    if (c.n && Math.abs(c.total - 100) > 0.05) metaTxt += ' · <span class="warn">los porcentajes suman ' + fmtPct(c.total) + (c.total < 100 ? ', falta asignar ' + fmtPct(100 - c.total) : '') + '</span>';
  }
  html += '<p class="meta">' + metaTxt + '</p></div>';

  // próximas actividades
  var open = S.acts.filter(function (a) { return a.subjectId === sub.id && isOpen(a); }).sort(byDue);
  html += '<div class="sec">' + secHead('Próximas actividades');
  html += open.length ? '<div class="rows">' + open.map(actRow).join('') + '</div>' : '<p class="mini-empty">Nada pendiente en esta materia.</p>';
  html += '</div>';

  // apuntes
  var notes = S.notes.filter(function (n) { return n.subjectId === sub.id; }).sort(function (a, b) { return b.updated - a.updated; });
  html += '<div class="sec">' + secHead('Apuntes') + '<div class="shelf" style="grid-auto-columns:150px"><button class="note-card new tap" data-a="new-note" data-sub="' + sub.id + '">' + icon('pencil', 26) + 'Nuevo apunte</button>' +
    notes.map(function (n) {
      return '<button class="note-card tap" data-a="edit-note" data-id="' + n.id + '"><div class="nt">' + esc(n.title || 'Sin título') + '</div><div class="nb">' + esc(n.body) + '</div><div class="nd">' + esc(shortDate(new Date(n.updated))) + '</div>' +
        (n.files && n.files.length ? '<span class="nclip">' + icon('clip', 14) + '</span>' : '') + '</button>';
    }).join('') + '<div class="end"></div></div></div>';

  // clases
  var cls = S.classes.filter(function (x) { return x.subjectId === sub.id; }).sort(function (a, b) { return a.day - b.day || tmin(a.start) - tmin(b.start); });
  html += '<div class="sec">' + secHead('Clases') + cls.map(function (x) {
    return '<button class="crow tap" data-a="edit-class" data-id="' + x.id + '"><div class="tm">' + cap(DAY_NAMES[x.day]) + '</div><div class="bar2" style="background:' + sub.color + '"></div>' +
      '<div class="mid"><div class="t">' + fmtTime(x.start) + ' – ' + fmtTime(x.end) + '</div><div class="s">' + esc(x.room || sub.room || 'Sin aula') + '</div></div></button>';
  }).join('') + '<button class="add-row" data-a="new-class" data-sub="' + sub.id + '">' + icon('plus', 20) + 'Agregar clase al horario</button></div>';

  // historial
  var done = S.acts.filter(function (a) { return a.subjectId === sub.id && !isOpen(a); }).sort(function (a, b) { return (b.completedAt || 0) - (a.completedAt || 0); });
  if (done.length) html += '<div class="sec">' + secHead('Historial de tareas') + done.slice(0, 15).map(taskRow).join('') + '</div>';

  html += '<p class="meta" style="text-align:center;padding-top:30px">' + plural(open.length + done.length, 'actividad', 'actividades') + ' · ' + plural(notes.length, 'apunte', 'apuntes') +
    (sub.created ? '<br>Agregada el ' + new Date(sub.created).getDate() + ' de ' + MONTHS[new Date(sub.created).getMonth()] + ' de ' + new Date(sub.created).getFullYear() : '') + '</p>';
  return { title: sub.name, back: e.back || 'Materias', large: false, right: '<button class="circle-btn" data-a="sub-menu" data-id="' + sub.id + '" aria-label="Opciones">' + icon('more', 20) + '</button>', html: html, th: 300 };
};

/* ================= TAREAS ================= */
function taskRow(a) {
  var late = isOverdue(a), sub = getSub(a.subjectId);
  var when = a.status === 'completada' ? 'Completada ' + (a.completedAt ? relDay(new Date(a.completedAt)).toLowerCase() : '') : (late ? 'Atrasada · ' : '') + fmtDue(a);
  return '<div class="trow ' + a.status + '" id="tr-' + a.id + '"><button class="st ' + a.status + '" data-a="cycle-status" data-id="' + a.id + '" aria-label="Estado: ' + STATUS_T[a.status] + '">' + statusIcon(a.status) + '</button>' +
    '<button class="mid tap" style="text-align:left" data-a="open-act" data-id="' + a.id + '"><div class="t">' + (a.kind === 'examen' ? '<span class="kind">Examen</span>' : '') + esc(a.title) + '</div>' +
    '<div class="s' + (late ? ' bad' : '') + '">' + (sub ? '<i class="dot" style="background:' + sub.color + '"></i>' + esc(sub.name) + ' · ' : '') + esc(when) + '</div></button>' +
    '<div class="side">' + prioMarks(a.priority) + (a.files && a.files.length ? icon('clip', 16) : '') + '</div>' +
    '<button class="icon-btn sm" data-a="act-menu" data-id="' + a.id + '" aria-label="Opciones">' + icon('more', 20) + '</button></div>';
}
VIEWS.tasks = function (e) {
  var f = e.f || 'activas', now = new Date();
  var all = S.acts.filter(function (a) { return a.kind !== 'evento'; });
  var cnt = {
    activas: all.filter(isOpen).length,
    proceso: all.filter(function (a) { return a.status === 'proceso'; }).length,
    examenes: all.filter(function (a) { return a.kind === 'examen' && isOpen(a); }).length,
    completadas: all.filter(function (a) { return !isOpen(a); }).length
  };
  var right = '<button class="circle-btn" data-a="new-act" aria-label="Nueva tarea">' + icon('plus', 20) + '</button>';
  var chips = '<div class="chips">' + [['activas', 'Por hacer'], ['proceso', 'En proceso'], ['examenes', 'Exámenes'], ['completadas', 'Completadas']].map(function (x) {
    return '<button class="chip' + (f === x[0] ? ' on' : '') + '" data-a="task-filter" data-v="' + x[0] + '">' + x[1] + '<span class="n">' + cnt[x[0]] + '</span></button>';
  }).join('') + '</div>';
  var list;
  if (f === 'completadas') list = all.filter(function (a) { return !isOpen(a); }).sort(function (a, b) { return (b.completedAt || 0) - (a.completedAt || 0); });
  else if (f === 'proceso') list = all.filter(function (a) { return a.status === 'proceso'; }).sort(byDue);
  else if (f === 'examenes') list = all.filter(function (a) { return a.kind === 'examen' && isOpen(a); }).sort(byDue);
  else list = all.filter(isOpen).sort(byDue);
  var html = chips;
  if (!all.length) {
    html += empty('tasks', 'Sin tareas por ahora', 'Agrega tareas y exámenes con fecha, prioridad y archivos. Te avisamos antes de que se venzan.', '<button class="pill solid sm" data-a="new-act">Nueva tarea</button>');
    return { title: 'Tareas', right: right, html: html };
  }
  if (!list.length) {
    var msg = { activas: ['Todo al día', 'No tienes tareas pendientes.'], proceso: ['Nada en proceso', 'Cuando empieces una tarea, márcala como en proceso tocando el círculo.'],
      examenes: ['Sin exámenes próximos', 'Agrega tus exámenes para ver cuánto necesitas sacar.'], completadas: ['Nada completado aún', 'Las tareas que termines aparecerán aquí.'] }[f];
    html += '<div class="empty sm"><div class="eic">' + icon(f === 'activas' ? 'check' : 'tasks', 44) + '</div><h3>' + msg[0] + '</h3><p>' + msg[1] + '</p></div>';
    return { title: 'Tareas', right: right, html: html };
  }
  if (f === 'completadas') { html += '<div style="margin-top:10px">' + list.map(taskRow).join('') + '</div>'; return { title: 'Tareas', right: right, html: html }; }
  var groups = [['late', 'Atrasadas'], ['today', 'Hoy'], ['tomorrow', 'Mañana'], ['week', 'Esta semana'], ['later', 'Más adelante']], g = {};
  list.forEach(function (a) {
    var n = dayDiff(pymd(a.date)), k;
    if (isOverdue(a, now)) k = 'late'; else if (n <= 0) k = 'today'; else if (n === 1) k = 'tomorrow'; else if (n < 7) k = 'week'; else k = 'later';
    (g[k] = g[k] || []).push(a);
  });
  groups.forEach(function (x) {
    if (!g[x[0]]) return;
    html += '<div class="grp-h' + (x[0] === 'late' ? ' bad' : '') + '">' + x[1] + '</div>' + g[x[0]].map(taskRow).join('');
  });
  return { title: 'Tareas', right: right, html: html };
};

/* ================= DETALLE DE ACTIVIDAD ================= */
VIEWS.act = function (e) {
  var a = getAct(e.id);
  if (!a) return null;
  var sub = getSub(a.subjectId), late = isOverdue(a), due = actDue(a), now = new Date();
  var html = '<div class="act-head"><div class="cvw">' + actCover(a, 's') + '</div><div style="flex:1;min-width:0"><div class="eyebrow">' + KIND[a.kind] + (sub ? ' · ' + esc(sub.name) : '') + '</div><h1>' + esc(a.title) + '</h1></div></div>';
  html += '<p class="act-due' + (late ? ' bad' : '') + '">' + esc(longDate(pymd(a.date)) + (a.time ? ', ' + fmtTime(a.time) : '') + ' · ' + (isOpen(a) ? (late ? 'venció ' : 'vence ') + countdown(due - now) : 'completada')) + '</p>';
  if (a.kind !== 'evento') {
    html += '<div class="seg" style="margin-top:18px">' + ['pendiente', 'proceso', 'completada'].map(function (v) {
      return '<button class="' + (a.status === v ? 'on' : '') + '" data-a="set-status" data-id="' + a.id + '" data-v="' + v + '">' + STATUS_T[v] + '</button>';
    }).join('') + '</div>';
  }
  html += '<div class="pill-btns" style="margin-top:14px"><button class="pill tap" data-a="focus-act" data-id="' + a.id + '">' + icon('play', 18) + 'Estudiar</button>' +
    (a.kind === 'evento' ? '<button class="pill tap" data-a="edit-act" data-id="' + a.id + '">' + icon('pencil', 18) + 'Editar</button>'
      : isOpen(a) ? '<button class="pill tap" data-a="set-status" data-id="' + a.id + '" data-v="completada">' + icon('check', 20) + 'Completar</button>'
        : '<button class="pill tap" data-a="set-status" data-id="' + a.id + '" data-v="pendiente">' + icon('rew', 18) + 'Reabrir</button>') + '</div>';
  if (sub && a.kind !== 'evento') {
    var c = calcSubject(sub), g = gradeForAct(a), gv = g ? parseNum(g.grade) : null;
    html += '<div class="need-card">' + (gv !== null ? 'Sacaste <b>' + fmtG(gv) + '</b> en esta actividad. ' : '') + gradeSentence(sub, c) +
      '<div style="margin-top:12px"><button class="pill sm" data-a="act-grade" data-id="' + a.id + '">' + icon('grade', 18) + (g ? 'Editar nota' : 'Registrar nota') + '</button></div></div>';
  }
  if (a.desc) html += '<div class="sec">' + secHead('Descripción') + '<p class="desc">' + esc(a.desc) + '</p></div>';
  html += '<div class="sec">' + secHead('Archivos adjuntos') + '<div class="files">' + (a.files || []).map(function (f) { return fileTile(f, false); }).join('') +
    '<button class="file add tap" data-a="attach" data-tag="act:' + a.id + '" data-mode="file"><span class="fi">' + icon('clip', 24) + 'Archivo</span></button>' +
    '<button class="file add tap" data-a="attach" data-tag="act:' + a.id + '" data-mode="photo"><span class="fi">' + icon('camera', 24) + 'Foto</span></button></div></div>';
  var rem = (a.rem || []).slice().sort(function (x, y) { return y - x; }).map(function (m) { return REM_SHORT[m]; }).join(', ') || 'Ninguno';
  html += '<div class="fg">' + '<div class="group">' +
    (a.kind !== 'evento' ? '<div class="cell"><span class="cl">Prioridad</span><span class="cv">' + PRIO[a.priority || 0] + '</span></div>' : '') +
    '<div class="cell"><span class="cl">Recordatorios</span><span class="cv">' + esc(rem) + '</span></div>' +
    (a.focusMs ? '<div class="cell"><span class="cl">Tiempo de estudio</span><span class="cv">' + span(a.focusMs) + '</span></div>' : '') +
    (a.created ? '<div class="cell"><span class="cl">Creada</span><span class="cv">' + shortDate(new Date(a.created)) + '</span></div>' : '') +
    (sub ? '<button class="cell tap" data-a="open-subject" data-id="' + sub.id + '"><span class="cl">Ver materia</span><span class="cv">' + esc(sub.name) + icon('chev_r', 18) + '</span></button>' : '') +
    '</div></div>';
  html += '<div class="fg"><div class="group"><button class="cell danger" data-a="delete-act" data-id="' + a.id + '">Eliminar ' + KIND[a.kind].toLowerCase() + '</button></div></div>';
  return { title: a.title, back: e.back || 'Tareas', large: false, th: 110, right: '<button class="nb-back" style="padding:0 12px" data-a="edit-act" data-id="' + a.id + '">Editar</button>', html: html };
};

/* ================= CALENDARIO ================= */
VIEWS.calendar = function (e) {
  var mode = e.mode || 'mes';
  var html = '<div class="seg" style="margin-top:2px">' + [['mes', 'Mes'], ['semana', 'Semana'], ['horario', 'Horario']].map(function (x) {
    return '<button class="' + (mode === x[0] ? 'on' : '') + '" data-a="cal-mode" data-v="' + x[0] + '">' + x[1] + '</button>';
  }).join('') + '</div>';
  if (mode === 'semana') html += weekView(e);
  else if (mode === 'horario') html += horarioView(e);
  else html += monthView(e);
  return { title: 'Calendario', right: '<button class="circle-btn" data-a="cal-add" aria-label="Agregar">' + icon('plus', 20) + '</button>', html: html,
    after: mode === 'mes' ? bindMonthSwipe : null };
};
function actsByDay() {
  var m = {};
  S.acts.forEach(function (a) { (m[a.date] = m[a.date] || []).push(a); });
  return m;
}
function monthView(e) {
  var sel = e.sel || ymd(new Date()), selD = pymd(sel);
  var m0 = e.m ? pymd(e.m) : new Date(selD.getFullYear(), selD.getMonth(), 1);
  var first = new Date(m0.getFullYear(), m0.getMonth(), 1), dim = new Date(m0.getFullYear(), m0.getMonth() + 1, 0).getDate();
  var start = monday(first), rows = Math.ceil((dow(first) - 1 + dim) / 7), map = actsByDay(), todayS = ymd(new Date());
  var html = '<div class="cal-head"><div class="cal-month">' + MONTHS[first.getMonth()] + ' <span>' + first.getFullYear() + '</span></div>' +
    '<div class="cal-nav"><button class="icon-btn" data-a="cal-prev" aria-label="Mes anterior">' + icon('chev_l', 22) + '</button><button class="today" data-a="cal-today">Hoy</button>' +
    '<button class="icon-btn" data-a="cal-next" aria-label="Mes siguiente">' + icon('chev_r', 22) + '</button></div></div>';
  html += '<div class="cal-wd">' + [1, 2, 3, 4, 5, 6, 7].map(function (d) { return '<span>' + DAY_LETTER[d] + '</span>'; }).join('') + '</div><div class="cal-grid" id="calgrid">';
  for (var i = 0; i < rows * 7; i++) {
    var d = addDays(start, i), k = ymd(d), list = map[k] || [];
    var cols = [];
    list.forEach(function (a) { var c = a.subjectId ? subColor(a.subjectId) : 'var(--accent)'; if (cols.indexOf(c) < 0 && cols.length < 3) cols.push(c); });
    html += '<button class="cd' + (d.getMonth() !== first.getMonth() ? ' out' : '') + (dow(d) > 5 ? ' we' : '') + (k === todayS ? ' today' : '') + (k === sel ? ' sel' : '') + '" data-a="cal-sel" data-d="' + k + '">' +
      '<span class="n">' + d.getDate() + '</span><span class="dots">' + cols.map(function (c) { return '<i style="background:' + c + '"></i>'; }).join('') + '</span></button>';
  }
  html += '</div><div class="cal-sep"></div>' + dayAgenda(selD, map[sel] || []);
  return html;
}
function bindMonthSwipe(page) {
  var g = $('#calgrid', page); if (!g) return;
  var x0 = null, y0 = null;
  g.addEventListener('touchstart', function (ev) { x0 = ev.touches[0].clientX; y0 = ev.touches[0].clientY; }, { passive: true });
  g.addEventListener('touchend', function (ev) {
    if (x0 === null) return;
    var dx = ev.changedTouches[0].clientX - x0, dy = ev.changedTouches[0].clientY - y0; x0 = null;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) runAction(dx < 0 ? 'cal-next' : 'cal-prev', {});
  });
}
function dayAgenda(d, acts) {
  var cls = classesOn(dow(d)), rows = [];
  cls.forEach(function (c) {
    var sub = getSub(c.subjectId); if (!sub) return;
    rows.push({ m: tmin(c.start), h: '<button class="crow cls tap" data-a="open-subject" data-id="' + sub.id + '"><div class="tm">' + fmtTime(c.start) + '<br><span style="color:var(--label3)">' + fmtTime(c.end) + '</span></div>' +
      '<div class="bar2" style="background:' + sub.color + ';opacity:.5"></div><div class="mid"><div class="t">' + esc(sub.name) + '</div><div class="s">Clase' + ((c.room || sub.room) ? ' · ' + esc(c.room || sub.room) : '') + '</div></div></button>' });
  });
  acts.forEach(function (a) {
    var sub = getSub(a.subjectId);
    rows.push({ m: a.time ? tmin(a.time) : -1, h: '<button class="crow tap' + (isOpen(a) ? '' : ' done') + '" data-a="open-act" data-id="' + a.id + '"><div class="tm">' + (a.time ? fmtTime(a.time) : 'Todo el día') + '</div>' +
      '<div class="bar2" style="background:' + (sub ? sub.color : 'var(--accent)') + '"></div><div class="mid"><div class="t">' + esc(a.title) + '</div><div class="s">' + KIND[a.kind] + (sub ? ' · ' + esc(sub.name) : '') + (a.kind !== 'evento' ? ' · ' + STATUS_T[a.status] : '') + '</div></div></button>' });
  });
  rows.sort(function (x, y) { return x.m - y.m; });
  var n = dayDiff(d);
  var html = '<div class="agenda-h">' + esc(longDate(d)) + '</div><div class="agenda-sub">' + (n === 0 ? 'Hoy · ' : n === 1 ? 'Mañana · ' : '') +
    (acts.length ? plural(acts.length, 'actividad', 'actividades') : 'Sin actividades') + (cls.length ? ' · ' + plural(cls.length, 'clase', 'clases') : '') + '</div>';
  html += rows.map(function (r) { return r.h; }).join('');
  html += '<button class="add-row" data-a="new-act" data-date="' + ymd(d) + '">' + icon('plus', 20) + 'Agregar actividad este día</button>';
  return html;
}
function weekView(e) {
  var wk = e.w ? pymd(e.w) : monday(new Date()), now = new Date(), map = actsByDay(), todayS = ymd(now);
  var nd = scheduleDays();
  for (var x = 6; x <= 7; x++) if ((map[ymd(addDays(wk, x - 1))] || []).length && x > nd) nd = x;
  var mins = [], maxs = [];
  S.classes.forEach(function (c) { if (c.day <= nd) { mins.push(tmin(c.start)); maxs.push(tmin(c.end)); } });
  for (var i = 0; i < nd; i++) (map[ymd(addDays(wk, i))] || []).forEach(function (a) { if (a.time) { mins.push(tmin(a.time)); maxs.push(tmin(a.time) + 30); } });
  var h0 = Math.floor((mins.length ? Math.min.apply(null, mins) : 7 * 60) / 60), h1 = Math.ceil((maxs.length ? Math.max.apply(null, maxs) : 14 * 60) / 60);
  h0 = Math.min(h0, 7); h1 = Math.max(h1, h0 + 6);
  var PX = 0.9, H = (h1 - h0) * 60 * PX, end = addDays(wk, nd - 1);
  var title = wk.getMonth() === end.getMonth() ? wk.getDate() + ' – ' + end.getDate() + ' de ' + MONTHS[wk.getMonth()] : wk.getDate() + ' ' + MONTHS_S[wk.getMonth()] + ' – ' + end.getDate() + ' ' + MONTHS_S[end.getMonth()];
  var html = '<div class="cal-head"><div class="cal-month" style="text-transform:none">' + title + '</div><div class="cal-nav">' +
    '<button class="icon-btn" data-a="wk-prev" aria-label="Semana anterior">' + icon('chev_l', 22) + '</button><button class="today" data-a="wk-today">Hoy</button>' +
    '<button class="icon-btn" data-a="wk-next" aria-label="Semana siguiente">' + icon('chev_r', 22) + '</button></div></div><div class="wk">';
  var head = '', all = '', cols = '', anyAll = false;
  for (var d = 0; d < nd; d++) {
    var date = addDays(wk, d), k = ymd(date), isToday = k === todayS, acts = map[k] || [];
    head += '<div class="wd' + (isToday ? ' today' : '') + '"><span>' + DAYS_S[date.getDay()] + '</span><b>' + date.getDate() + '</b></div>';
    var untimed = acts.filter(function (a) { return !a.time; });
    if (untimed.length) anyAll = true;
    all += '<div class="col">' + untimed.map(function (a) {
      return '<button class="ev" data-a="open-act" data-id="' + a.id + '" style="background:' + (a.subjectId ? subColor(a.subjectId) : 'var(--accent)') + (isOpen(a) ? '' : ';opacity:.45') + '">' + esc(a.title) + '</button>';
    }).join('') + '</div>';
    var col = '<div class="wk-col' + (isToday ? ' today' : '') + '">';
    classesOn(dow(date)).forEach(function (c) {
      var sub = getSub(c.subjectId); if (!sub) return;
      var top = (tmin(c.start) - h0 * 60) * PX, hh = Math.max(18, (tmin(c.end) - tmin(c.start)) * PX - 2);
      var st = atTime(date, c.start), en = atTime(date, c.end);
      var cl = now >= st && now < en ? ' now' : now >= en ? ' past' : '';
      col += '<button class="blk' + cl + '" data-a="open-subject" data-id="' + sub.id + '" style="top:' + top + 'px;height:' + hh + 'px;background:' + sub.color + '"><b>' + esc(sub.name) + '</b><span>' + fmtTimeShort(c.start) + '</span></button>';
    });
    acts.filter(function (a) { return a.time; }).forEach(function (a) {
      col += '<button class="wk-ev" data-a="open-act" data-id="' + a.id + '" style="top:' + ((tmin(a.time) - h0 * 60) * PX - 9) + 'px">' + esc(a.kind === 'examen' ? 'Examen' : a.title) + '</button>';
    });
    if (isToday) { var nm = nowMin(now); if (nm >= h0 * 60 && nm <= h1 * 60) col += '<div class="nowline" style="top:' + ((nm - h0 * 60) * PX) + 'px"></div>'; }
    cols += col + '</div>';
  }
  var hours = '', lines = '';
  for (var hr = h0; hr <= h1; hr++) {
    var y = (hr - h0) * 60 * PX;
    hours += '<span style="top:' + y + 'px">' + (hr % 12 || 12) + (hr < 12 ? ' a. m.' : ' p. m.') + '</span>';
    lines += '<div class="line" style="top:' + y + 'px"></div>';
  }
  html += '<div class="wk-head">' + head + '</div>' + (anyAll ? '<div class="wk-all">' + all + '</div>' : '') +
    '<div class="wk-body" style="height:' + (H + 20) + 'px;margin-top:10px"><div class="wk-hours">' + hours + '</div><div class="wk-cols" style="height:' + H + 'px">' + lines + cols + '</div></div></div>';
  if (!S.classes.length) html += '<div class="empty sm"><h3>Tu horario está vacío</h3><p>Agrega tus clases en la pestaña Horario y aparecerán aquí cada semana.</p><button class="pill sm" data-a="cal-mode" data-v="horario">Ir al horario</button></div>';
  return html;
}
function horarioView(e) {
  var nd = scheduleDays(), now = new Date(), td = dow(now);
  var hd = e.hd || (td <= nd ? td : 1), wk = monday(now);
  var html = '<div class="hz-days">';
  for (var d = 1; d <= nd; d++) {
    var date = addDays(wk, d - 1);
    html += '<button class="hz-day' + (d === hd ? ' on' : '') + '" data-a="hz-day" data-v="' + d + '"><span>' + DAYS_S[d % 7].toUpperCase() + '</span><b>' + date.getDate() + '</b>' + (d === td ? '<i class="tdot"></i>' : '') + '</button>';
  }
  html += '</div>';
  if (!S.classes.length) {
    return html + empty('calendar', 'Arma tu horario', 'Agrega tus clases una vez y la app te dirá siempre cuál es la clase actual y la siguiente.', '<button class="pill solid sm" data-a="new-class" data-day="' + hd + '">Agregar clase</button>');
  }
  var list = classesOn(hd), isToday = hd === td, nm = nowMin(now), nextFound = false;
  html += '<div class="hz-title">' + DAY_NAMES[hd] + (isToday ? ' · hoy' : '') + '</div>';
  if (!list.length) html += '<p class="mini-empty" style="padding-bottom:8px">No tienes clases este día.</p>';
  list.forEach(function (c, i) {
    var sub = getSub(c.subjectId); if (!sub) return;
    if (i > 0) {
      var gap = tmin(c.start) - tmin(list[i - 1].end);
      if (gap >= 10) html += '<div class="hz-gap"><span>Descanso · ' + span(gap * 60000) + '</span></div>';
    }
    var s0 = tmin(c.start), s1 = tmin(c.end), state = '';
    if (isToday) {
      if (nm >= s0 && nm < s1) state = 'now';
      else if (nm >= s1) state = 'past';
      else if (!nextFound) { state = 'next'; nextFound = true; }
    }
    var tag = state === 'now' ? 'AHORA · QUEDAN ' + span((s1 - nm) * 60000).toUpperCase() : state === 'next' ? 'SIGUIENTE · ' + countdown((s0 - nm) * 60000).toUpperCase() : '';
    html += '<button class="hz tap ' + state + '" data-a="edit-class" data-id="' + c.id + '" style="--c:' + sub.color + '"><div class="tm"><b>' + fmtTimeShort(c.start) + '</b><span>' + fmtTimeShort(c.end) + '</span></div>' +
      '<div class="card">' + (tag ? '<div class="tag">' + tag + '</div>' : '') + '<div class="t">' + esc(sub.name) + '</div><div class="s">' + esc([sub.teacher, c.room || sub.room].filter(Boolean).join(' · ') || 'Toca para editar') + '</div>' +
      (state === 'now' ? '<div class="hp"><i style="width:' + ((nm - s0) / (s1 - s0) * 100).toFixed(1) + '%"></i></div>' : '') + '</div></button>';
  });
  html += '<button class="add-row" data-a="new-class" data-day="' + hd + '">' + icon('plus', 20) + 'Agregar clase el ' + DAY_NAMES[hd] + '</button>';
  return html;
}

/* ================= PERFIL ================= */
VIEWS.profile = function () {
  var p = S.profile, st = S.settings, s = sc(), ov = overallAvg();
  var html = '<div class="prof"><button data-a="pick-avatar" aria-label="Cambiar foto">' + avatarHtml('') + '</button>' +
    '<h1>' + esc(p.name || 'Estudiante') + '</h1><div class="ps">' + esc([p.school, p.level].filter(Boolean).join(' · ') || 'Toca Editar para agregar tu colegio') + '</div>' +
    '<button class="pill sm tap" data-a="edit-profile">Editar perfil</button></div>';
  var good = 0, withGrades = 0;
  S.subjects.forEach(function (sub) { var c = calcSubject(sub); if (c.status !== 'empty') { withGrades++; if (c.status === 'ok' || c.status === 'secured') good++; } });
  var weekAgo = Date.now() - 7 * 864e5;
  var doneWeek = S.acts.filter(function (a) { return !isOpen(a) && (a.completedAt || 0) > weekAgo; }).length;
  html += '<div class="fg"><div class="fg-h">Tu progreso</div><div class="group">' +
    '<div class="cell"><span class="cl">Promedio general</span><span class="cv stat-num">' + (ov ? fmtAcc(ov.avg) : '—') + '</span></div>' +
    '<div class="cell"><span class="cl">Materias que vas pasando</span><span class="cv stat-num">' + good + ' de ' + withGrades + '</span></div>' +
    '<div class="cell"><span class="cl">Tareas completadas esta semana</span><span class="cv stat-num">' + doneWeek + '</span></div>' +
    '<div class="cell"><span class="cl">Tiempo de estudio</span><span class="cv stat-num">' + (S.stats.focusMs ? span(S.stats.focusMs) : '0 min') + '</span></div></div></div>';

  html += '<div class="fg"><div class="fg-h">Apariencia</div><div class="group">' +
    '<div class="cell stack"><span class="cl">Tema</span><div class="seg">' + [['dark', 'Oscuro'], ['light', 'Claro'], ['auto', 'Automático']].map(function (x) {
      return '<button class="' + (st.theme === x[0] ? 'on' : '') + '" data-a="set-theme" data-v="' + x[0] + '">' + x[1] + '</button>';
    }).join('') + '</div></div>' +
    '<div class="cell stack" style="padding-bottom:4px"><span class="cl">Color de acento</span><div class="swatches" style="padding:4px 4px 10px">' + ACCENTS.map(function (a) {
      return '<button class="swatch' + (st.accent.toUpperCase() === a.c ? ' on' : '') + '" style="background:' + a.c + '" data-a="set-accent" data-v="' + a.c + '" aria-label="' + a.n + '"></button>';
    }).join('') + '</div></div>' +
    '<button class="cell" data-a="toggle-fx"><span class="cl">Transparencias<small>Apágalas si el celular va lento</small></span><span class="sw' + (fxOn() ? ' on' : '') + '"></span></button>' +
    '<button class="cell" data-a="toggle-motion"><span class="cl">Animaciones</span><span class="sw' + (motionOn() ? ' on' : '') + '"></span></button></div></div>';

  html += '<div class="fg"><div class="fg-h">Calificaciones</div><div class="group">' +
    '<button class="cell" data-a="edit-scale"><span class="cl">Escala de notas</span><span class="cv">' + fmtG(s.min) + ' a ' + fmtG(s.max) + ' · aprueba ' + fmtG(s.pass) + icon('chev_r', 18) + '</span></button>' +
    '<div class="cell stack"><span class="cl">En materias nuevas, las notas</span><div class="seg">' +
    '<button class="' + (st.defMode !== 'equal' ? 'on' : '') + '" data-a="set-defmode" data-v="pct">Por porcentajes</button>' +
    '<button class="' + (st.defMode === 'equal' ? 'on' : '') + '" data-a="set-defmode" data-v="equal">Valen igual</button></div></div></div>' +
    '<div class="fg-f">Cada materia puede usar su propia forma de cálculo; se cambia en la página de la materia.</div></div>';

  var can = Native ? nat('canNotify') : null;
  html += '<div class="fg"><div class="fg-h">Recordatorios</div><div class="group">' +
    (Native ? '<button class="cell" data-a="notif-perm"><span class="cl">Notificaciones</span><span class="cv" style="color:' + (can ? 'var(--green)' : 'var(--orange)') + '">' + (can ? 'Activadas' : 'Activar') + icon('chev_r', 18) + '</span></button>' : '') +
    '<div class="cell stack"><span class="cl">Avisos por defecto en tareas nuevas</span><div class="mchips" style="padding:0">' + REM_OPTS.map(function (o) {
      return '<button class="chip' + (st.defRem.indexOf(o.m) >= 0 ? ' on' : '') + '" data-a="toggle-defrem" data-v="' + o.m + '">' + REM_SHORT[o.m] + '</button>';
    }).join('') + '</div></div>' +
    '<div class="cell stack"><span class="cl">Avisarme antes de cada clase</span><div class="seg">' + [0, 5, 10, 15].map(function (m) {
      return '<button class="' + (+st.classRem === m ? 'on' : '') + '" data-a="set-classrem" data-v="' + m + '">' + (m ? m + ' min' : 'No') + '</button>';
    }).join('') + '</div></div>' +
    '<div class="cell stack"><span class="cl">Duración de las sesiones de estudio</span><div class="seg">' + [15, 25, 45, 60].map(function (m) {
      return '<button class="' + (+st.focusMin === m ? 'on' : '') + '" data-a="focus-min" data-m="' + m + '">' + m + ' min</button>';
    }).join('') + '</div></div>' +
    (Native ? '<button class="cell btn" data-a="test-notif">Enviar notificación de prueba</button>' : '') + '</div></div>';

  html += '<div class="fg"><div class="fg-h">Tus datos</div><div class="group">' +
    '<button class="cell btn" data-a="export"><span class="cl">Guardar copia de seguridad</span>' + icon('share', 20) + '</button>' +
    '<button class="cell btn" data-a="import"><span class="cl">Restaurar copia de seguridad</span>' + icon('download', 20) + '</button>' +
    '<button class="cell btn" data-a="load-demo"><span class="cl">Cargar datos de ejemplo</span></button>' +
    '<button class="cell danger" data-a="wipe">Borrar todos los datos</button></div>' +
    '<div class="fg-f">Todo se guarda solo en este celular y funciona sin internet. Haz una copia antes de cambiar de celular o desinstalar la app. Los archivos adjuntos no se incluyen en la copia.</div></div>';
  html += '<p class="meta" style="text-align:center;padding:30px 20px 0">' + APP_NAME + ' · versión 1.0</p>';
  return { title: 'Perfil', html: html };
};
