/* Que Pasa Hermano — datos, cálculos y utilidades.
   Escrito en JavaScript compatible con WebView antiguos (sin ?. ni ??). */
'use strict';

var APP_NAME = 'Que Pasa Hermano';
var Native = (typeof window.Android === 'object' && window.Android) ? window.Android : null;

function nat(fn) {
  if (!Native) return undefined;
  try {
    if (typeof Native[fn] !== 'function') return undefined;
    var args = Array.prototype.slice.call(arguments, 1);
    return Native[fn].apply(Native, args);
  } catch (e) { return undefined; }
}

/* ---------- utilidades ---------- */
function $(s, r) { return (r || document).querySelector(s); }
function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
function esc(s) {
  return String(s === undefined || s === null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
function pad(n) { return (n < 10 ? '0' : '') + n; }
function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
function plural(n, one, many) { return n + ' ' + (n === 1 ? one : many); }
function find(arr, fn) { for (var i = 0; i < arr.length; i++) if (fn(arr[i], i)) return arr[i]; return null; }
function hashStr(s) {
  var h = 0; s = String(s);
  for (var i = 0; i < s.length; i++) { h = ((h << 5) - h + s.charCodeAt(i)) | 0; }
  return (h & 0x7fffffff) || 1;
}
function deepCopy(o) { return JSON.parse(JSON.stringify(o)); }

/* ---------- fechas ---------- */
var DAYS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
var DAYS_S = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
var DAY_LETTER = ['', 'L', 'M', 'M', 'J', 'V', 'S', 'D'];
var DAY_NAMES = ['', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];
var MONTHS = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
var MONTHS_S = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sept', 'oct', 'nov', 'dic'];

function today0() { var d = new Date(); d.setHours(0, 0, 0, 0); return d; }
function day0(d) { var x = new Date(d.getTime()); x.setHours(0, 0, 0, 0); return x; }
function addDays(d, n) { var x = new Date(d.getTime()); x.setDate(x.getDate() + n); return x; }
function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
function pymd(s) { var p = String(s).split('-'); return new Date(+p[0], (+p[1]) - 1, +p[2]); }
function dow(d) { var x = d.getDay(); return x === 0 ? 7 : x; }          // 1 = lunes … 7 = domingo
function monday(d) { return addDays(day0(d), 1 - dow(d)); }
function tmin(hm) { var p = String(hm).split(':'); return (+p[0]) * 60 + (+p[1]); }
function minToHm(m) { m = clamp(Math.round(m), 0, 24 * 60 - 1); return pad(Math.floor(m / 60)) + ':' + pad(m % 60); }
function atTime(d, hm) { var x = day0(d); var m = tmin(hm); x.setHours(Math.floor(m / 60), m % 60, 0, 0); return x; }
function nowMin(d) { d = d || new Date(); return d.getHours() * 60 + d.getMinutes(); }
function dayDiff(d) { return Math.round((day0(d).getTime() - today0().getTime()) / 864e5); }

function fmtTime(hm) {
  if (!hm) return '';
  var m = tmin(hm), h = Math.floor(m / 60), mm = pad(m % 60);
  return (h % 12 || 12) + ':' + mm + (h < 12 ? ' a. m.' : ' p. m.');
}
function fmtTimeShort(hm) { var m = tmin(hm), h = Math.floor(m / 60); return (h % 12 || 12) + ':' + pad(m % 60); }
function aLas(hm) { var h = Math.floor(tmin(hm) / 60) % 12; return (h === 1 ? 'a la ' : 'a las ') + fmtTime(hm); }
function longDate(d) { return cap(DAYS[d.getDay()]) + ' ' + d.getDate() + ' de ' + MONTHS[d.getMonth()]; }
function shortDate(d) { return cap(DAYS_S[d.getDay()]) + ' ' + d.getDate() + ' ' + MONTHS_S[d.getMonth()]; }
function relDay(d) {
  var n = dayDiff(d);
  if (n === 0) return 'Hoy';
  if (n === 1) return 'Mañana';
  if (n === -1) return 'Ayer';
  if (n > 1 && n < 7) return cap(DAYS[d.getDay()]);
  return shortDate(d);
}
function relPhrase(d) {
  var n = dayDiff(d);
  if (n === 0) return 'hoy';
  if (n === 1) return 'mañana';
  if (n > 1 && n < 7) return 'el ' + DAYS[d.getDay()];
  return 'el ' + d.getDate() + ' de ' + MONTHS[d.getMonth()];
}
function span(ms) {
  var m = Math.round(Math.abs(ms) / 6e4);
  if (m < 1) return 'menos de 1 min';
  if (m < 60) return m + ' min';
  if (m < 60 * 24) { var h = Math.floor(m / 60), r = m % 60; return h + ' h' + (r && h < 6 ? ' ' + r + ' min' : ''); }
  var dd = Math.round(m / 1440); return dd + (dd === 1 ? ' día' : ' días');
}
function countdown(ms) { return ms < 0 ? 'hace ' + span(ms) : 'en ' + span(ms); }
function clock(ms) { var s = Math.max(0, Math.round(ms / 1000)); var m = Math.floor(s / 60); return m + ':' + pad(s % 60); }

/* ---------- estado ---------- */
var STORE_KEY = 'qph-data-v1';
var SUBJECT_COLORS = ['#E5383B', '#F2600C', '#C98500', '#2F9E44', '#0F9D8A', '#1F7AE0', '#4F55D9', '#8A4FD0', '#D9367B', '#5E5E63'];
var ACCENTS = [
  { c: '#FA2D48', n: 'Rojo' }, { c: '#FF6A2B', n: 'Naranja' }, { c: '#30B85B', n: 'Verde' },
  { c: '#0A84FF', n: 'Azul' }, { c: '#7D5CFF', n: 'Violeta' }
];

function defaultState() {
  return {
    v: 1, onboarded: false,
    profile: { name: '', school: '', level: '', avatar: null },
    settings: {
      theme: 'dark', accent: '#FA2D48', fx: null, motion: true,
      scale: { min: 0, max: 5, pass: 3, dec: 1 },
      defMode: 'pct', defRem: [1440, 60], classRem: 0, focusMin: 25
    },
    subjects: [], classes: [], acts: [], notes: [],
    focus: null, stats: { focusMs: 0 }
  };
}

function migrate(s) {
  var d = defaultState();
  if (!s || typeof s !== 'object') return d;
  s.settings = Object.assign({}, d.settings, s.settings || {});
  s.settings.scale = Object.assign({}, d.settings.scale, (s.settings && s.settings.scale) || {});
  s.profile = Object.assign({}, d.profile, s.profile || {});
  s.stats = Object.assign({}, d.stats, s.stats || {});
  ['subjects', 'classes', 'acts', 'notes'].forEach(function (k) { if (!Array.isArray(s[k])) s[k] = []; });
  s.subjects.forEach(function (x) { if (!Array.isArray(x.grades)) x.grades = []; if (!x.mode) x.mode = 'pct'; });
  s.acts.forEach(function (a) { if (!Array.isArray(a.files)) a.files = []; if (!Array.isArray(a.rem)) a.rem = []; });
  s.notes.forEach(function (n) { if (!Array.isArray(n.files)) n.files = []; });
  if (s.focus === undefined) s.focus = null;
  s.v = 1;
  return s;
}

var S = defaultState();

function loadState() {
  var raw;
  if (Native) raw = nat('load');
  else { try { raw = localStorage.getItem(STORE_KEY); } catch (e) { raw = null; } }
  var parsed = null;
  try { parsed = raw ? JSON.parse(raw) : null; } catch (e) { parsed = null; }
  S = migrate(parsed);
}

var saveTimer = null;
function save() { if (saveTimer) clearTimeout(saveTimer); saveTimer = setTimeout(flush, 220); }
function flush() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  var json = JSON.stringify(S);
  if (Native) nat('save', json);
  else { try { localStorage.setItem(STORE_KEY, json); } catch (e) { /* sin espacio */ } }
  syncReminders();
}

/* ---------- acceso a datos ---------- */
function getSub(id) { return id ? find(S.subjects, function (x) { return x.id === id; }) : null; }
function getAct(id) { return find(S.acts, function (x) { return x.id === id; }); }
function getNote(id) { return find(S.notes, function (x) { return x.id === id; }); }
function getClass(id) { return find(S.classes, function (x) { return x.id === id; }); }
function subName(id) { var s = getSub(id); return s ? s.name : ''; }
function subColor(id) { var s = getSub(id); return s ? s.color : 'var(--label3)'; }

function actDue(a) {
  var d = pymd(a.date);
  if (a.time) { var m = tmin(a.time); d.setHours(Math.floor(m / 60), m % 60, 0, 0); }
  else d.setHours(23, 59, 0, 0);
  return d;
}
function actBase(a) { return a.time ? actDue(a) : atTime(pymd(a.date), '07:00'); }
function isOpen(a) { return a.status !== 'completada'; }
function isOverdue(a, now) { return isOpen(a) && a.kind !== 'evento' && actDue(a).getTime() < (now || new Date()).getTime(); }
function fmtDue(a) { var d = pymd(a.date); return relDay(d) + (a.time ? ', ' + fmtTime(a.time) : ''); }
function byDue(a, b) { return actDue(a) - actDue(b); }

var KIND = { tarea: 'Tarea', examen: 'Examen', evento: 'Evento' };
var PRIO = ['Ninguna', 'Baja', 'Media', 'Alta'];
var STATUS_T = { pendiente: 'Pendiente', proceso: 'En proceso', completada: 'Completada' };

function pendingWork() { return S.acts.filter(function (a) { return a.kind !== 'evento' && isOpen(a); }).sort(byDue); }

/* ---------- horario ---------- */
function classesOn(day) {
  return S.classes.filter(function (c) { return +c.day === day; }).sort(function (a, b) { return tmin(a.start) - tmin(b.start); });
}
function occ(c, date) { return { c: c, sub: getSub(c.subjectId), start: atTime(date, c.start), end: atTime(date, c.end) }; }
function currentClass(now) {
  now = now || new Date(); var m = nowMin(now);
  var list = classesOn(dow(now));
  for (var i = 0; i < list.length; i++) if (tmin(list[i].start) <= m && m < tmin(list[i].end)) return occ(list[i], now);
  return null;
}
function nextClass(now) {
  now = now || new Date(); var m = nowMin(now);
  for (var k = 0; k < 8; k++) {
    var date = addDays(day0(now), k), list = classesOn(dow(date));
    for (var i = 0; i < list.length; i++) if (k > 0 || tmin(list[i].start) > m) return occ(list[i], date);
  }
  return null;
}
function subjectDays(subId) {
  var days = {};
  S.classes.forEach(function (c) { if (c.subjectId === subId) days[c.day] = 1; });
  return Object.keys(days).map(Number).sort();
}
function scheduleDays() {
  var max = 5;
  S.classes.forEach(function (c) { if (+c.day > max) max = +c.day; });
  return max;
}

/* ---------- calificaciones ---------- */
function sc() { return S.settings.scale; }
function parseNum(v) {
  if (v === null || v === undefined) return null;
  var s = String(v).trim().replace(',', '.');
  if (s === '') return null;
  var n = Number(s);
  return isFinite(n) ? n : null;
}
function fmtG(x) { if (x === null || x === undefined || !isFinite(x)) return '—'; return x.toFixed(sc().dec); }
function fmtAcc(x) {
  if (x === null || x === undefined || !isFinite(x)) return '—';
  var d = sc().dec, s = x.toFixed(d + 1);
  if (s.charAt(s.length - 1) === '0') s = x.toFixed(d);
  return s;
}
function fmtPct(x) { var r = Math.round(x * 10) / 10; return (r % 1 === 0 ? r.toFixed(0) : r.toFixed(1)) + '%'; }
function ceilG(x) { var f = Math.pow(10, sc().dec); return Math.ceil(x * f - 1e-7) / f; }
function needLabel(x) { var s = sc(); if (x === null || x === undefined) return '—'; return fmtG(Math.max(s.min, ceilG(x))); }

function calcSubject(sub) {
  var s = sc(), items = sub.grades || [], n = items.length, eq = sub.mode === 'equal';
  var w = items.map(function (it) { return eq ? (n ? 100 / n : 0) : (parseNum(it.weight) || 0); });
  var total = 0; w.forEach(function (x) { total += x; });
  var gW = 0, acc = 0, graded = 0, sum = 0;
  items.forEach(function (it, i) {
    var g = parseNum(it.grade);
    if (g !== null) { gW += w[i]; acc += g * w[i] / 100; graded++; sum += g; }
  });
  var pending = n - graded;
  var rem = Math.max(0, 100 - gW);
  if (eq && pending === 0) rem = 0;
  var avg = gW > 0 ? acc * 100 / gW : null;
  if (eq && graded) avg = sum / graded;
  var maxP = acc + s.max * rem / 100, minP = acc + s.min * rem / 100;
  var need = rem > 0.0001 ? (s.pass - acc) * 100 / rem : null;
  var need1 = null;
  if (eq && pending === 0 && graded) need1 = s.pass * (graded + 1) - sum;
  var status;
  if (graded === 0) status = 'empty';
  else if (eq && pending === 0) status = avg >= s.pass - 1e-9 ? 'ok' : 'risk';
  else if (minP >= s.pass - 1e-9) status = 'secured';
  else if (rem <= 0.0001) status = 'failed';
  else if (need > s.max + 1e-9) status = 'impossible';
  else if (avg !== null && need <= avg + 1e-9) status = 'ok';
  else status = 'risk';
  return { w: w, total: total, gW: gW, acc: acc, rem: rem, avg: avg, maxP: maxP, minP: minP, need: need, need1: need1,
    status: status, n: n, graded: graded, pending: pending, eq: eq, sum: sum };
}
function needFor(c, target) {
  if (c.rem <= 0.0001) return null;
  return (target - c.acc) * 100 / c.rem;
}
var STATUS = {
  empty: { t: 'Sin notas aún', c: 'var(--label3)' },
  secured: { t: 'Aprobada', c: 'var(--green)' },
  ok: { t: 'Vas bien', c: 'var(--green)' },
  risk: { t: 'Necesitas subir', c: 'var(--orange)' },
  impossible: { t: 'No alcanza', c: 'var(--red)' },
  failed: { t: 'Reprobada', c: 'var(--red)' }
};
function gradeSentence(sub, c) {
  var s = sc();
  if (c.status === 'empty') return 'Registra tu primera calificación y aquí verás cuánto necesitas para aprobar.';
  if (c.eq) {
    if (c.pending > 0) {
      if (c.status === 'secured') return 'Ya aseguraste la materia: aunque saques ' + fmtG(s.min) + ' en lo que falta, apruebas.';
      if (c.status === 'impossible') return 'Aunque saques ' + fmtG(s.max) + ' en las ' + c.pending + ' notas que faltan, llegarías a <b>' + fmtAcc(c.maxP) + '</b>.';
      return 'Para aprobar con ' + fmtG(s.pass) + ' necesitas un promedio de <b>' + needLabel(c.need) + '</b> en ' +
        (c.pending === 1 ? 'la nota que falta.' : 'las ' + c.pending + ' notas que faltan.');
    }
    if (c.avg >= s.pass) return 'Tu promedio es <b>' + fmtAcc(c.avg) + '</b>. Vas aprobando. Si vienen más notas, agrégalas sin calificar para calcular lo que necesitas.';
    if (c.need1 !== null && c.need1 <= s.max) return 'Tu promedio es <b>' + fmtAcc(c.avg) + '</b>. Si viene una nota más, necesitas <b>' + needLabel(c.need1) + '</b> en ella para llegar a ' + fmtG(s.pass) + '.';
    return 'Tu promedio es <b>' + fmtAcc(c.avg) + '</b>. Con una sola nota más no alcanzas ' + fmtG(s.pass) + '; necesitarás varias notas altas.';
  }
  var remTxt = fmtPct(c.rem);
  if (c.status === 'secured') return c.rem > 0.0001 ? 'Ya aseguraste la materia: aunque saques ' + fmtG(s.min) + ' en el ' + remTxt + ' que falta, apruebas.' : 'Aprobaste con <b>' + fmtAcc(c.acc) + '</b>.';
  if (c.status === 'failed') return 'Terminaste con <b>' + fmtAcc(c.acc) + '</b>; se necesitaba ' + fmtG(s.pass) + ' para aprobar.';
  if (c.status === 'impossible') return 'Aunque saques ' + fmtG(s.max) + ' en el ' + remTxt + ' restante, llegarías a <b>' + fmtAcc(c.maxP) + '</b>.';
  var t = 'Para aprobar necesitas <b>' + needLabel(c.need) + '</b> en el ' + remTxt + ' restante.';
  if (c.status === 'risk' && c.avg !== null) t += ' Hasta ahora tu promedio es ' + fmtAcc(c.avg) + '.';
  return t;
}
function targetsFor(s) {
  var out = [], step = (s.max - s.pass) / 4;
  for (var i = 1; i <= 4; i++) {
    var v = s.pass + step * i;
    v = s.dec ? Math.round(v * 10) / 10 : Math.round(v);
    if (out.indexOf(v) < 0) out.push(v);
  }
  return out;
}
function overallAvg() {
  var vals = [];
  S.subjects.forEach(function (sub) { var c = calcSubject(sub); if (c.avg !== null) vals.push(c.avg); });
  if (!vals.length) return null;
  var t = 0; vals.forEach(function (v) { t += v; });
  return { avg: t / vals.length, n: vals.length };
}
function gradeForAct(a) {
  var sub = getSub(a.subjectId);
  if (!sub) return null;
  return find(sub.grades, function (g) { return g.actId === a.id; });
}

/* ---------- recordatorios ---------- */
var REM_OPTS = [
  { m: 0, t: 'A la hora' }, { m: 60, t: '1 hora antes' }, { m: 180, t: '3 horas antes' },
  { m: 1440, t: '1 día antes' }, { m: 2880, t: '2 días antes' }, { m: 10080, t: '1 semana antes' }
];
var REM_SHORT = { 0: 'A la hora', 60: '1 h', 180: '3 h', 1440: '1 día', 2880: '2 días', 10080: '1 sem.' };
function remLead(m) {
  return { 0: 'Ahora', 60: 'En 1 hora', 180: 'En 3 horas', 1440: 'Mañana', 2880: 'En 2 días', 10080: 'En una semana' }[m] || 'Pronto';
}
function computeReminders() {
  var out = [], now = Date.now();
  S.acts.forEach(function (a) {
    if (!isOpen(a) || !a.rem || !a.rem.length) return;
    var base = actBase(a).getTime(), sub = getSub(a.subjectId);
    a.rem.forEach(function (m) {
      var at = base - m * 60000;
      if (at <= now) return;
      var title = remLead(m) + ': ' + a.title;
      var body = (sub ? sub.name + ' · ' : '') + shortDate(pymd(a.date)) + (a.time ? ', ' + fmtTime(a.time) : '');
      if (a.kind === 'examen' && sub) {
        var c = calcSubject(sub);
        if (c.need !== null && c.status !== 'secured' && c.status !== 'empty') body += ' · Necesitas ' + needLabel(c.need) + ' para aprobar';
      }
      out.push({ id: hashStr(a.id + ':' + m), at: at, title: title, body: body });
    });
  });
  var lead = +S.settings.classRem || 0;
  if (lead > 0) {
    for (var k = 0; k < 14; k++) {
      var date = addDays(today0(), k);
      classesOn(dow(date)).forEach(function (c) {
        var at = atTime(date, c.start).getTime() - lead * 60000;
        if (at <= now) return;
        var sub = getSub(c.subjectId);
        if (!sub) return;
        out.push({ id: hashStr('cls:' + c.id + ':' + ymd(date)), at: at,
          title: sub.name + ' en ' + lead + ' min',
          body: fmtTime(c.start) + ((c.room || sub.room) ? ' · ' + (c.room || sub.room) : '') + (sub.teacher ? ' · ' + sub.teacher : '') });
      });
    }
  }
  var f = S.focus;
  if (f && f.running && f.endAt > now) {
    out.push({ id: hashStr('focus'), at: f.endAt, title: 'Sesión de estudio terminada', body: 'Terminaste ' + Math.round(f.dur / 60000) + ' min de ' + f.label + '. Tómate un descanso.' });
  }
  out.sort(function (a, b) { return a.at - b.at; });
  return out.slice(0, 300);
}
var lastRemJson = null;
function syncReminders(force) {
  if (!Native) return;
  var json = JSON.stringify(computeReminders());
  if (!force && json === lastRemJson) return;
  lastRemJson = json;
  nat('setReminders', json);
}

/* ---------- materias: portada sugerida por nombre ---------- */
function guessGlyph(name) {
  var n = String(name || '').toLowerCase().normalize ? String(name || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '') : String(name || '').toLowerCase();
  var rules = [
    [/calcul|algebr|aritm|trigon|geometr|estad/, 'pi'], [/matem/, 'sigma'], [/fisic/, 'atom'], [/quim/, 'flask'],
    [/biolog|natural|ambient|ecolog/, 'leaf'], [/ingl|idiom|frances|portug|aleman|english/, 'lang'],
    [/lengua|castell|espanol|lectura|literat|comunic|redacc/, 'book'], [/histor|constitu|democr|civic|politic/, 'landmark'],
    [/social|geograf|econom/, 'globe'], [/arte|artist|dibujo|plast/, 'palette'], [/music/, 'music'],
    [/fisica\b|deport|educacion fisica|edu\. fis|danza/, 'ball'], [/inform|sistem|program|tecnolog|comput|robot/, 'code'],
    [/etica|filosof|relig|valores|psicol/, 'scales'], [/emprend|contab|financ|admin/, 'calc'], [/salud|anatom|medic/, 'dna']
  ];
  if (/educacion fisica|edu\.? ?fis/.test(n)) return 'ball';
  for (var i = 0; i < rules.length; i++) if (rules[i][0].test(n)) return rules[i][1];
  return 'book';
}

/* ---------- datos de ejemplo ---------- */
function seedState(keep) {
  var s = defaultState();
  s.onboarded = true;
  if (keep) { s.profile = Object.assign({}, keep.profile); s.settings = Object.assign({}, keep.settings); }
  var t = today0();
  function d(n) { return ymd(addDays(t, n)); }
  function sub(id, name, teacher, room, color, glyph, mode, grades) {
    s.subjects.push({ id: id, name: name, teacher: teacher, room: room, color: color, glyph: glyph, mode: mode, created: Date.now(),
      grades: grades.map(function (g, i) { return { id: id + 'g' + i, name: g[0], weight: g[1] === null ? '' : g[1], grade: g[2] === null ? '' : g[2] }; }) });
  }
  sub('mat', 'Matemáticas', 'Prof. Laura Gómez', 'Aula 204', '#1F7AE0', 'sigma', 'pct',
    [['Quiz 1', 10, 4.2], ['Taller 1', 15, 3.8], ['Parcial 1', 25, 3.1], ['Quiz 2', 10, null], ['Parcial 2', 25, null], ['Taller 2', 15, null]]);
  sub('fis', 'Física', 'Prof. Andrés Ramírez', 'Laboratorio 2', '#4F55D9', 'atom', 'pct',
    [['Laboratorio 1', 20, 4.5], ['Quiz 1', 10, 2.8], ['Parcial 1', 30, 3.2], ['Examen final', 40, null]]);
  sub('len', 'Lengua Castellana', 'Prof. Marta Rosero', 'Aula 108', '#E5383B', 'book', 'equal',
    [['Ensayo argumentativo', null, 4.6], ['Lectura crítica', null, 3.9], ['Exposición', null, 4.2], ['Comprensión lectora', null, null]]);
  sub('ing', 'Inglés', 'Prof. James Ortiz', 'Aula 301', '#0F9D8A', 'lang', 'equal',
    [['Listening 1', null, 4.0], ['Speaking', null, 4.4], ['Writing', null, 3.7]]);
  sub('qui', 'Química', 'Prof. Diana López', 'Laboratorio 1', '#F2600C', 'flask', 'pct',
    [['Laboratorio', 25, 2.6], ['Quiz', 15, 2.4], ['Parcial', 30, 2.2], ['Final', 30, null]]);
  sub('soc', 'Ciencias Sociales', 'Prof. Carlos Benavides', 'Aula 110', '#C98500', 'globe', 'equal',
    [['Mapa conceptual', null, 4.1], ['Debate', null, 3.6], ['Taller', null, 3.9], ['Quiz', null, null]]);
  sub('bio', 'Biología', 'Prof. Sandra Erazo', 'Laboratorio 1', '#2F9E44', 'leaf', 'pct',
    [['Informe', 30, 4.0], ['Quiz 1', 20, 3.5], ['Proyecto', 50, null]]);

  var slots = [['07:00', '07:55'], ['07:55', '08:50'], ['08:50', '09:45'], ['10:15', '11:10'], ['11:10', '12:05'], ['12:05', '13:00']];
  var week = {
    1: ['mat', 'mat', 'fis', 'len', 'ing', 'soc'],
    2: ['qui', 'bio', 'mat', 'len', 'len', 'ing'],
    3: ['fis', 'fis', 'soc', 'mat', 'qui', 'bio'],
    4: ['ing', 'len', 'mat', 'qui', 'soc', 'fis'],
    5: ['bio', 'mat', 'len', 'fis', 'ing', 'soc']
  };
  Object.keys(week).forEach(function (day) {
    week[day].forEach(function (sid, i) {
      s.classes.push({ id: 'c' + day + i, subjectId: sid, day: +day, start: slots[i][0], end: slots[i][1], room: '' });
    });
  });

  function act(id, kind, title, sid, n, time, prio, status, desc, rem) {
    var a = { id: id, kind: kind, title: title, subjectId: sid, date: d(n), time: time || '', priority: prio || 0, status: status || 'pendiente',
      desc: desc || '', files: [], rem: rem || [], created: addDays(t, Math.min(n, 0) - 4).getTime(), focusMs: 0 };
    if (status === 'completada') a.completedAt = addDays(t, n).getTime();
    s.acts.push(a);
  }
  act('a1', 'tarea', 'Taller de derivadas', 'mat', 1, '', 3, 'proceso', 'Ejercicios 1 al 20 de la guía 4. Mostrar procedimiento completo.', [1440]);
  act('a2', 'tarea', 'Informe de laboratorio: péndulo simple', 'fis', 3, '07:00', 2, 'pendiente', 'Tablas de datos, gráfica de periodo contra longitud y conclusiones. Máximo 4 páginas.', [1440]);
  act('a3', 'examen', 'Parcial 2', 'mat', 4, '07:00', 3, 'pendiente', 'Temas: límites, derivadas por definición y reglas de derivación.', [1440, 60]);
  act('a4', 'examen', 'Quiz de estequiometría', 'qui', 2, '07:00', 2, 'pendiente', 'Balanceo de ecuaciones, moles y reactivo límite.', [1440]);
  act('a5', 'tarea', 'Ensayo sobre Cien años de soledad', 'len', 6, '', 1, 'pendiente', 'Mínimo 800 palabras. Tema libre sobre la soledad en la familia Buendía.', [2880]);
  act('a6', 'tarea', 'Listening practice, unit 5', 'ing', 0, '18:00', 2, 'pendiente', '', [60]);
  act('a7', 'tarea', 'Mapa conceptual: independencia de Colombia', 'soc', -1, '', 2, 'pendiente', '', []);
  act('a8', 'examen', 'Examen final de Física', 'fis', 15, '07:00', 3, 'pendiente', 'Dinámica, trabajo y energía, momentum.', [10080, 1440]);
  act('a9', 'evento', 'Simulacro Saber 11', '', 9, '07:00', 0, 'pendiente', 'Llevar lápiz número 2, borrador y documento de identidad.', [1440]);
  act('a10', 'evento', 'Feria de la ciencia', '', 12, '08:00', 0, 'pendiente', '', []);
  act('a11', 'tarea', 'Taller de vectores', 'fis', -3, '', 2, 'completada', '', []);
  act('a12', 'tarea', 'Guía de lectura capítulo 3', 'len', -2, '', 1, 'completada', '', []);
  act('a13', 'examen', 'Proyecto de biología', 'bio', 8, '10:15', 2, 'pendiente', 'Maqueta de la célula animal con exposición de 5 minutos.', [1440]);

  s.notes.push({ id: 'n1', subjectId: 'fis', title: 'Leyes de Newton', body: '1. Inercia: un cuerpo sigue en reposo o en movimiento uniforme si la fuerza neta es cero.\n2. F = m · a\n3. Acción y reacción: las fuerzas aparecen en pares iguales y opuestos.', updated: addDays(t, -2).getTime(), files: [] });
  s.notes.push({ id: 'n2', subjectId: 'fis', title: 'Plano inclinado', body: 'N = m·g·cos θ\nFuerza paralela = m·g·sen θ\nCon fricción: f = μ·N', updated: addDays(t, -5).getTime(), files: [] });
  s.notes.push({ id: 'n3', subjectId: 'mat', title: 'Reglas de derivación', body: '(xⁿ)\' = n·xⁿ⁻¹\n(f·g)\' = f\'g + fg\'\n(f/g)\' = (f\'g − fg\')/g²\nRegla de la cadena: (f(g(x)))\' = f\'(g(x))·g\'(x)', updated: addDays(t, -1).getTime(), files: [] });
  return s;
}
