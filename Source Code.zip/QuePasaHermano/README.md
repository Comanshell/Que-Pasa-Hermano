# Que Pasa Hermano

App escolar para Android: materias, calificaciones (por porcentajes o todas con el mismo valor), tareas, calendario, horario, apuntes y recordatorios.

- Android 5.0 o superior (minSdk 21, targetSdk 34)
- Funciona sin internet; los datos se guardan solo en el celular
- Paquete: `co.quepasahermano.app` · versión 1.0

## Cómo está hecha

La interfaz es HTML, CSS y JavaScript que corre dentro de un WebView. La parte en Java se encarga de lo que necesita el sistema: guardar los datos, programar alarmas, mostrar notificaciones, abrir la cámara y los archivos.

```
AndroidManifest.xml        permisos, actividad, receptores y proveedor de archivos
build.sh                   compila y firma el APK sin Gradle
keystore/qph.jks           llave de firma (contraseña en build.sh)
res/                       icono, icono de notificación, tema y nombre de la app
assets/
  index.html               punto de entrada
  styles.css               todo el diseño (tema oscuro y claro)
  fonts/inter.woff2        tipografía Inter (licencia SIL OFL)
  js/core.js               datos, fechas, cálculo de notas, recordatorios, datos de ejemplo
  js/ui.js                 íconos, portadas, navegación, hojas, mini panel y reproductor
  js/views.js              pantallas: Inicio, Materias, Tareas, Calendario, Perfil
  js/forms.js              formularios: materia, calificación, actividad, clase, apunte
  js/main.js               acciones, arranque y funciones que llama Android
src/co/quepasahermano/app/
  MainActivity.java        WebView, pantalla completa, puente JS ↔ Android, archivos
  Reminders.java           alarmas exactas y notificaciones
  ReminderReceiver.java    muestra la notificación cuando suena la alarma
  BootReceiver.java        vuelve a programar alarmas al reiniciar el celular
  FilesProvider.java       comparte los adjuntos con otras apps de forma segura
```

## Probar la interfaz en el computador

Abre `assets/index.html` en Chrome. Sin Android los datos se guardan en el navegador.
Parámetros útiles: `index.html?demo=1` carga datos de ejemplo, `&theme=light` usa el tema claro.

## Compilar el APK

En Ubuntu o Debian:

```
sudo apt install openjdk-17-jdk android-sdk-platform-23 android-sdk-build-tools apksigner zipalign dalvik-exchange
./build.sh
```

El APK queda en `build/QuePasaHermano.apk`.

También se puede abrir en Android Studio creando un proyecto vacío con el mismo nombre de paquete y copiando `assets`, `res`, `src` y el manifiesto.

## Importante sobre la llave de firma

Guarda `keystore/qph.jks`. Android solo deja instalar una versión nueva encima de la anterior si está firmada con la misma llave. Si se pierde, para actualizar habrá que desinstalar la app (haz antes una copia de seguridad desde Perfil).
