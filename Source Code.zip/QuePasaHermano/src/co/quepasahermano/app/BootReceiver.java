package co.quepasahermano.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Las alarmas se borran al reiniciar el celular o actualizar la app: aquí se vuelven a programar. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i == null || i.getAction() == null) return;
        String a = i.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)
                || "android.intent.action.QUICKBOOT_POWERON".equals(a) || "com.htc.intent.action.QUICKBOOT_POWERON".equals(a)) {
            Reminders.reschedule(c);
        }
    }
}
