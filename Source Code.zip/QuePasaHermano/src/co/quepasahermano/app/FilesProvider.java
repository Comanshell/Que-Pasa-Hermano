package co.quepasahermano.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

/** Comparte los archivos adjuntos con otras apps (visor de PDF, galería, cámara) sin dar acceso a nada más. */
public class FilesProvider extends ContentProvider {

    static String authority(Context c) { return c.getPackageName() + ".files"; }

    static Uri uriFor(Context c, String kind, String id, String name) {
        return new Uri.Builder().scheme("content").authority(authority(c))
                .appendPath(kind).appendPath(id).appendPath(name == null || name.length() == 0 ? "archivo" : name).build();
    }

    static String guessMime(String name) {
        if (name != null) {
            int dot = name.lastIndexOf('.');
            if (dot >= 0 && dot < name.length() - 1) {
                String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase());
                if (m != null) return m;
            }
        }
        return "application/octet-stream";
    }

    private File resolve(Uri uri) {
        List<String> seg = uri.getPathSegments();
        if (seg == null || seg.size() < 2) return null;
        String kind = seg.get(0), id = seg.get(1);
        if (id == null || !id.matches("[A-Za-z0-9._-]+") || id.contains("..")) return null;
        Context c = getContext();
        if (c == null) return null;
        File base;
        if ("a".equals(kind)) base = new File(c.getFilesDir(), "adjuntos");
        else if ("x".equals(kind)) base = new File(c.getCacheDir(), "export");
        else return null;
        return new File(base, id);
    }

    private String nameOf(Uri uri) {
        List<String> seg = uri.getPathSegments();
        if (seg != null && seg.size() >= 3) return seg.get(2);
        if (seg != null && seg.size() >= 2) return seg.get(1);
        return "archivo";
    }

    @Override public boolean onCreate() { return true; }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        File f = resolve(uri);
        if (f == null) return null;
        String[] cols = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
        MatrixCursor c = new MatrixCursor(cols, 1);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = nameOf(uri);
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = f.length();
        }
        c.addRow(row);
        return c;
    }

    @Override public String getType(Uri uri) { return guessMime(nameOf(uri)); }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = resolve(uri);
        if (f == null) throw new FileNotFoundException("No encontrado");
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.parseMode(mode == null ? "r" : mode));
    }

    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] args) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] args) { return 0; }
}
