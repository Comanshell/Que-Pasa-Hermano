package co.quepasahermano.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Recibe la alarma programada y muestra la notificación. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i == null || !Reminders.ACTION.equals(i.getAction())) return;
        Reminders.notify(c, i.getIntExtra("id", 1), i.getStringExtra("title"), i.getStringExtra("body"));
    }
}
