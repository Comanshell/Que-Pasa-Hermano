package co.quepasahermano.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/** Programa las alarmas de recordatorio y muestra las notificaciones. */
final class Reminders {
    static final String CHANNEL = "recordatorios";
    static final String ACTION = "co.quepasahermano.app.RECORDATORIO";

    private Reminders() { }

    static SharedPreferences store(Context c) { return c.getSharedPreferences("alarmas", Context.MODE_PRIVATE); }

    static int flags(int base) { return Build.VERSION.SDK_INT >= 23 ? base | PendingIntent.FLAG_IMMUTABLE : base; }

    static Intent intent(Context c, int id) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.setAction(ACTION);
        i.setData(Uri.parse("qph://alarma/" + id));
        return i;
    }

    static synchronized void scheduleAll(Context c, String json) {
        SharedPreferences sp = store(c);
        String old = sp.getString("ids", "");
        for (String s : old.split(",")) {
            if (s.length() == 0) continue;
            try { cancel(c, Integer.parseInt(s)); } catch (Throwable t) { /* id inválido */ }
        }
        StringBuilder ids = new StringBuilder();
        JSONArray keep = new JSONArray();
        long now = System.currentTimeMillis();
        try {
            JSONArray arr = new JSONArray(json == null ? "[]" : json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                long at = o.getLong("at");
                if (at <= now) continue;
                int id = o.getInt("id");
                set(c, id, at, o.optString("title", "Recordatorio"), o.optString("body", ""));
                ids.append(id).append(',');
                keep.put(o);
            }
        } catch (Throwable t) { /* lista inválida */ }
        sp.edit().putString("ids", ids.toString()).putString("list", keep.toString()).apply();
    }

    static void reschedule(Context c) { scheduleAll(c, store(c).getString("list", "[]")); }

    static void set(Context c, int id, long at, String title, String body) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = intent(c, id);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        PendingIntent pi = PendingIntent.getBroadcast(c, id, i, flags(PendingIntent.FLAG_UPDATE_CURRENT));
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            // Sin permiso de alarmas exactas: se usa una alarma aproximada
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    static void cancel(Context c, int id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, id, intent(c, id), flags(PendingIntent.FLAG_NO_CREATE));
        if (pi != null) {
            if (am != null) am.cancel(pi);
            pi.cancel();
        }
    }

    static boolean canNotify(Context c) {
        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return false;
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
                Object r = NotificationManager.class.getMethod("areNotificationsEnabled").invoke(nm);
                if (r instanceof Boolean) return (Boolean) r;
            } catch (Throwable t) { /* se asume que sí */ }
        }
        return true;
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            Class<?> ch = Class.forName("android.app.NotificationChannel");
            Object channel = ch.getConstructor(String.class, CharSequence.class, int.class).newInstance(CHANNEL, "Recordatorios", 4);
            ch.getMethod("setDescription", String.class).invoke(channel, "Exámenes, tareas, clases y sesiones de estudio");
            ch.getMethod("enableVibration", boolean.class).invoke(channel, true);
            ch.getMethod("enableLights", boolean.class).invoke(channel, true);
            ch.getMethod("setLightColor", int.class).invoke(channel, 0xFFFA2D48);
            NotificationManager.class.getMethod("createNotificationChannel", ch).invoke(nm, channel);
        } catch (Throwable t) { /* sin canal */ }
    }

    static Notification.Builder builder(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                return Notification.Builder.class.getConstructor(Context.class, String.class).newInstance(c, CHANNEL);
            } catch (Throwable t) { /* constructor antiguo */ }
        }
        return new Notification.Builder(c);
    }

    static void notify(Context c, int id, String title, String body) {
        ensureChannel(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, flags(PendingIntent.FLAG_UPDATE_CURRENT));
        if (title == null || title.length() == 0) title = "Recordatorio";
        if (body == null) body = "";
        Notification.Builder b = builder(c)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .setColor(0xFFFA2D48)
                .setCategory("reminder")
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL);
        try { nm.notify(id, b.build()); } catch (Throwable t) { /* sin permiso */ }
    }
}
