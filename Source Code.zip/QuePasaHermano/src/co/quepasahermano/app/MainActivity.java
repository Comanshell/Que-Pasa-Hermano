package co.quepasahermano.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    static final int REQ_PICK = 11, REQ_PHOTO = 12, REQ_IMPORT = 13, REQ_IMAGE = 14, REQ_EXPORT = 15, REQ_NOTIF = 21;
    static final int MIN_CHROME = 61;
    static final long MAX_FILE = 60L * 1024 * 1024;

    WebView web;
    FrameLayout root;
    float density = 1f;
    int insetTop = 0, insetBottom = 0;
    boolean pageReady = false, dark = true;
    String pendingTag, pendingPhotoId, pendingExport;
    SharedPreferences prefs;
    final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("datos", MODE_PRIVATE);
        density = getResources().getDisplayMetrics().density;
        dark = prefs.getBoolean("dark", true);
        setupWindow();
        root = new FrameLayout(this);
        root.setBackgroundColor(bgColor());
        setContentView(root);

        int chrome = chromeVersion();
        if (chrome == -1) { showMessage("Falta un componente del sistema",
                "Para abrir Que Pasa Hermano necesitas tener instalado y activado \"Android System WebView\".", true); return; }
        if (chrome > 0 && chrome < MIN_CHROME) { showMessage("Actualiza un componente del sistema",
                "Tu celular tiene una versión antigua de \"Android System WebView\". Actualízala desde Play Store para usar la app.", true); return; }
        try { web = new WebView(this); } catch (Throwable t) { showMessage("No se pudo abrir la app", "Activa o actualiza \"Android System WebView\" desde Play Store.", true); return; }

        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets in) { handleInsets(in); return in.consumeSystemWindowInsets(); }
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setTextZoom(textZoom());
        web.setBackgroundColor(bgColor());
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setHapticFeedbackEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                if (url != null && url.startsWith("file:///android_asset/")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable t) { /* sin app */ }
                return true;
            }
            @Override
            public void onPageFinished(WebView v, String url) { pageReady = true; pushInsets(); }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    /* ---------- ventana a pantalla completa ---------- */
    void setupWindow() {
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.getClass().getField("layoutInDisplayCutoutMode").setInt(lp, 1);
                w.setAttributes(lp);
            } catch (Throwable t) { /* sin muesca */ }
        }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                Window.class.getMethod("setNavigationBarContrastEnforced", boolean.class).invoke(w, false);
                Window.class.getMethod("setStatusBarContrastEnforced", boolean.class).invoke(w, false);
            } catch (Throwable t) { /* opcional */ }
        }
        applySystemBars();
    }

    void applySystemBars() {
        Window w = getWindow();
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (!dark && Build.VERSION.SDK_INT >= 23) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (!dark && Build.VERSION.SDK_INT >= 26) flags |= 0x10; // SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        w.getDecorView().setSystemUiVisibility(flags);
        w.setStatusBarColor(!dark && Build.VERSION.SDK_INT < 23 ? 0x55000000 : Color.TRANSPARENT);
        w.setNavigationBarColor(!dark && Build.VERSION.SDK_INT < 26 ? Color.BLACK : Color.TRANSPARENT);
        w.getDecorView().setBackgroundColor(bgColor());
        if (root != null) root.setBackgroundColor(bgColor());
        if (web != null) web.setBackgroundColor(bgColor());
    }

    int bgColor() { return dark ? Color.BLACK : Color.WHITE; }

    int textZoom() {
        float f = getResources().getConfiguration().fontScale;
        if (f < 0.85f) f = 0.85f;
        if (f > 1.15f) f = 1.15f;
        return Math.round(f * 100);
    }

    void handleInsets(WindowInsets in) {
        int top = in.getSystemWindowInsetTop(), bottom = in.getSystemWindowInsetBottom();
        int ime = 0, nav = bottom;
        boolean done = false;
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Class<?> type = Class.forName("android.view.WindowInsets$Type");
                int imeT = (Integer) type.getMethod("ime").invoke(null);
                int barsT = (Integer) type.getMethod("systemBars").invoke(null);
                Object a = WindowInsets.class.getMethod("getInsets", int.class).invoke(in, imeT);
                Object b = WindowInsets.class.getMethod("getInsets", int.class).invoke(in, barsT);
                ime = a.getClass().getField("bottom").getInt(a);
                nav = b.getClass().getField("bottom").getInt(b);
                top = b.getClass().getField("top").getInt(b);
                done = true;
            } catch (Throwable t) { done = false; }
        }
        if (!done) {
            if (bottom > 120 * density) { ime = bottom; nav = 0; } else { ime = 0; nav = bottom; }
        }
        root.setPadding(0, 0, 0, ime);
        insetTop = top;
        insetBottom = ime > 0 ? 0 : nav;
        pushInsets();
    }

    /* si el sistema aún no reportó la barra de estado, se usa su alto estándar */
    int topInset() {
        if (insetTop > 0) return insetTop;
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : Math.round(24 * density);
    }

    void pushInsets() {
        if (!pageReady || web == null) return;
        js("window.__insets&&window.__insets(" + Math.round(topInset() / density) + "," + Math.round(insetBottom / density) + ")");
    }

    void js(final String code) {
        if (web == null) return;
        ui.post(new Runnable() { public void run() { if (web != null) web.evaluateJavascript(code, null); } });
    }

    void toastJs(String msg) { js("window.__toast&&window.__toast(" + JSONObject.quote(msg) + ")"); }

    int chromeVersion() {
        try {
            String ua = WebSettings.getDefaultUserAgent(this);
            Matcher m = Pattern.compile("Chrome/(\\d+)").matcher(ua == null ? "" : ua);
            return m.find() ? Integer.parseInt(m.group(1)) : 0;
        } catch (Throwable t) {
            return -1;
        }
    }

    void showMessage(String title, String text, boolean store) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int p = Math.round(32 * density);
        box.setPadding(p, p, p, p);
        TextView t1 = new TextView(this);
        t1.setText(title); t1.setTextSize(24); t1.setTextColor(Color.WHITE); t1.setGravity(Gravity.CENTER);
        TextView t2 = new TextView(this);
        t2.setText(text); t2.setTextSize(16); t2.setTextColor(0xFFAAAAAA); t2.setGravity(Gravity.CENTER);
        t2.setPadding(0, Math.round(12 * density), 0, Math.round(24 * density));
        box.addView(t1); box.addView(t2);
        if (store) {
            TextView btn = new TextView(this);
            btn.setText("Abrir Play Store"); btn.setTextSize(17); btn.setTextColor(0xFFFA2D48); btn.setGravity(Gravity.CENTER);
            btn.setPadding(p / 2, p / 3, p / 2, p / 3);
            btn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.webview"))); }
                    catch (Throwable t) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.webview"))); } catch (Throwable t2) { /* nada */ } }
                }
            });
            box.addView(btn);
        }
        root.setBackgroundColor(Color.BLACK);
        root.addView(box, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /* ---------- ciclo de vida ---------- */
    @Override
    public void onBackPressed() {
        if (web == null || !pageReady) { super.onBackPressed(); return; }
        web.evaluateJavascript("(window.__back&&window.__back())?'1':'0'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) { if (v == null || !v.contains("1")) moveTaskToBack(true); }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) { web.onResume(); if (pageReady) js("window.__resume&&window.__resume()"); }
    }

    @Override
    protected void onPause() {
        if (web != null && pageReady) web.evaluateJavascript("window.__pause&&window.__pause()", null);
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (web != null) {
            web.getSettings().setTextZoom(textZoom());
            if (pageReady) js("window.__sysTheme&&window.__sysTheme()");
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) { root.removeView(web); web.destroy(); web = null; }
        super.onDestroy();
    }

    /* ---------- permisos de notificación ---------- */
    void requestNotif() {
        if (Reminders.canNotify(this)) { js("window.__notifPerm&&window.__notifPerm(true)"); return; }
        if (Build.VERSION.SDK_INT >= 33) {
            boolean asked = prefs.getBoolean("notif_asked", false);
            if (!asked || shouldShowRequestPermissionRationale("android.permission.POST_NOTIFICATIONS")) {
                prefs.edit().putBoolean("notif_asked", true).apply();
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
                return;
            }
        }
        openNotifSettings();
    }

    void openNotifSettings() {
        try {
            Intent i;
            if (Build.VERSION.SDK_INT >= 26) {
                i = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
                i.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
            } else {
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            }
            startActivity(i);
            toastJs("Activa las notificaciones de Que Pasa Hermano");
        } catch (Throwable t) {
            toastJs("Activa las notificaciones en los ajustes del celular");
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_NOTIF) js("window.__notifPerm&&window.__notifPerm(" + Reminders.canNotify(this) + ")");
    }

    /* ---------- archivos adjuntos ---------- */
    File attachDir() { File d = new File(getFilesDir(), "adjuntos"); if (!d.exists()) d.mkdirs(); return d; }

    File fileFor(String id) {
        if (id == null || !id.matches("[A-Za-z0-9-]+")) return null;
        return new File(attachDir(), id);
    }

    void startPick(String tag, String mode) {
        pendingTag = tag;
        try {
            if ("photo".equals(mode)) {
                String id = UUID.randomUUID().toString();
                File f = new File(attachDir(), id);
                f.createNewFile();
                pendingPhotoId = id;
                Uri uri = FilesProvider.uriFor(this, "a", id, "foto.jpg");
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                i.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                i.setClipData(ClipData.newRawUri("foto", uri));
                startActivityForResult(i, REQ_PHOTO);
                return;
            }
            int req = "import".equals(mode) ? REQ_IMPORT : "image".equals(mode) ? REQ_IMAGE : REQ_PICK;
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image".equals(mode) ? "image/*" : "*/*");
            if (req == REQ_PICK) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            try { startActivityForResult(i, req); }
            catch (Throwable t) {
                Intent g = new Intent(Intent.ACTION_GET_CONTENT);
                g.addCategory(Intent.CATEGORY_OPENABLE);
                g.setType("image".equals(mode) ? "image/*" : "*/*");
                if (req == REQ_PICK) g.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(g, "Elegir archivo"), req);
            }
        } catch (Throwable t) {
            if (pendingPhotoId != null) { File f = fileFor(pendingPhotoId); if (f != null) f.delete(); pendingPhotoId = null; }
            toastJs("photo".equals(mode) ? "No se encontró una app de cámara" : "No se pudo abrir el selector de archivos");
        }
    }

    @Override
    protected void onActivityResult(int req, final int res, final Intent data) {
        super.onActivityResult(req, res, data);
        final String tag = pendingTag;
        if (req == REQ_PHOTO) {
            final String id = pendingPhotoId;
            pendingPhotoId = null;
            final File f = fileFor(id);
            if (res == RESULT_OK && f != null && f.length() > 0) {
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            shrinkPhoto(f, 2560);
                            JSONObject o = new JSONObject();
                            o.put("id", id);
                            o.put("name", "Foto " + new java.text.SimpleDateFormat("d MMM HH.mm", new java.util.Locale("es")).format(new java.util.Date()) + ".jpg");
                            o.put("size", f.length());
                            o.put("mime", "image/jpeg");
                            JSONArray arr = new JSONArray();
                            arr.put(o);
                            postPicked(tag, arr);
                        } catch (Throwable t) { toastJs("No se pudo guardar la foto"); }
                    }
                }).start();
            } else if (f != null) f.delete();
            return;
        }
        if (req == REQ_EXPORT) {
            final String json = pendingExport;
            pendingExport = null;
            if (res != RESULT_OK || data == null || data.getData() == null || json == null) return;
            final Uri uri = data.getData();
            new Thread(new Runnable() {
                public void run() {
                    try {
                        OutputStream os;
                        try { os = getContentResolver().openOutputStream(uri, "wt"); }
                        catch (Throwable e) { os = getContentResolver().openOutputStream(uri, "w"); }
                        os.write(json.getBytes("UTF-8"));
                        os.close();
                        toastJs("Copia de seguridad guardada");
                    } catch (Throwable t) { toastJs("No se pudo guardar la copia"); }
                }
            }).start();
            return;
        }
        if (res != RESULT_OK || data == null) return;
        if (req == REQ_IMPORT) {
            final Uri uri = data.getData();
            if (uri == null) return;
            new Thread(new Runnable() {
                public void run() {
                    try {
                        String text = readText(uri, 20L * 1024 * 1024);
                        js("window.__imported&&window.__imported(" + JSONObject.quote(text) + ")");
                    } catch (Throwable t) { toastJs("No se pudo leer el archivo"); }
                }
            }).start();
            return;
        }
        if (req == REQ_PICK || req == REQ_IMAGE) {
            final ArrayList<Uri> uris = new ArrayList<Uri>();
            ClipData clip = data.getClipData();
            if (clip != null) for (int i = 0; i < clip.getItemCount(); i++) { Uri u = clip.getItemAt(i).getUri(); if (u != null) uris.add(u); }
            if (uris.isEmpty() && data.getData() != null) uris.add(data.getData());
            if (uris.isEmpty()) return;
            final boolean image = req == REQ_IMAGE;
            new Thread(new Runnable() {
                public void run() {
                    JSONArray arr = new JSONArray();
                    int failed = 0;
                    for (Uri u : uris) {
                        try {
                            JSONObject o = copyIn(u);
                            if (image) { File f = fileFor(o.getString("id")); shrinkPhoto(f, 1024); o.put("size", f.length()); o.put("mime", "image/jpeg"); }
                            arr.put(o);
                        } catch (Throwable t) { failed++; }
                    }
                    if (failed > 0) toastJs(failed == 1 ? "Un archivo no se pudo agregar (máximo 60 MB)" : failed + " archivos no se pudieron agregar");
                    if (arr.length() > 0) postPicked(tag, arr);
                }
            }).start();
        }
    }

    void postPicked(String tag, JSONArray arr) {
        js("window.__picked&&window.__picked(" + JSONObject.quote(tag == null ? "" : tag) + "," + JSONObject.quote(arr.toString()) + ")");
    }

    JSONObject copyIn(Uri uri) throws Exception {
        ContentResolver cr = getContentResolver();
        String name = "archivo";
        Cursor c = null;
        try {
            c = cr.query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ni >= 0 && c.getString(ni) != null) name = c.getString(ni);
            }
        } catch (Throwable t) { /* sin nombre */ } finally { if (c != null) c.close(); }
        String mime = cr.getType(uri);
        if (mime == null) mime = FilesProvider.guessMime(name);
        String id = UUID.randomUUID().toString();
        File out = new File(attachDir(), id);
        InputStream in = cr.openInputStream(uri);
        if (in == null) throw new Exception("sin datos");
        OutputStream os = new FileOutputStream(out);
        long total = 0;
        try {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
                total += n;
                if (total > MAX_FILE) throw new Exception("muy grande");
            }
        } catch (Exception e) {
            os.close(); in.close(); out.delete(); throw e;
        }
        os.close(); in.close();
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("name", name); o.put("size", total); o.put("mime", mime);
        return o;
    }

    String readText(Uri uri, long max) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        long total = 0;
        while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); total += n; if (total > max) { in.close(); throw new Exception("muy grande"); } }
        in.close();
        return bo.toString("UTF-8");
    }

    static int exifRotation(String path) {
        try {
            int o = new ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (o == ExifInterface.ORIENTATION_ROTATE_90) return 90;
            if (o == ExifInterface.ORIENTATION_ROTATE_180) return 180;
            if (o == ExifInterface.ORIENTATION_ROTATE_270) return 270;
        } catch (Throwable t) { /* sin exif */ }
        return 0;
    }

    static Bitmap decodeScaled(String path, int max) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, o);
        if (o.outWidth <= 0 || o.outHeight <= 0) return null;
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= max) s *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = s;
        Bitmap bm = BitmapFactory.decodeFile(path, o2);
        if (bm == null) return null;
        int rot = exifRotation(path);
        float scale = Math.min(1f, (float) max / Math.max(bm.getWidth(), bm.getHeight()));
        if (rot != 0 || scale < 1f) {
            Matrix m = new Matrix();
            if (scale < 1f) m.postScale(scale, scale);
            if (rot != 0) m.postRotate(rot);
            Bitmap r = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            if (r != bm) bm.recycle();
            bm = r;
        }
        return bm;
    }

    /* reduce fotos grandes para no llenar el celular */
    static void shrinkPhoto(File f, int max) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            if (o.outWidth <= 0) return;
            if (Math.max(o.outWidth, o.outHeight) <= max && exifRotation(f.getPath()) == 0 && f.length() < 1500000) return;
            Bitmap bm = decodeScaled(f.getPath(), max);
            if (bm == null) return;
            File tmp = new File(f.getPath() + ".tmp");
            FileOutputStream fo = new FileOutputStream(tmp);
            bm.compress(Bitmap.CompressFormat.JPEG, 85, fo);
            fo.close();
            bm.recycle();
            if (!tmp.renameTo(f)) tmp.delete();
        } catch (Throwable t) { /* se deja la original */ }
    }

    String thumbFor(String id) {
        File f = fileFor(id);
        if (f == null || !f.exists()) return "";
        try {
            File dir = new File(getCacheDir(), "miniaturas");
            if (!dir.exists()) dir.mkdirs();
            File cache = new File(dir, id + ".jpg");
            if (!cache.exists()) {
                Bitmap bm = decodeScaled(f.getPath(), 400);
                if (bm == null) return "";
                FileOutputStream fo = new FileOutputStream(cache);
                bm.compress(Bitmap.CompressFormat.JPEG, 80, fo);
                fo.close();
                bm.recycle();
            }
            FileInputStream in = new FileInputStream(cache);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return "data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable t) {
            return "";
        }
    }

    void deleteTree(File d) {
        File[] list = d.listFiles();
        if (list != null) for (File f : list) { if (f.isDirectory()) deleteTree(f); else f.delete(); }
    }

    /* ---------- puente con la interfaz ---------- */
    public class Bridge {
        @JavascriptInterface public String load() { return prefs.getString("state", ""); }
        @JavascriptInterface public void save(String json) { prefs.edit().putString("state", json).apply(); }
        @JavascriptInterface public void setReminders(String json) { Reminders.scheduleAll(getApplicationContext(), json); }
        @JavascriptInterface public boolean canNotify() { return Reminders.canNotify(MainActivity.this); }
        @JavascriptInterface public void askNotify() { ui.post(new Runnable() { public void run() { requestNotif(); } }); }
        @JavascriptInterface public void testNotify() {
            Reminders.notify(getApplicationContext(), 7, "¿Qué pasa, hermano?", "Así te llegarán los recordatorios de tus exámenes, tareas y clases.");
        }
        @JavascriptInterface public void haptic(final int k) {
            ui.post(new Runnable() {
                public void run() {
                    if (web == null) return;
                    int c = k == 2 ? (Build.VERSION.SDK_INT >= 30 ? 16 : HapticFeedbackConstants.VIRTUAL_KEY)
                            : k == 1 ? HapticFeedbackConstants.VIRTUAL_KEY : HapticFeedbackConstants.CLOCK_TICK;
                    web.performHapticFeedback(c);
                }
            });
        }
        @JavascriptInterface public void setTheme(final boolean d) {
            ui.post(new Runnable() {
                public void run() {
                    if (dark != d) { dark = d; prefs.edit().putBoolean("dark", d).apply(); }
                    applySystemBars();
                }
            });
        }
        @JavascriptInterface public boolean systemDark() {
            return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        }
        @JavascriptInterface public String insets() { return Math.round(topInset() / density) + "," + Math.round(insetBottom / density); }
        @JavascriptInterface public String info() {
            try {
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                JSONObject o = new JSONObject();
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("lowRam", am.isLowRamDevice());
                o.put("ramMb", mi.totalMem / (1024 * 1024));
                o.put("cores", Runtime.getRuntime().availableProcessors());
                return o.toString();
            } catch (Throwable t) { return "{\"sdk\":" + Build.VERSION.SDK_INT + "}"; }
        }
        @JavascriptInterface public void pick(final String tag, final String mode) { ui.post(new Runnable() { public void run() { startPick(tag, mode); } }); }
        @JavascriptInterface public String thumb(String id) { return thumbFor(id); }
        @JavascriptInterface public boolean openFile(final String id, final String mime, final String name) {
            final File f = fileFor(id);
            if (f == null || !f.exists()) return false;
            ui.post(new Runnable() {
                public void run() {
                    try {
                        Uri uri = FilesProvider.uriFor(MainActivity.this, "a", id, name);
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setDataAndType(uri, mime == null || mime.length() == 0 ? FilesProvider.guessMime(name) : mime);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        i.setClipData(ClipData.newRawUri(name, uri));
                        startActivity(i);
                    } catch (Throwable t) { toastJs("No hay una app para abrir este archivo"); }
                }
            });
            return true;
        }
        @JavascriptInterface public void removeFile(String id) {
            File f = fileFor(id);
            if (f != null) f.delete();
            File th = new File(new File(getCacheDir(), "miniaturas"), id + ".jpg");
            th.delete();
        }
        @JavascriptInterface public void wipeFiles() { deleteTree(attachDir()); deleteTree(new File(getCacheDir(), "miniaturas")); }
        @JavascriptInterface public void exportBackup(final String json, final String name) {
            ui.post(new Runnable() {
                public void run() {
                    pendingExport = json;
                    try {
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("application/json");
                        i.putExtra(Intent.EXTRA_TITLE, name);
                        startActivityForResult(i, REQ_EXPORT);
                    } catch (Throwable t) { pendingExport = null; shareBackup(json, name); }
                }
            });
        }
    }

    void shareBackup(String json, String name) {
        try {
            File dir = new File(getCacheDir(), "export");
            if (!dir.exists()) dir.mkdirs();
            String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
            File f = new File(dir, safe);
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(json.getBytes("UTF-8"));
            fo.close();
            Uri uri = FilesProvider.uriFor(this, "x", safe, safe);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.putExtra(Intent.EXTRA_SUBJECT, "Copia de Que Pasa Hermano");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.setClipData(ClipData.newRawUri(safe, uri));
            startActivity(Intent.createChooser(i, "Guardar copia en…"));
        } catch (Throwable t) { toastJs("No se pudo exportar la copia"); }
    }
}
